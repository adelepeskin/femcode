#ifndef SOLVER_H
#define SOLVER_H

class Solver_structure
{
   public:
      Solver_structure ( Mesh*, int );
      void set_up_the_solver ( );
      void fill_global_matrix ( );
      void solve_the_matrix ( );
      void solve_it( );
      myvar find_residual ( );
      void form_first_predictors ( );
      Mesh* mymesh;
      int number_of_equations; 

   protected:
      int degrees_of_freedom;
      myvar* matrix;
      myvar* rhs;
      myvar* delta_soln;
      myvar* solution;
      myvar* residual;
      myvar resid;
      int matrix_size;
      skyline_sizes* sky_sizes;
};

#endif
