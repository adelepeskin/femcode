#include <stdio.h>
#include <fstream.h>
#include <math.h>

int main( int argc, char** argv ) {
  // print out nodes
  for (int i = 0; i < 51; ++i) {
    printf("%d 0.0 %f 0.0 0\n",i*51+1,(float)(i));
    printf("%d 50.0 %f 0.0 1\n",i*51+51,(float)(i));
  }

  // print out constraints
  float vel= 0.0;
  float yy;
  printf("1    0.0   0.0   0\n");
  printf("51   0.0   0.0   1\n");
  for (int i = 0; i < 49; ++i) {
    yy = (float) (i+1);
    vel = -(yy*yy)/625.0 + (2.0*yy)/25.0;
    printf("%d %f 0.0 0\n",52+i*51,vel);
  }
  printf("2551   0.0   0.0   0\n");
  printf("2601   0.0   0.0   1\n");

  // print out initial values
  for (int i = 0; i < 51; ++i) {
    yy = (float) (i);
    vel = -(yy*yy)/625.0 + (2.0*yy)/25.0;
    printf("%d %f 0.0 0\n",1+i*51,vel);
    printf("%d %f 0.0 1\n",51+i*51,vel);
  }
  // print out elements
  for (int i = 0; i < 25; ++i) {
    for (int j = 0; j < 25; ++j) {
      printf("%d %d %d %d %d %d %d %d %d\n",2*j+1+i*102,2*j+3+i*102,
	     2*j+105+i*102,2*j+103+i*102,
	     2*j+2+i*102,2*j+54+i*102,
	     2*j+104+i*102,2*j+52+i*102,
	     2*j+53+i*102);
    }
  }
}
