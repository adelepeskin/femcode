void Element::fill_el_matrix ( )
{
  myvar rval = 1.0;
  for ( int cnt = 0; cnt < vel_dof*number_of_nodes*vel_dof*number_of_nodes; ++cnt ) {
    difcon_v[cnt] = 0.0;
    convection[cnt] = 0.0;
    v_duv[cnt] = 0.0;
  }
  for ( int cnt = 0; cnt < vel_dof*number_of_nodes; ++cnt ) {
    v_rhs[cnt] = 0.0;
  }
  myvar ratio = 1.0; int m_place = 0;

  // loop over pairs of the gauss points in each element
  // for each set of gauss points, loop over each pair of nodes
  int gauss_row = number_gauss_points - 1;
  for ( int pt_s = 0; pt_s < number_gauss_points; ++pt_s) {
    point_s = gauss_points [ gauss_row ] [ pt_s ];
    weight_s = gauss_weights [ gauss_row ] [ pt_s ];
    for ( int pt_t = 0; pt_t < number_gauss_points; ++pt_t) {
      point_t = gauss_points [ gauss_row ] [ pt_t ];
      weight_t = gauss_weights [ gauss_row ] [ pt_t ];
   
      // find derivatives at this gauss point
      find_derivatives ( ); 
      deriv->weight = weight_s * weight_t;
      deriv->weight_product = deriv->weight * determinant;
      just_weight = deriv->weight_product;
      
      // find values of the unknowns and the coordinates at this gauss point 
      find_values_at_this_gauss_point ( ); 
      find_vel_integral_terms ( );
    }
  }

  // form and add in the kp matrix if necessary
  form_kp_matrix ( );  

  // velocity constrained data
  rhs_from_constrained_values ( );
}

void Element::find_values_at_this_gauss_point ( )
{
  int next_eqn;
  myvar ux = 0.0, uy = 0.0;
  gauss_pt_u = 0.0, gauss_pt_v = 0.0;
  dudx = 0.0; dudy = 0.0; duds = 0.0; dudt = 0.0; 
  dvdx = 0.0; dvdy = 0.0; dvds = 0.0; dvdt = 0.0;
  
  for ( int ndp = 0; ndp < number_of_nodes; ++ndp )
    {
      next_eqn = vel_equation_numbers[vel_dof*ndp];
      ux = find_next_value ( next_eqn );
      next_eqn = vel_equation_numbers[vel_dof*ndp+1];
      uy = find_next_value ( next_eqn );
      gauss_pt_u += deriv->shape[ndp] * ux;
      gauss_pt_v += deriv->shape[ndp] * uy;
      dudx += deriv->global_deriv_x[ndp] * ux;
      dudy += deriv->global_deriv_y[ndp] * ux;
      dvdx += deriv->global_deriv_x[ndp] * uy;
      dvdy += deriv->global_deriv_y[ndp] * uy;
      duds += deriv->local_deriv_s[ndp] * ux;
      dudt += deriv->local_deriv_t[ndp] * ux;
      dvds += deriv->local_deriv_s[ndp] * uy;
      dvdt += deriv->local_deriv_t[ndp] * uy;
    }
}

void Element::find_vel_integral_terms ( )
{
  myvar mu = 1.0;
  myvar kinematic_vis = 1.0;  
  int plac2 = 0; int place = 0;
  int add_on; myvar add_on_term;
  int ct_place = 0;
  
  for ( int row = 0; row < number_of_nodes; ++row ) {
    for ( int col = 0; col < number_of_nodes; ++col ) {
      dxdx_term =
	deriv->global_deriv_x[row] * deriv->global_deriv_x[col];
      dydy_term =
	deriv->global_deriv_y[row] * deriv->global_deriv_y[col];
      add_on = vel_dof * number_of_nodes + 1;
      add_on_term =  deriv->weight_product *
	kinematic_vis * (dxdx_term + dydy_term);
      difcon_v[plac2] += add_on_term;
      difcon_v[plac2+add_on] += add_on_term;

      add_on_term = deriv->weight_product * 
	deriv->shape[row] *
	( gauss_pt_u * deriv->global_deriv_x[col] +
	  gauss_pt_v * deriv->global_deriv_y[col] );
      
      convection[plac2] += add_on_term;
      convection[plac2+add_on] += add_on_term;
      
      // extra derivatives for non-linear terms:
      // d(udu/dx)/du
      v_duv[plac2] += deriv->weight_product * 
	deriv->shape[row] * deriv->shape[col] * dudx;
      
      // d(vdu/dy)/dv
      v_duv[plac2+1] += deriv->weight_product * 
	deriv->shape[row] * deriv->shape[col] * dudy;
      
      // d(udv/dx)/du
      v_duv[plac2+add_on-1] += deriv->weight_product * 
	deriv->shape[row] * deriv->shape[col] * dvdx;
      
      // d(vdv/dy)/dv
      v_duv[plac2+add_on] += deriv->weight_product * 
	deriv->shape[row] * deriv->shape[col] * dvdy;
      plac2 += vel_dof;
      place += 1;
    }
    plac2 += (vel_dof-1)*vel_dof*number_of_nodes;
  }
}

void Element::find_derivatives ( )
{
  // find the shape functions
  deriv->shape[0] =  (0.25) * (1.0-point_s) * (1.0-point_t) * point_s * point_t;
  deriv->shape[1] = -(0.25) * (1.0+point_s) * (1.0-point_t) * point_s * point_t;
  deriv->shape[2] =  (0.25) * (1.0+point_s) * (1.0+point_t) * point_s * point_t;
  deriv->shape[3] = -(0.25) * (1.0-point_s) * (1.0+point_t) * point_s * point_t;
  deriv->shape[4] = -(0.5) * (1.0-point_s*point_s) * (1.0-point_t) * point_t;
  deriv->shape[5] =  (0.5) * (1.0+point_s) * (1.0-point_t*point_t) * point_s;
  deriv->shape[6] =  (0.5) * (1.0-point_s*point_s) * (1.0+point_t) * point_t;
  deriv->shape[7] = -(0.5) * (1.0-point_s) * (1.0-point_t*point_t) * point_s;
  deriv->shape[8] =  (1.0-point_s*point_s) * (1.0-point_t*point_t);
  //printf("shape: ");
  //for (int ii=0; ii<9; ++ii) {
  //  printf(" %f ",deriv->shape[ii]);
  //}
  //printf("\n");

  // find the local derivatives
  deriv->local_deriv_s[0] =   (0.25) * (1.0 - point_t) * point_t * (1.0 - 2.0*point_s);
  deriv->local_deriv_s[1] = - (0.25) * (1.0 - point_t) * point_t * (1.0 + 2.0*point_s);
  deriv->local_deriv_s[2] =   (0.25) * (1.0 + point_t) * point_t * (1.0 + 2.0*point_s);
  deriv->local_deriv_s[3] = - (0.25) * (1.0 + point_t) * point_t * (1.0 - 2.0*point_s);
  deriv->local_deriv_s[4] =   (1.0 - point_t) * point_s * point_t;
  deriv->local_deriv_s[5] =   (0.5) * (1.0 - point_t*point_t) * (1.0 + 2.0*point_s);
  deriv->local_deriv_s[6] = - (1.0 + point_t) * point_t * point_s;
  deriv->local_deriv_s[7] = - (0.5) * (1.0 - point_t*point_t) * (1.0 - 2.0*point_s);
  deriv->local_deriv_s[8] = - 2.0 * (1.0 - point_t*point_t) * point_s;
  
  deriv->local_deriv_t[0] =   (0.25) * (1.0 - point_s) * point_s * (1.0 - 2.0*point_t);
  deriv->local_deriv_t[1] = - (0.25) * (1.0 + point_s) * point_s * (1.0 - 2.0*point_t);
  deriv->local_deriv_t[2] =   (0.25) * (1.0 + point_s) * point_s * (1.0 + 2.0*point_t);
  deriv->local_deriv_t[3] = - (0.25) * (1.0 - point_s) * point_s * (1.0 + 2.0*point_t);
  deriv->local_deriv_t[4] = - (0.5) * (1.0 - point_s*point_s) * (1.0 - 2.0*point_t);
  deriv->local_deriv_t[5] = - (1.0 + point_s) * point_s * point_t;
  deriv->local_deriv_t[6] =   (0.5) * (1.0 - point_s*point_s) * (1.0 + 2.0*point_t);
  deriv->local_deriv_t[7] =   (1.0 - point_s) * point_s * point_t;
  deriv->local_deriv_t[8] = - 2.0 * (1.0 - point_s*point_s) * point_t;

  /*printf("locals: ");
  for (int ii=0; ii<9; ++ii) {
    printf(" %f ",deriv->local_deriv_s[ii]);
  }
  printf("\n");
  printf("localt: ");
  for (int ii=0; ii<9; ++ii) {
    printf(" %f ",deriv->local_deriv_t[ii]);
  }
  printf("\n");
  printf("yderiv: ");
  for (int ii=0; ii<9; ++ii) {
    printf(" %f ",deriv->y_vals[ii]);
  }
  printf("\n");*/

  // find the global derivatives and the determinant
  deriv->dx_ds = 0.0; deriv->dx_dt = 0.0;
  deriv->dy_ds = 0.0; deriv->dy_dt = 0.0;
  for ( int nod = 0; nod < 9; ++nod ) {
    deriv->dx_ds += deriv->local_deriv_s[nod] * deriv->x_vals[nod];
    deriv->dx_dt += deriv->local_deriv_t[nod] * deriv->x_vals[nod];
    deriv->dy_ds += deriv->local_deriv_s[nod] * deriv->y_vals[nod];
    deriv->dy_dt += deriv->local_deriv_t[nod] * deriv->y_vals[nod];
  }
  //printf("dxds: %f dxdt: %f dyds:%f dydt: %f\n",deriv->dx_ds,deriv->dx_dt,deriv->dy_ds,deriv->dy_dt);

  determinant = deriv->dx_ds * deriv->dy_dt   -
    deriv->dx_dt * deriv->dy_ds;
  //printf("determinant: %f\n",determinant);
   
  if ( fabs ( determinant ) < 0.1e-8 ) {
    printf("zero determinant at 9 node element\n"); 
    return;
  }

  // find global derivatives
  myvar det_inv = 1.0 / determinant;
  deriv->ds_dx =  det_inv * deriv->dy_dt;
  deriv->ds_dy = -det_inv * deriv->dx_dt;
  deriv->dt_dx = -det_inv * deriv->dy_ds;
  deriv->dt_dy =  det_inv * deriv->dx_ds;
  for ( int nod = 0; nod < 9; ++nod ) {
    deriv->global_deriv_x [nod] =
      deriv->ds_dx * deriv->local_deriv_s[nod] +
      deriv->dt_dx * deriv->local_deriv_t[nod];
    deriv->global_deriv_y [nod] =
      deriv->ds_dy * deriv->local_deriv_s[nod] +
      deriv->dt_dy * deriv->local_deriv_t[nod];
  }
  /*printf("globalx: ");
  for (int ii=0; ii<9; ++ii) {
    printf(" %f ",deriv->global_deriv_x[ii]);
  }
  printf("\n");
  printf("globaly: ");
  for (int ii=0; ii<9; ++ii) {
    printf(" %f ",deriv->global_deriv_y[ii]);
  }
  printf("\n");*/
}

void Element::form_kp_matrix ( )
{
  myvar lambda = 1.0e6;
  // this formulation is for 2-d cartesian or cylindrical coordinates;
  // for cylindrical coordinates, the final formulation of the penalty
  // matrix will be put into a (3x9)x(3x9) matrix instead of a (2x9)x(2x9)
  
  // assign computation space: c [0-80], m-1 [81-89], cm [90-170]
  // ct [171-251], c_dr [252-305], ct_dr [306-359], m_dr [360-368]
  // dr_terms [369-1097], cmm[1098-1178]
  myvar* c = &computation_space [0];
  myvar* m = &computation_space [81];
  myvar* cm = &computation_space [90];
  myvar* ct = &computation_space [171];
  myvar* c_dr = &computation_space [252];
  myvar* ct_dr = &computation_space [306];
  myvar* m_dr = &computation_space [360];
  myvar* dr_terms = &computation_space [369];
  myvar* cmm = &computation_space [1098];
  int velnum = 9 * vel_dof;
 
  // zero out computation space
  for ( int pt = 0; pt < 1178; ++pt )
    {
      computation_space [pt] = 0.0;
    }
  
  myvar ux = 0.0; myvar uy = 0.0;
  dudx = 0.0; dudy = 0.0;
  dvdx = 0.0; dvdy = 0.0;
  duds = 0.0; dudt = 0.0;
  dvds = 0.0; dvdt = 0.0;
  myvar xval = 0.0; myvar yval = 0.0;
  for ( int pt_s = 0; pt_s < 3; ++pt_s)
    {
      point_s = gauss_points [ 2 ] [ pt_s ];
      weight_s = gauss_weights [ 2 ] [ pt_s ];
      for ( int pt_t = 0; pt_t < 3; ++pt_t)
	{
	  point_t = gauss_points [ 2 ][ pt_t ];
	  weight_t = gauss_weights [ 2 ] [ pt_t ];
	  // find derivatives at this gauss point
	  find_derivatives ( );
	  myvar weight = weight_s * weight_t;
	  myvar weight_product = weight * determinant;
	  xval = 0.0; yval = 0.0;
	  for ( int ndp = 0; ndp < number_of_nodes; ++ndp )
	    {
	      xval += deriv->x_vals[ndp] * deriv->shape[ndp];
	      yval += deriv->y_vals[ndp] * deriv->shape[ndp];
	    } 
	  
	  // form the c matrix
	  int plac_c = 0;
	  for ( int row = 0; row < number_of_nodes; ++row )
	    {
	      myvar row_x_term = deriv->global_deriv_x[row];
	      myvar row_y_term = deriv->global_deriv_y[row];
	      c[plac_c] += weight_product * row_x_term;
	      c[plac_c+1] += weight_product * row_x_term * point_s;
	      c[plac_c+2] += weight_product * row_x_term * point_t;
	      c[plac_c+3] += weight_product * row_y_term;
	      c[plac_c+4] += weight_product * row_y_term * point_s;
	      c[plac_c+5] += weight_product * row_y_term * point_t;
	      plac_c += 6;
	    }
	  
	  // form pressure mass matrix
	  m[0] += weight_product;
	  m[1] += weight_product * point_s;
	  m[2] += weight_product * point_t;
	  m[3] += weight_product * point_s;
	  m[4] += weight_product * point_s * point_s;
	  m[5] += weight_product * point_s * point_t;
	  m[6] += weight_product * point_t;
	  m[7] += weight_product * point_s * point_t;
	  m[8] += weight_product * point_t * point_t;
	}
    }
  
  // now invert the mass matrix
  myvar det_of_3_by_3 = invert_a_3_by_3_matrix ( m );
  
  // for c*m-1*ct
  multiply_two_matrices ( c, 18, 3, m, 3, cm, 1.0 );
  transpose_a_matrix ( c, 18, 3, ct );
  multiply_two_matrices ( m, 3, 3, ct, 18, dr_terms, lambda );
  
  int next = 0;
  // compute the pressures for output: p = -lambda/rho * m-1 * ct * U
  myvar element_rho = 1.0;
  for ( int q = 0; q < 3; ++q )
    {
      myvar p1 = 0.0;
      int veleqn = 0; int velu = 0;
      for ( int r = 0; r < 18; ++r )
	{
	  int next_eqn = vel_equation_numbers[veleqn];
	  myvar ux = find_next_value ( next_eqn );
	  p1 += ux * dr_terms[next] * element_rho;
	  ++velu;
	  ++veleqn;
	  ++next;
	}
    }
  
  // use the dr_terms space temporarily since its the right size
  multiply_two_matrices ( cm, 18, 3, ct, 18, dr_terms, lambda/element_rho );
 
  for ( int j = 0; j < 324; ++j ) {
    difcon_v[j] += dr_terms[j];
  }
}

void Element::find_residual ( myvar* residual, myvar* solution )
{
  //printf("in el-2d find_residual: %f %f\n",residual[0],solution[0]);
  // find contribution from difcon_v
  field_residual_calc(residual, solution);
}

