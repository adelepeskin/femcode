#ifndef SOLVERIT_H
#define SOLVERIT_H

// FORTRAN iterative-solver interface

extern "C"
{
   int iter_solve_nop_ ( int*, myvar*, myvar*, myvar*, int*, int*,
                        int*, int*, myvar*, myvar*, int*, myvar*,
                        myvar*, myvar*, myvar*, int* );
   /* int iter_solve_ ( int*, myvar*, myvar*, myvar*, int*, int*,
                    myvar*, myvar*, int*, myvar*,
                    myvar*, myvar*, myvar*, int* );*/
   int nopcnv_ ( int*, int*, int*, int*, int*, int*, int*, int* );
}

class Solver_iterative : public Solver_structure
{
   public:
      Solver_iterative ( Mesh*, equation_groups, int );
      void size_the_global_matrix ( );
      void assign_sizes ( );
      void fill_global_matrix ( );
      void solve_the_matrix ( myvar* );

   protected:
      iterative_sizes* field_sizes;
      myvar* b;
      myvar* sorthm;
      myvar* xtemp;
      myvar* rw;
      myvar* piv;
      int north;
      int iter;
      myvar epn;
      int b_matrix_size;
};

#endif
