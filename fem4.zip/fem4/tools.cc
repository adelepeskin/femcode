#include "tools.h"
#include <math.h>

int min ( int first, int second )
{
   if ( first < second ) return first;
   return second;
}

int max ( int first, int second )
{
   if ( first > second ) return first;
   return second;
}

myvar max ( myvar first, myvar second )
{
   if ( first > second ) return first;
   return second;
}

myvar dot_product ( myvar* vector_a, myvar* vector_b, int length )
{
   myvar product = 0.0;
   if ( length < 1 ) return product;
   for ( int cnt = 0; cnt < length; ++cnt )
   {
      product += vector_a [cnt] * vector_b [cnt];
   }
   return product;
}

void multiply_two_matrices ( myvar* a, int n, int m, myvar* b,
   int p, myvar* product, myvar factor )
{
   for ( int j = 0; j < n*p; ++j )
   {
      product[j] = 0.0;
   }
   // multiply a (nXm) by b (mXp)
   for ( int row = 0; row < n; ++row )
   {
      for ( int col = 0; col < p; ++col )
      {
	 myvar sum = 0.0;
	 for ( int term = 0; term < m; ++term )
	 {
	    sum += a[m*row + term] * b[p*term + col];
	 }
	 product [p*row + col] += factor * sum;
      }
   }
}

void transpose_a_matrix ( myvar* a, int n, int m, myvar* at )
{
   for ( int row = 0; row < n; ++row )
   {
      for ( int col = 0; col < m; ++col )
      {
	 at[col*n + row] = a[row*m + col];
      }
   }
}

myvar invert_a_3_by_3_matrix ( myvar* matrix )
// overwrites original matrix with its inverse
{
   myvar a = matrix[0];  myvar b = matrix[1];  myvar c = matrix[2];
   myvar d = matrix[3];  myvar e = matrix[4];  myvar f = matrix[5];
   myvar g = matrix[6];  myvar h = matrix[7];  myvar i = matrix[8];
   myvar f1 = e*a - b*d;
   myvar f2 = h*a - b*g;
   myvar f3 = f*a - c*d;
   myvar f4 = i*a - c*g;
   myvar f5 = d*h - g*e;
   myvar factor = f4 * f1 - f3 * f2;

   myvar det = c*f5 - f*f2 + i*f1;
   
   if ( fabs (factor) < small || fabs (f1) < small || fabs (a) < small
	|| fabs (det) < small )
   {
      det = 0.0;
      return  ( det );
   }

   matrix[8] =  a * f1 / factor;
   matrix[7] = -a * f2 / factor;
   matrix[6] = ( d * f2 - g * f1 ) / factor;
   matrix[5] = -a * f3 / factor;
   matrix[4] = ( a - matrix[7] * f3 ) / f1;
   matrix[3] = (-d - matrix[6] * f3 ) / f1;
   matrix[2] = - ( b * matrix[5] + c * matrix[8] ) / a;
   matrix[1] = - ( b * matrix[4] + c * matrix[7] ) / a;
   matrix[0] =  ( 1.0 - b * matrix[3] - c * matrix[6] ) / a;
   return det;
}

myvar det_of_3_by_3_matrix ( myvar* matrix )
// returns determinant; leaves matrix intact
{
   myvar a = matrix[0];  myvar b = matrix[1];  myvar c = matrix[2];
   myvar d = matrix[3];  myvar e = matrix[4];  myvar f = matrix[5];
   myvar g = matrix[6];  myvar h = matrix[7];  myvar i = matrix[8];
   myvar det = a * (e*i - h*f) - b * (d*i - g*f) + c * (d*h - g*e);
   return det;
}

myvar distance_between_points ( myvar* pointa, myvar* pointb )
{
   myvar distance = (pointa[0] - pointb[0])*(pointa[0] - pointb[0]) +
      (pointa[1] - pointb[1])*(pointa[1] - pointb[1]);
   distance = sqrt ( distance );
   return ( distance );
}

myvar time_piston_rate ( myvar a, myvar b, myvar c, myvar d, myvar stage_time )
{
   // compression or expansion
   myvar rate = a + b * sin ( c + d * stage_time );
   //cout << "stage time in sin: " << stage_time << "  sin(c+dt): " << sin ( c + d * stage_time ) << "  bsin: " << b * sin ( c + d * stage_time ) << " total: " << rate << endl;
   return ( rate );
}

myvar get_timed_velocities ( myvar time, myvar vel_param )
{
  // cout << "time: " << time << endl;
   myvar val = vel_param * sin(2.0e0*pi*time);
   // cout << "val: " << val << endl;
   return val;
}
