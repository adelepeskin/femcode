#ifndef MESHFEM_H
#define MESHFEM_H
#include <stdio.h>
#include <fstream.h>
#include "node.cc"
#include "el.cc"
#include "el-2d.cc"

class Mesh
{
   public:
      Mesh ( );
      int Set_up_mesh ( );
      int number_of_equations;
      void assign_skyline (skyline_sizes*);
      void fill_el_matrix ( );
      void fill_global_matrix ( myvar*, int*, int* );
      void element_resid (myvar*, myvar*);
      void update_nodes( myvar* );
      myvar* initial_soln;
      void printSolution();

   protected:
      int number_of_nodes;
      int number_of_elements;
      int number_constrained;

   private:
      Element** element_list;
      Node** node_list;
};

#endif
