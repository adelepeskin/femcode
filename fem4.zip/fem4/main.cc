#include "mytypes.h"
#include "structs.h"
#include "mesh-fem.cc"
#include "solver.cc"

int main( int argc, char** argv )
{
  // create a mesh entity
  Mesh* newmesh = new Mesh ( );

  // read in element information and create elements
  // return number of equations in global matrix
  int numeqns = newmesh->Set_up_mesh ( );
  printf("number of equations: %d\n",numeqns);

  Solver_structure* solv = new Solver_structure(newmesh, numeqns);
  solv->set_up_the_solver ( );
  solv->solve_the_matrix();

  return 0;
}
