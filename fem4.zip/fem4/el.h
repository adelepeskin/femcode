#ifndef EL_H
#define EL_H

struct element_derivatives
{
   myvar* current_soln_v;
   myvar* shape;
   myvar* local_deriv_s;
   myvar* local_deriv_t;
   myvar* global_deriv_x;
   myvar* global_deriv_y;
   myvar* local_second_deriv_s;
   myvar* global_second_deriv_x;
   myvar* x_vals;
   myvar* y_vals;
   myvar dx_ds;
   myvar dx_dt;
   myvar dy_ds;
   myvar dy_dt;
   myvar ds_dx;
   myvar ds_dy;
   myvar dt_dx;
   myvar dt_dy;
   myvar weight;
   myvar weight_product;
};

class Element
{
   public:
      Element ( int, myvar* );
      ~Element ( );
      void set_up_new_element ( );
      void get_node_coordinates ( );
      Node* get_node_ptr ( int );
      myvar get_determinant ( Element* );
      myvar find_next_value ( int );
      myvar getValue ( int );
      int find_place_in_global_matrix ( int, int, int*, int* );
      void rhs_from_constrained_values ( );
      void element_to_global_skyline
	 ( myvar*, int*, int*, myvar, int, int, myvar*, int*, int* );
      void element_to_global_rhs ( myvar*, myvar*, int*, int, myvar );
      void field_residual_calc ( myvar*, myvar*);
      void fill_el_matrix ( );
      void find_derivatives ( );
      void form_kp_matrix ( );
      void find_values_at_this_gauss_point ( );
      void find_vel_integral_terms ( );
      void e_matrix_into_skyline
	( int*, int*, int, int, myvar*, myvar* );
      void find_residual ( myvar*, myvar* );
      void fill_equation_number_arrays ( );
      Node** connect_ptrs;
      int* connectivity;
      int* vel_equation_numbers;
      myvar* difcon_v;
      myvar* convection;
      myvar* v_duv;
      myvar* v_rhs;
      int number_of_nodes;
      element_derivatives* deriv;

   protected:
      int element_number;
      int difcon_v_size;
      myvar* rho_g;
      myvar* mass;
      myvar dudx;
      myvar dudy;
      myvar duds;
      myvar dudt;
      myvar dvdx;
      myvar dvdy;
      myvar dvds;
      myvar dvdt;
      myvar dxdx_term;
      myvar dydy_term;
      myvar determinant;
      myvar just_weight;
      int number_gauss_points;
      myvar point_s;
      myvar point_t;
      myvar weight_s;
      myvar weight_t;
      myvar gauss_pt_u;
      myvar gauss_pt_v;
      int vel_dof;
      myvar* computation_space;
      static const myvar gauss_points [ 7 ] [ 7 ];
      static const myvar gauss_weights [ 7 ] [ 7 ];
};


#endif




