#ifndef CONST_DENSITY_H
#define CONST_DENSITY_H

class const_density: public Property_model
{
   friend class Element;
   public:
      const_density ( density_models, model_types );
      myvar find_density ( myvar, myvar );
      myvar find_dp_dt ( myvar, myvar );
      myvar find_enthalpy ( myvar, myvar, myvar );

   protected:
};

#endif
