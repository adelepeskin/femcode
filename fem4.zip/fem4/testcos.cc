#include <fstream.h>
#include <math.h>

main()
{
   // this program tests what units the input to cosine should be in
   
  cout << "try degrees: " << endl;  
   for ( int d = 0; d < 6; ++d )
   {
      cout << "cosine of " << d << " times 60: " << cos(10.0*d) << endl;
    }
   
  cout << "try radians: " << endl;
   double pi2 = 6.28;
   pi2 = pi2/6.0;  
   for ( d = 0; d < 6; ++d )
   {
     cout << "cosine of " << d << " times 2pi/6: " << pi2*d << " is: " << cos(pi2*d) << endl;
    }
}

