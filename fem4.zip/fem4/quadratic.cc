#include "quadratic.h"
#include "property_model.h"
#include "el.h"
#include "io.h"
#include <math.h>
#include <fstream.h>

// define static members (default initialization to 0)
//end addition

quadratic::quadratic ( density_models dens_type, model_types mod_type )
   :Property_model ( dens_type, mod_type )
{
}

myvar quadratic::find_density ( myvar tempval, myvar pressval )
{
   myvar density = 0.0;
   myvar A,B,C;
   myvar mol_vol;
   myvar Mw =
     properties->molecular_weights[properties->main_component_number]; 

   // use second virial coefficient:
   // the density is a function of temperature and pressure

   // PV/RT = 1 + B(T)/V
   // V^2 - (RT/P)V - RTB/P = 0

   A = 1.0;
   B = -gas_const_r * tempval/pressval;
   C = B * find_b_ ( &tempval );
   // cout << "findb at temp: " << tempval << " is: " << find_b_(&tempval) << endl;

   // solve for molar volume:
   mol_vol = quad_solver_ ( &A, &B, &C );
   // find density
   density = Mw / mol_vol;
   cout << "quad density: " << density << " press: " << pressval << " temp: " << tempval << endl;
   return ( density );
}

myvar quadratic::find_dp_dt ( myvar tempval, myvar pressval )
{
   // PV/RT = 1 + B(T)/V
   // P = (rho R T / Mw) + (rho^2 R T B/ Mw^2)
   // dP/dT = (rho R / Mw) + (rho^2 R B/ Mw^2) = P/T

   return ( pressval/tempval );
}

myvar quadratic::find_enthalpy ( myvar tempval, myvar pressval, myvar )
{
   // first find ideal gas part:
   myvar enthalpy = cpIcpp ( tempval );
   // enthalpy returned in units of (J/(mol-K)): change to J/g-K
   enthalpy /= molecular_wt;

   // add extra terms from Virial equation:
   myvar Tr = tempval / properties->tcrit;
   myvar Pr = pressval / properties->pcrit;

   myvar B0 = find_b_ ( &tempval );
   myvar dB0dT = find_dbdt_ ( &tempval );
   // B's in units of cm^3/mole:

   // the next term is unitless:
   myvar extra_term = (pressval/gas_const_r) * (dB0dT - (B0/tempval));
   extra_term = ((8.314 * tempval)/molecular_wt) * extra_term;
   enthalpy -= extra_term;

   return ( enthalpy );
}

