struct skyline_sizes
{
   int* diag;
   int* left;
   int matrix_size;
};
