#include "const_density.h"
// define static members (default initialization to 0)
//end addition

const_density::const_density 
   ( density_models dens_type, model_types mod_type  )
   :Property_model ( dens_type, mod_type )
{
}

myvar const_density::find_density ( myvar, myvar )
{
   myvar density = 0.0;
   density = properties->density;
   return ( density );
}

myvar const_density::find_dp_dt ( myvar, myvar )
{
   return ( 0.0 );
} 

myvar const_density::find_enthalpy ( myvar tempval, myvar, myvar )
{
  // enthalpy changes for constant Cp: Cp(T - Tref)
   myvar enthalpy = properties->heat_capacity * (tempval - tref);
   return ( enthalpy );
}


