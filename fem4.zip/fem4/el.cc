#include "el.h"
#include "tools.cc"

const myvar Element::gauss_points [ 7 ] [ 7 ] =
{
   { 0.00000000000000, 0.00000000000000, 0.00000000000000, 0.00000000000000,
     0.00000000000000, 0.00000000000000, 0.00000000000000 },
   { 0.57735026918963, -.57735026918963, 0.00000000000000, 0.00000000000000,
     0.00000000000000, 0.00000000000000, 0.00000000000000 },
   { 0.77459666924148, -.77459666924148, 0.00000000000000, 0.00000000000000,
     0.00000000000000, 0.00000000000000, 0.00000000000000 },
   { 0.86113631159405, -.86113631159405, 0.33998104358486, -.33998104358486,
     0.00000000000000, 0.00000000000000, 0.00000000000000 },
   { 0.90617984593866, -.90617984593866, 0.53846931010568, -.53846931010568,
     0.00000000000000, 0.00000000000000, 0.00000000000000 },
   { 0.93246951420315, -.93246951420315, 0.66120938646626, -.66120938646626,
     0.23861918608320, -.23861918608320, 0.00000000000000 },
   { 0.94910791234276, -.94910791234276, 0.74153118559939, -.74153118559939,
     0.40584515137740, -.40584515137740, 0.00000000000000 }
};

const myvar Element::gauss_weights [ 7 ] [ 7 ] =
{
   { 2.00000000000000, 1.00000000000000, 0.00000000000000, 0.00000000000000,
     0.00000000000000, 0.00000000000000, 0.00000000000000 },
   { 1.00000000000000, 1.00000000000000, 0.00000000000000, 0.00000000000000,
     0.00000000000000, 0.00000000000000, 0.00000000000000 },
   { 0.55555555555556, 0.55555555555556, 0.88888888888889, 0.00000000000000,
     0.00000000000000, 0.00000000000000, 0.00000000000000 },
   { 0.34785484513745, 0.34785484513745, 0.65214515486255, 0.65214515486255,
     0.00000000000000, 0.00000000000000, 0.00000000000000 },
   { 0.23692688505619, 0.23692688505619, 0.47862867049937, 0.47862867049937,
     0.00000000000000, 0.00000000000000, 0.00000000000000 },
   { 0.17132449237917, 0.17132449237917, 0.36076157304814, 0.36076157304814,
     0.46791393457270, 0.46791393457269, 0.00000000000000 },
   { 0.12948496616887, 0.12948496616887, 0.27970539148928, 0.27970539148928,
     0.38183005050512, 0.38183005050512, 0.41795918367347 }
};

Element::Element ( int el_number, myvar* cmpsp )
{
   element_number = el_number;
   connectivity = 0;
   connect_ptrs = 0;
   vel_equation_numbers = 0;
   vel_dof = 2;
   number_of_nodes = 9;
   computation_space = cmpsp;
   deriv = new element_derivatives;
   deriv->shape = new myvar[number_of_nodes];
   deriv->local_deriv_s = new myvar[number_of_nodes];
   deriv->local_deriv_t = new myvar[number_of_nodes];
   deriv->global_deriv_x = new myvar[number_of_nodes];
   deriv->global_deriv_y = new myvar[number_of_nodes];
   deriv->x_vals = new myvar[number_of_nodes];
   deriv->y_vals = new myvar[number_of_nodes];
   number_of_nodes = 9;
   number_gauss_points = 2;
   connect_ptrs = new Node*[number_of_nodes];
   connectivity = new int[number_of_nodes];
   vel_equation_numbers = new int[2*number_of_nodes];
   difcon_v = new myvar[2*number_of_nodes*2*number_of_nodes];
   convection = new myvar[2*number_of_nodes*2*number_of_nodes];
   v_duv = new myvar[2*number_of_nodes*2*number_of_nodes];
   v_rhs = new myvar[2*number_of_nodes];
}

Element::~Element ( )
{
   delete [] connectivity;
   delete [] connect_ptrs;
}

void Element::get_node_coordinates ( )
{
   // the coordinate values get put into the
   // Mesh element_derivative structure
   for ( int nod = 0; nod < number_of_nodes; ++nod)
   {
      deriv->x_vals[nod] = connect_ptrs[nod]->x;
      deriv->y_vals[nod] = connect_ptrs[nod]->y;
   }
}

void Element::rhs_from_constrained_values ( ) {
   myvar value = 0.0; Node* n_ptr; int place = 0;
   int next_eqn, col_eqn, val_num;
   for ( int row = 0; row < 2*number_of_nodes; ++row ) {
     v_rhs [row]= 0.0;
   }

   place = 0;
   for ( int row = 0; row < 2*number_of_nodes; ++row ) {
     next_eqn = vel_equation_numbers [row];
     if ( next_eqn < 0 ) {
       place += 2*number_of_nodes;
       continue;
     }

     for ( int col = 0; col < 2*number_of_nodes; ++col ) {
	 col_eqn = vel_equation_numbers [col];
	 n_ptr = get_node_ptr ( col_eqn );
	 if ( col_eqn < 0 ) {
	   value = n_ptr->getValue( col_eqn );
	   //printf("node number: %d and value: %f\n",n_ptr->node_number,value);
	   v_rhs [row] -= (difcon_v[place]+convection[place]) * value;
	 }
	 ++place;
      }
   }
   //printf("vrhs: %f %f %f %f %f %f %f %f %f\n",v_rhs[0],v_rhs[1],v_rhs[2],v_rhs[3],v_rhs[4],v_rhs[5],v_rhs[6],v_rhs[7],v_rhs[8]);
   //printf("vrhs: %f %f %f %f %f %f %f %f %f\n",v_rhs[9],v_rhs[10],v_rhs[11],v_rhs[12],v_rhs[13],v_rhs[14],v_rhs[15],v_rhs[16],v_rhs[17]);
}

int Element::find_place_in_global_matrix
    ( int row_eqn, int col_eqn, int* left, int* diag )
{
   int m_place = 0;
   int left_diff = 0; int top_diff = 0;
   int column_diag = 0;
   int current_diag = diag [ row_eqn ];
   int current_left = left [ row_eqn ];

   // 3 choices for how to assemble
   if ( row_eqn == col_eqn )
   {
      // put entry on the diagonal
      m_place = diag[row_eqn];
   }
   else if ( row_eqn > col_eqn )
   {
      // put entry to the left of the diagonal
      m_place = diag[row_eqn-1] + left[row_eqn] + 1 - row_eqn + col_eqn;
   }
   if (row_eqn < col_eqn )
   {
      // put entry above the column diagonal
      column_diag = diag [ col_eqn ];
      top_diff = col_eqn - row_eqn;
       m_place = column_diag - top_diff;
   }
   //printf("row and col: %d %d  place: %d\n",row_eqn,col_eqn,m_place);
   return m_place;
}

myvar Element::find_next_value ( int next_eqn )
{
   Node* n_ptr = get_node_ptr ( next_eqn );
   myvar value = 0.0;
   int val_num = 0;
   value = n_ptr->getValue ( next_eqn );
   return value;
}

myvar Element::getValue ( int eqn ) {

}

void Element::element_to_global_skyline ( myvar* matrix, int* left, int* diag, myvar step_factor, int number_of_rows, int number_of_columns,
myvar* el_matrix, int* row_eqn_numbers, int* col_eqn_numbers )
{
   // add entries for equation numbers first to last
   int place = 0; int m_place = 0;
   int row_eqn = 0; int col_eqn = 0;
   myvar entry;
   place = 0;
   for ( int row = 0; row < number_of_rows; ++row ) {
     row_eqn = row_eqn_numbers [row];
     if ( row_eqn < 0 ) {
       place += number_of_columns;
       continue;
     }
     for ( int col = 0; col < number_of_columns; ++col ) {
       col_eqn = col_eqn_numbers [col];
       entry = step_factor * el_matrix[place];
       ++place;
       if (col_eqn < 0) continue;
 
       m_place = find_place_in_global_matrix
	 ( row_eqn, col_eqn, left, diag );
       matrix [m_place] += entry;
     }
   }
}

void Element::element_to_global_rhs ( myvar* rhs_vector, 
     myvar* elem_rhs, int* row_eqn_numbers, int number_of_rows, myvar factor )
{
   for ( int row = 0; row < number_of_rows; ++row )
   {
      int row_eqn = row_eqn_numbers [row];
      if ( row_eqn < 0 ) continue;
      rhs_vector [ row_eqn ] += factor * elem_rhs [row];
   }
}

void Element::field_residual_calc ( myvar* residual, 
    myvar* soln_vec)
{
   myvar uval_new, uval_old; int place = 0;
   int row_eqn = 0; int col_eqn = 0;

   place = 0;
   for ( int row = 0; row < 2*number_of_nodes; ++row ) {
     row_eqn = vel_equation_numbers [row];
     if (row_eqn < 0) {
       place += 2*number_of_nodes;
       continue;
     }
     
     for ( int col = 0; col < 2*number_of_nodes; ++col ) {
       col_eqn = vel_equation_numbers [col];
       if (col_eqn > -1)  {
	 uval_new = soln_vec[col_eqn];
	 residual [row_eqn] += uval_new * (difcon_v[place]+ convection[place]);
	 //printf("in field resid: eqn: %d uval: %f\n",col_eqn,uval_new);
       }
       ++place;
     }

     // add on contribution from rhs
     residual [row_eqn] -= v_rhs[row];
   }
}

Node* Element::get_node_ptr ( int eqn_number )
{
   // find position on connectivity list
   int place = 0; int eqnu = 0; int eqnv = 0;
   Node* n_ptr = 0;
   for ( int nod = 0; nod < number_of_nodes; ++nod ) {
     eqnu = vel_equation_numbers[2*nod];
     eqnv = vel_equation_numbers[2*nod+1];
     if (eqnu == eqn_number || eqnv == eqn_number)
       n_ptr = connect_ptrs[nod];
   }
   return ( n_ptr );
}

myvar Element::get_determinant ( Element* elem )
{
   myvar det;
   det = elem->determinant;
   return det;
}
