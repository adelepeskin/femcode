#include "tools.h"
#include "mesh-fem.h"
#include "solver.h"
#include "solver-it.h"
#include <fstream.h>

Solver_iterative::Solver_iterative 
   ( Mesh* newmesh, equation_groups matrx_group, int numeqn )
:Solver_structure ( newmesh, matrx_group, numeqn )
{
   int_flags->solver_type = iterative;
   field_sizes = new iterative_sizes;
   int gauss_number = int_flags->gauss_number;
   cout << "gauss number is: " << gauss_number << "\n";
   field_sizes->pivots = 0;
   field_sizes->row_eqns = 0;
   field_sizes->nop = 0;
   field_sizes->igauss = gauss_number;
   number_of_equations = numeqn;
   size_the_global_matrix ( );
   // size_the_matrix computes number_of_equations;
   cout << "size of numeqns, matrix_size  " << number_of_equations << "  " << matrix_size
        << "\n"; 
   north = 15;
   epn = number_of_equations * int_flags->iteration_error;
   iter = int_flags->max_iteration_loop;
   sorthm = new myvar [(north+1)*(number_of_equations+25)];
   xtemp = new myvar [number_of_equations+25];
   rw = new myvar [number_of_equations+25];
   piv = new myvar [number_of_equations+25];
   rhs_vector = new myvar [ number_of_equations+extra_eqns ];
   delta_soln = new myvar [number_of_equations+extra_eqns ];
   residual = new myvar [number_of_equations+extra_eqns ];
   soln_vec = new solution_vectors;
   soln_vec->current_soln = new myvar [ number_of_equations+extra_eqns ];
   soln_vec->old_soln = new myvar [ number_of_equations+extra_eqns ];
   soln_vec->very_old_soln = new myvar [ number_of_equations+extra_eqns ];
   soln_vec->current_deriv = new myvar [ number_of_equations+extra_eqns ];
   soln_vec->old_deriv = new myvar [ number_of_equations+extra_eqns ];
   soln_vec->very_old_deriv = new myvar [ number_of_equations+extra_eqns ];
   soln_vec->current_guess = new myvar [ number_of_equations+extra_eqns ];
   soln_vec->current_time = 0.0;
}

void Solver_iterative::size_the_global_matrix ( )
{
   // first get rid of old sizing matrices if this is a resizing
   if ( int_flags->resize_global_flag == resize )
   {
      // delete old row_eqns
      delete [] field_sizes->row_eqns;
      // delete a and b global matrices
      delete [] matrix;
      delete [] b;
   }

   // now assign the sizes
   assign_sizes ( );
   int_flags->resize_global_flag = same_size;
}

void Solver_iterative::assign_sizes ( )
{
   int numeqns = number_of_equations;
   b_matrix_size = 0;
   int old_matrix_size = matrix_size;
   cout << "print out old matrix size: " << old_matrix_size << endl;

   field_sizes->pivots = new int [number_of_equations+25];
   mymesh->Loop_to_assign_iterative ( field_sizes );
   
   // see if the matrix has been resized and is now bigger
   if ( int_flags->resize_global_flag == resize_but_keep_old_matrix );
   {
      cout << "print out old matrix size: " << old_matrix_size << endl;
      cout << "print out new matrix size: " << matrix_size << endl;
      if ( matrix_size > old_matrix_size )
      {
         // delete a and b global matrices
         delete [] matrix;
         delete [] b;
         int_flags->resize_global_flag = resize;
      }
   }

   int biggest = 1;
   // define a space to use each block
   biggest = field_sizes->a_matrix_size;
   matrix_size = max ( matrix_size, biggest );
   cout << "final a matrix size: " << matrix_size << " \n";

   if ( int_flags->resize_global_flag != resize_but_keep_old_matrix );
   {
      matrix = new myvar [matrix_size];
      for ( int w = 0; w < matrix_size; ++w )
      {
         matrix[w] = 0.0;
      }

      biggest = field_sizes->b_matrix_size;
      b_matrix_size = max ( b_matrix_size, biggest );
      cout << "final b matrix size: " << b_matrix_size << " \n";
      b = new myvar [b_matrix_size];
      for ( w = 0; w < b_matrix_size; ++w )
      {
         b[w] = 0.0;
      }
   }
}

void Solver_iterative::fill_global_matrix ( )
{
   mymesh->Loop_to_fill_iterative ( this, rhs_vector, field_sizes );
}

void Solver_iterative::solve_the_matrix ( myvar* residual )
{ 
   cout << "start of solve_the matrix: " << endl;
   int* pivots = field_sizes->pivots;
   int* row_eqns = field_sizes->row_eqns;
   int* nop = field_sizes->nop;
   int gauss_number = field_sizes->igauss;
   int numeqns = number_of_equations; 

   // store the current solution in delta_soln and add on the
   // calculated delta at the end
   for ( int q = 0; q < numeqns; ++q )
   {
      delta_soln[q] = soln_vec->current_soln[q];
   }
   
    if ( int_flags->initial_flag  == solving_for_initial )
       numeqns -= int_flags->number_of_surf_equations;

    iter = int_flags->max_iteration_loop; 
    epn = 0.00001 * numeqns * int_flags->iteration_error;
    // send in the residual as the rhs
    int iter2 = 25, junk;

    if ( gauss_number > 0 )
    {
       cout << "calling iter_solve_nop: \n";
       cout << "print out numeqns: " << numeqns << "\n";
       junk = iter_solve_nop_ ( &numeqns, matrix, b, residual, row_eqns, nop,
           &north, &numeqns, sorthm, &epn, pivots, &xtemp[0], &rw[0],
           soln_vec->current_soln, piv, &iter2 );
    }
    /* else
    {
       cout << "calling iter_solve: \n";
       junk = iter_solve_ ( &numeqns, matrix, b, residual, row_eqns, 
           &north, sorthm, &epn, pivots, &xtemp[0], &rw[0],
           soln_vec->current_soln, piv, &iter2 );
    }*/

   // move solution into solution vector
   for ( int j = 0; j < numeqns; ++j )
   {
      soln_vec->current_soln[j] = delta_soln[j] 
                  - int_flags->decceleration_factor*residual[j];
   }

   cout << "print out the first solutions: ";
   for ( j = 0; j < 6; ++j )
   {
     cout << soln_vec->current_soln[j] << "  ";
   }
   cout << endl;
}

