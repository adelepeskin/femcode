#ifndef MYTYPES_H
#define MYTYPES_H
typedef double myvar;

const myvar small = 1.0e-15;
const myvar kind_of_small = 1.0e-5;
const myvar machine_zero = 0.1e-23;
const myvar pi = 3.14159265358979;
const myvar gas_const_r = 82.05;
const myvar gas_const_J = 8.314471;
const int max_number_of_matrices = 3;
const int extra_eqns = 25;
const myvar atm_to_kPa = 101.325;
const myvar tref = 273.15;
const myvar rhoref = 1.0;

#endif






