#ifndef SORTS_H
#define SORTS_H

static void swap ( int *ia, int i, int j );

void qsort ( int* ia, int low, int high );

void bsort ( int* ia, int size );

#endif
