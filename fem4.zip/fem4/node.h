#ifndef NODE_H
#define NODE_H

class Node
{
 public:
  Node (int, myvar, myvar);
  myvar getValue( int );
  myvar x;
  myvar y;
  int ueqn;
  int veqn;
  bool constrained;
  myvar initialu;
  myvar initialv;
  myvar uval;
  myvar vval;
  int node_number;
  
 protected:
};

#endif
