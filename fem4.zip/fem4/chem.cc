#include "chem.h"
#include <math.h>

// Added 10-8-93 by TPQ
// define static members (default initialization to 0)
      integration_flags* Chemical_reaction::int_flags;
      myvar* Chemical_reaction::current_soln;
      int Chemical_reaction::temperature_dof;
      int Chemical_reaction::last_mass_dof;
// end Addition

// initialize public static member constants
const myvar Chemical_reaction::r_in_kcals = 0.001987;

Chemical_reaction::Chemical_reaction ( int reaction_num,
   type_of_reaction type_rxn, int num_forward_1,
   int num_backward_1, int num_forward_2,
   int num_backward_2, myvar k1, myvar k2,
   myvar ea, myvar bbb, reaction_temp_term t_term )
{
   reaction_number = reaction_num;
   type = type_rxn;
   number_of_single_forward_reactants = num_forward_1;
   number_of_single_backward_reactants = num_backward_1;
   number_of_double_forward_reactants = num_forward_2;
   number_of_double_backward_reactants = num_backward_2;
   single_forward_reactants = new int [number_of_single_forward_reactants];
   single_backward_reactants = new int [number_of_single_backward_reactants];
   double_forward_reactants = new int [number_of_double_forward_reactants];
   double_backward_reactants = new int [number_of_double_backward_reactants];
   current_soln = 0; 
   k_1 = k1;
   k_2 = k2;
   E_a = ea;
   beta = bbb;
   temp_term = t_term;  
}
 
myvar Element::get_reaction_term ( int dof )
{
   myvar rate = 0.0;
   // find the reactions for this dof
   int num_rxns = rxns_for_each[dof]->num_gas_rxns;
   if ( num_rxns == 0 ) return rate = 0.0;
  
   for ( int rxn = 0; rxn < num_rxns; ++rxn )
   {
      // get the reaction number
      int number = rxns_for_each[dof]->gas_rxns[rxn];
      // now get the rate for this reaction
      list_of_reactions[number-1]->elem = this;
      list_of_reactions[number-1]->tempval = tempval;
      rate += list_of_reactions[number-1]->assemble_rate ( dof );
   }
   // rate is computed in molar units: change back
   //rate *= properties->molecular_weights[dof];
   return rate;
}

myvar Element::get_d_reaction_term 
   ( int dof, int df_deriv )
{
   myvar rate = 0.0;
   // find the reactions for this dof
   int num_rxns = rxns_for_each[dof]->num_gas_rxns;
   if ( num_rxns == 0 ) return rate = 0.0;
   for ( int rxn = 0; rxn < num_rxns; ++rxn )
   {
      // get the reaction number
      int number = rxns_for_each[dof]->gas_rxns[rxn];
      // now get the rate for this reaction
      list_of_reactions[number-1]->elem = this;
      list_of_reactions[number-1]->tempval = tempval;
      rate += list_of_reactions[number-1]->assemble_rate_derivative
        ( dof, df_deriv );
   }
   //rate *= properties->molecular_weights[dof];
   return rate;
}

myvar Element::get_dt_reaction_term ( int dof )
{
   myvar rate = 0.0;
   // find the reactions for this dof
   int num_rxns = rxns_for_each[dof]->num_gas_rxns;
   if ( num_rxns == 0 ) return rate = 0.0;
   for ( int rxn = 0; rxn < num_rxns; ++rxn )
   {
      // get the reaction number
      int number = rxns_for_each[dof]->gas_rxns[rxn];
      // now get the rate for this reaction
      list_of_reactions[number-1]->elem = this;
      list_of_reactions[number-1]->tempval = tempval;
      rate += list_of_reactions[number-1]->assemble_temp_derivative ( dof );
   }
   //rate *= properties->molecular_weights[dof];
   return rate;
}

myvar Element::get_surface_reaction_term ( int dof )
{
   myvar rate = 0.0;
   // find the surface reactions for this dof
   int num_rxns = rxns_for_each[dof]->num_surface_rxns;
   if ( num_rxns == 0 ) return rate = 0.0;
   for ( int rxn = 0; rxn < num_rxns; ++rxn )
   {
      // get the reaction number
      int number = rxns_for_each[dof]->surf_rxns[rxn];
      // now get the rate for this reaction
      list_of_reactions[number-1]->elem = this;
      list_of_reactions[number-1]->tempval = tempval;
      rate += list_of_reactions[number-1]->assemble_rate ( dof );
   }
   //rate *= properties->molecular_weights[dof];
   return rate;
}

myvar Element::get_surface_d_reaction_term 
   ( int dof, int df_deriv )
{
   myvar rate = 0.0;
   // find the surface reactions for this dof
   int num_rxns = rxns_for_each[dof]->num_surface_rxns;
   if ( num_rxns == 0 ) return rate = 0.0;
   for ( int rxn = 0; rxn < num_rxns; ++rxn )
   {
      // get the reaction number
      int number = rxns_for_each[dof]->surf_rxns[rxn];
      // now get the rate for this reaction
      list_of_reactions[number-1]->elem = this;
      list_of_reactions[number-1]->tempval = tempval;
      rate += list_of_reactions[number-1]->assemble_rate_derivative
              ( dof, df_deriv );
   }
   //rate *= properties->molecular_weights[dof];
   return rate;
}

myvar Element::get_surface_dt_reaction_term ( int dof )
{
   myvar rate = 0.0;
   // find the surface reactions for this dof
   int num_rxns = rxns_for_each[dof]->num_surface_rxns;
   if ( num_rxns == 0 ) return rate = 0.0;
   for ( int rxn = 0; rxn < num_rxns; ++rxn )
   {
      // get the reaction number
      int number = rxns_for_each[dof]->surf_rxns[rxn];
      // now get the rate for this reaction
      list_of_reactions[number-1]->elem = this;
      list_of_reactions[number-1]->tempval = tempval;
      rate += list_of_reactions[number-1]->assemble_temp_derivative ( dof );
   }
   //rate *= properties->molecular_weights[dof];
   return rate;
}

myvar Element::get_growth_reaction_term ( )
{
   myvar rate = 0.0;
   // find the surface reactions for this dof
   int num_rxns = rxns_for_each[growth_dof-1]->num_growth_rxns;
   if ( num_rxns == 0 ) return rate = 0.0;
   for ( int rxn = 0; rxn < num_rxns; ++rxn )
   {
      // get the reaction number
      int number = rxns_for_each[growth_dof-1]->growth_rxns[rxn];
      // now get the rate for this reaction
      list_of_reactions[number-1]->elem = this;
      list_of_reactions[number-1]->tempval = tempval;
      // send routine the dof of the growth reactant
      rate += list_of_reactions[number-1]->assemble_rate ( -1 );
   }
   //rate *= properties->molecular_weights[growth_dof];
   return rate;
}

myvar Element::get_growth_d_reaction_term 
   ( int df_deriv )
{
   myvar rate = 0.0;
   // find the surface reactions for this dof
   int num_rxns = rxns_for_each[growth_dof-1]->num_growth_rxns;
   if ( num_rxns == 0 ) return rate = 0.0;
   for ( int rxn = 0; rxn < num_rxns; ++rxn )
   {
      // get the reaction number
      int number = rxns_for_each[growth_dof-1]->growth_rxns[rxn];
      // now get the rate for this reaction
      list_of_reactions[number-1]->elem = this;
      list_of_reactions[number-1]->tempval = tempval;
      rate += 
         list_of_reactions[number-1]->assemble_rate_derivative( -1,df_deriv );
   }
   //rate *= properties->molecular_weights[growth_dof];
   return rate;
}

myvar Element::get_growth_dt_reaction_term ( )
{
   myvar rate = 0.0;
   // find the surface reactions for this dof
   int num_rxns = rxns_for_each[growth_dof-1]->num_growth_rxns;
   if ( num_rxns == 0 ) return rate = 0.0;
   for ( int rxn = 0; rxn < num_rxns; ++rxn )
   {
      // get the reaction number
      int number = rxns_for_each[growth_dof-1]->growth_rxns[rxn];
      // now get the rate for this reaction
      list_of_reactions[number-1]->elem = this;
      list_of_reactions[number-1]->tempval = tempval;
      rate += list_of_reactions[number-1]->assemble_temp_derivative
              ( growth_dof-1 );
   }
   //rate *= properties->molecular_weights[growth_dof];
   return rate;
}

myvar Chemical_reaction::assemble_rate ( int dof )
{
   // reaction terms will go in the column of the dof of the first reactant
   // set rate to set if dof is not the first component

   myvar rate_sign = 1.0;
   myvar rate; int reactant_number;
   myvar numerator = 1.0; myvar denominator = 1.0;
   int rxn;
   if ( int_flags->con_logs == take_logs )
   {
      numerator = (1.0 / elem->molar_conval[ dof ]);
   }

   for ( rxn = 0; rxn < number_of_single_forward_reactants; ++rxn )
   {
      reactant_number = single_forward_reactants[rxn];
      numerator *= elem->molar_conval[reactant_number-1];
      if ( reactant_number == (dof+1)) rate_sign = -1.0;
   }

   for ( rxn = 0; rxn < number_of_double_forward_reactants; ++rxn )
   {
      reactant_number = double_forward_reactants[rxn];
      numerator *= elem->molar_conval[reactant_number-1] *
                      elem->molar_conval[reactant_number-1];
      if ( reactant_number == (dof+1)) rate_sign = -1.0;
   }

   // multiply concentrations in the denominator
   for ( rxn = 0; rxn < number_of_single_backward_reactants; ++rxn )
   {
      reactant_number = single_backward_reactants[rxn];
      denominator *= elem->molar_conval[reactant_number-1];
   }

   for ( rxn = 0; rxn < number_of_double_backward_reactants; ++rxn )
   {
      reactant_number = double_backward_reactants[rxn];
      denominator *= elem->molar_conval[reactant_number-1] *
                     elem->molar_conval[reactant_number-1];
   }

   rate = rate_sign * k_1 * numerator / denominator;
   if ( temperature_dof > 0 )
   {
      rate *= assemble_energy_term ( );
   }
   return rate; 
}


myvar Chemical_reaction::assemble_rate_derivative ( int df, int dof_deriv )
{
   // multiply concentrations in the numerator
   myvar rate_sign = 1.0;
   myvar rate = 0.0; int reactant_number; 
   myvar numerator = 1.0; myvar denominator = 1.0;
   reactant_in_reaction in_reaction = is_not_in_reaction;
   if ( int_flags->con_logs == take_logs )
   {
      numerator = -elem->molar_conval[ df ];
   } 

   // make sure dof_deriv is in this reaction
   int rxn;
   for ( rxn = 0; rxn < number_of_single_forward_reactants; ++rxn )
   {
      // see if this reactant is the one whose derivative is taken
      reactant_number = single_forward_reactants[rxn];
      if ( reactant_number == (df+1) ) rate_sign = -1.0;
      if ( reactant_number != (dof_deriv+1) )
         numerator *= elem->molar_conval[reactant_number-1];
      else
         numerator *= elem->col_shape;

      if ( reactant_number == (dof_deriv+1) ) in_reaction = is_in_reaction;
   }

   for ( rxn = 0; rxn < number_of_double_forward_reactants; ++rxn )
   {
      // see if this reactant is the one whose derivative is taken
      reactant_number = double_forward_reactants[rxn];
      if ( reactant_number == (df+1) ) rate_sign = -1.0;
      if ( reactant_number != (dof_deriv+1) )
         numerator *= elem->molar_conval[reactant_number-1] *
                      elem->molar_conval[reactant_number-1];
      else
         numerator *= 2.0 * elem->col_shape *
                      elem->molar_conval[reactant_number-1];

      if ( reactant_number == (dof_deriv+1) )in_reaction = is_in_reaction;
   }
   
   // multiply concentrations in the denominator
   for ( rxn = 0; rxn < number_of_single_backward_reactants; ++rxn )
   {
      reactant_number = single_backward_reactants[rxn];
      if ( reactant_number != (dof_deriv+1) )
         denominator *= elem->expval[reactant_number-1];
      else
      {
         numerator *= -elem->col_shape;
         denominator *=  elem->expval[reactant_number-1] *
                         elem->expval[reactant_number-1] *
                         elem->expval[reactant_number-1];
      }
   }

   for ( rxn = 0; rxn < number_of_double_backward_reactants; ++rxn )
   {
      reactant_number = double_backward_reactants[rxn];
      if ( reactant_number != (dof_deriv+1) )
         denominator *= elem->expval[reactant_number-1] *
                        elem->expval[reactant_number-1];
      else
      {
         numerator *= -2.0 * elem->col_shape;
         denominator *=  elem->molar_conval[reactant_number-1] *
                         elem->molar_conval[reactant_number-1] *
                         elem->molar_conval[reactant_number-1];
      }
   }

   // now form rate
   if ( in_reaction == is_in_reaction )
   { 
      rate = rate_sign * k_1 * numerator / denominator;
      if ( temperature_dof > 0 )
         rate *= assemble_energy_term ( );
      return rate;
   }
   else
      return 0.0;
}

myvar Chemical_reaction::assemble_temp_derivative ( int dof )
{
   myvar rate = assemble_rate ( dof );
   rate *= assemble_d_energy ( );
   return rate;  
}

myvar Chemical_reaction::assemble_energy_term ( )
{
   myvar ratio = 1.0;
   if ( temp_term == exponential_rate )
   {
      // assemble exp ( -E_a / RT ) term for appropriate node
      ratio = -E_a / (r_in_kcals * tempval);
      ratio = exp ( ratio );
   }
   if ( temp_term == adsorption_rate )
   {
      // assemble 1/sqrt(T) term
      ratio /= sqrt(tempval); 
   }
   if ( temp_term == exp_and_adsorp )
   {
      ratio = -E_a / (r_in_kcals * tempval);
      ratio = exp ( ratio );
      ratio /= sqrt(tempval);
   }
   if ( temp_term == t_exp_b )
   {
      ratio = pow ( tempval, beta );
   }
   return ratio;
}

myvar Chemical_reaction::assemble_d_energy ( )
{
   myvar ratio = 1.0;
   if ( temp_term == exponential_rate )
   {
      // assemble ( -1 / T**2 ) * ( -E_a / RT ) term 
      ratio = E_a / r_in_kcals;
      ratio /= tempval * tempval;
   }
   if ( temp_term == adsorption_rate )
   {
      // assemble d/dT(R/sqrt(T)) term = term (multiplied in already) * (-T/2)
      ratio = -tempval/2.0; 
   }
   if ( temp_term == exp_and_adsorp )
   {
      ratio = tempval;
      ratio *= ( E_a * tempval / r_in_kcals ) - 0.5;
   }
   if ( temp_term == t_exp_b )
   {
      ratio = beta / tempval;
   }
   return ratio;
}
 



