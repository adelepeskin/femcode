#ifndef PARTICLES_H
#define PARTICLES_H

struct save_particle_info
{
   Element** old_e_ptrs;
   int* old_side_numbers;
   Node** old_node_ptrs;
};

struct box
{
   Particle* p_ptr;
   myvar xmin;
   myvar xmax;
   myvar ymin;
   myvar ymax;
   myvar zmin;
   myvar zmax;
   myvar old_xmin;
   myvar old_xmax;
   myvar old_ymin;
   myvar old_ymax;
};

class Particle : public Moving_boundary_entity
{
   friend class List;
   friend class Mesh;
   friend class Node;
   friend class Element;
   friend class One_d_element;
   friend class Two_d_element;
   friend class four_node_element;
   friend Element* find_element_ptr ( int );
   public:
      Particle ( int, integration_flags* );
      myvar find_particle_radius ( int );
      void move_the_mesh_forward ( myvar* );
      void put_back_original_coordinates ( );
      void move_the_mesh_back ( );
      void save_old_coordinates ( );
      int is_node_on_list ( myvar* );
      void find_particle_element_intersections  ( );
      void find_all_the_nodes_inside ( );
      bool is_element_on_particle_list ( Element* );
      bool is_element_on_old_particle_list ( Element* );
      Node* find_the_closest_particle_node ( myvar* );
      void set_up_eqn_arrays ( );
      void save_old_element_info ( );
      void replace_old_element_info ( );
      void display_particle_intersection_data ( );
      void display_line_element_data ( );
      void find_rotation_angle ( Node* );
      int find_first_eqn ( );
      void set_element_particle_pointers ( );
      void put_nodes_inside_particle_boxes ( );
      void rezero_elements_for_particle_info ( );
      void rezero_particle_info ( );
      void display_intersection_info ( );
      void take_node_off_list ( Node* );
      void define_new_region ( remesh_region* );
      void print_particle_elements ( );
      void is_particle_box_in_region_box ( );
      void define_region_box ( );
      void assign_the_box ( );
      void store_old_particle_box_values ( );
      void find_direction_of_movement ( );

   protected:
      int particle_number;
      static int nodes_per_particle;
      static phase_properties* phase;
      constrained* v_values;
      Node** node_ptrs;
      Node** nodes_intersecting_elements;
      myvar radius;
      Node* center_node;
      int* particle_nodes;
      int number_of_intersection_points;
      Node* old_node_ptr;
      save_particle_info* old_particle_info;
      int dof_for_movement;
      Element* zero_element;
      int* part_equation_numbers;
      box* particle_box;
      constrained* press_values;
      particle_move_type part_move;
};

#endif
