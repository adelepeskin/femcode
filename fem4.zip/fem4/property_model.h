#ifndef PROPERTY_MODEL_H
#define PROPERTY_MODEL_H

struct refprop_data 
// this is data normally stored in common blocks in refprop
{
   myvar lower_temp;
   myvar upper_temp;
   myvar upper_press; // in KPa
   myvar max_density; // in mol/L
   myvar triple_point_temp;
   myvar triple_point_press;  // in KPa
   myvar triple_point_density; // in mol/L
   myvar boiling_temp;
   myvar acentric;
   myvar reducing_t;
   myvar reducing_rho; // in mol/L
   int number_of_terms;
   int coeff_per_term;
   myvar* ai;
   myvar* ti;
   myvar* di;
   int* li;
   myvar* phi01;
   myvar* phi10;
   myvar* phisav;
   // parameter for CP0 fit
   int number_cp_terms;
   myvar* cpc;
   myvar* xk;
};

// FORTRAN iterative-solver interface
extern "C"
{
   myvar cubic_solver_ ( myvar*, myvar*, myvar* );
}

class Property_model;

struct phase_properties
{
   myvar density;
   myvar viscosity;
   myvar thermal_conductivity;
   myvar heat_capacity;
   myvar gas_vapor_pressure;
   myvar tcrit; // in degrees K
   myvar pcrit; // in atm
   myvar rhocrit; // in mole/cm^3
   myvar* diffusivity;
   myvar* molecular_weights;
   myvar* molar_concentrations;
   myvar* mass_concentrations;
   myvar* surface_mws;
   myvar* surface_concentrations;
   myvar* thermal_diff_alpha_a;
   myvar* thermal_diff_alpha_b;
   myvar* thermal_diff_alpha_c;
   chemical_reaction_flag chem_reactions;
   int main_component_number;
   Property_model* prop_model;
};

class Property_model
{
   friend class Element;
   friend class Mesh;
   public:
      Property_model ( density_models, model_types );
      virtual myvar find_density ( myvar, myvar );
      virtual myvar find_dp_dt ( myvar, myvar );
      virtual myvar find_enthalpy ( myvar, myvar, myvar );
      myvar cp0cpp ( myvar );
      myvar cpIcpp ( myvar );
      myvar cpTcpp ( myvar );
      
   protected:
      phase_properties* properties;
      density_models density_type;
      model_types type_of_model;
      refprop_data* fluid_data;
      myvar molecular_wt;
};

#endif
