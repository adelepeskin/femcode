#ifndef REFPROP_H
#define REFPROP_H

#include "property_model.h"
#include "mytypes.h"

class refprop: public Property_model
{
   friend class Element;
   public:
      refprop ( density_models, model_types );
      myvar find_density ( myvar, myvar );
      myvar find_dp_dt ( myvar, myvar );
      myvar find_enthalpy ( myvar, myvar, myvar );
      myvar newpress ( myvar, myvar );
      myvar newdpdd ( myvar, myvar );
      myvar phik ( int, int, myvar, myvar );
      myvar phi0 ( int, myvar, myvar );

   protected:
};

#endif
