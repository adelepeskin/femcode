Element* List::get_top_element ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   return e_ptr;
}


void List::get_initial_values ( integration_flags* int_flags )
{
   // get initial values from input data: load nodal_solution structure
   // with current solution values
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   int mass_dof = int_flags->mass_degrees_of_freedom;
   int vel_dof = int_flags->vel_degrees_of_freedom;
   int surf_dof = int_flags->surf_degrees_of_freedom;
   myvar* cval = new myvar [mass_dof];
   myvar* cvals = new myvar [surf_dof];
   myvar temp, ux, uy, uz, press, pot;
   initial_node_values* initial_values = new initial_node_values;
   initial_values->initial_c = new myvar [mass_dof];
   initial_values->initial_csurf = new myvar [surf_dof];
   myvar* dc = new myvar [mass_dof];
   myvar* dcs = new myvar [surf_dof];
   int oldnum = 0;
   myvar* oldc = new myvar [mass_dof];
   myvar* oldcs = new myvar [surf_dof];
   myvar oldt = 0.0; myvar oldu = 0.0;
   myvar oldv = 0.0; myvar oldw = 0.0;
   myvar oldp = 0.0; myvar oldpot = 0.0;
   //cin.precision(12);
   while (n_item != 0 )
   {
      read_in_nodal_values ( int_flags, initial_values );
      if ( initial_values->generate == 0 )
      {
	 if ( int_flags->mass_eqns == solve_mass )
	 {
            n_ptr->first_values->initial_c = new myvar [mass_dof];
            for ( int nxt = 0; nxt < mass_dof; ++nxt )
	    {
	       n_ptr->first_values->initial_c[nxt] = initial_values->initial_c[nxt];
               n_ptr->nodal_solutions->conc[nxt] = initial_values->initial_c[nxt];
	    }
	 }

	 if ( int_flags->temp_eqns == solve_temp )
	 {
	    n_ptr->first_values->initial_t = initial_values->initial_t;
            n_ptr->nodal_solutions->temp = initial_values->initial_t; 
	 }
           
	 if ( int_flags->vel_eqns == solve_vel )
	 {
	    n_ptr->first_values->initial_u = initial_values->initial_u;
	    n_ptr->first_values->initial_v = initial_values->initial_v;
            if ( int_flags->coordinate_flag == cylindrical )
               n_ptr->first_values->initial_w = initial_values->initial_w;
            n_ptr->nodal_solutions->vel[0] = initial_values->initial_u;
            n_ptr->nodal_solutions->vel[1] = initial_values->initial_v;
            if ( int_flags->coordinate_flag == cylindrical )
               n_ptr->nodal_solutions->vel[2] = initial_values->initial_w;
            if ( int_flags->turb_eqns == solve_turb )
	    {
               n_ptr->first_values->initial_k = initial_values->initial_k;
	       n_ptr->first_values->initial_e = initial_values->initial_e;
               n_ptr->nodal_solutions->turbk = initial_values->initial_k;
               n_ptr->nodal_solutions->turbe = initial_values->initial_e; 
	    }  
	 }

         if ( int_flags->pot_eqns == solve_pot )
	 {
	    n_ptr->first_values->initial_pot = initial_values->initial_pot;
	    n_ptr->nodal_solutions->pot = initial_values->initial_pot;  
	 }

         if ( int_flags->surf_eqns == solve_surf )
	 {
            n_ptr->first_values->initial_csurf = new myvar [surf_dof];
            for ( int nxt = 0; nxt < surf_dof; ++nxt )
	    {
	       n_ptr->first_values->initial_csurf[nxt] = 
                                    initial_values->initial_csurf[nxt];
               n_ptr->nodal_solutions->surf_conc[nxt] = initial_values->initial_csurf[nxt];
	    }
	 }
         n_item = n_item->next;
         if (n_item!=0) n_ptr = n_item->value;
         for ( int nxt = 0; nxt < mass_dof; ++nxt )
	 {
            cval[nxt] = initial_values->initial_c[nxt];
	 }
         temp = initial_values->initial_t;
         ux = initial_values->initial_u;
         uy = initial_values->initial_v;
         uz = initial_values->initial_w;
         press = initial_values->initial_p;
         pot = initial_values->initial_pot;
         for ( int nxt = 0; nxt < surf_dof; ++nxt )
	 {
            cvals[nxt] = initial_values->initial_csurf[nxt];
	 }
      }
      else
      {
	 int newnum =
	 (initial_values->node_number - oldnum) / initial_values->generate;
         for (int nxt = 0; nxt < mass_dof; ++nxt )
	 {
	    dc[nxt] = (initial_values->initial_c[nxt] - oldc[nxt]) / newnum;
	 }
	 myvar dt = (initial_values->initial_t - oldt) / newnum;
	 myvar du = (initial_values->initial_u - oldu) / newnum;
	 myvar dv = (initial_values->initial_v - oldv) / newnum;
         myvar dw = (initial_values->initial_w - oldw) / newnum;
	 myvar dp = (initial_values->initial_p - oldp) / newnum;
         myvar dpot = (initial_values->initial_pot - oldpot) / newnum;
         for ( int nxt = 0; nxt < surf_dof; ++nxt )
	 {
	    dcs[nxt] = (initial_values->initial_csurf[nxt] - oldcs[nxt]) / newnum;
	 }
	 for ( int nd = 0; nd < newnum; ++nd )
	 {
            for ( int nxt = 0; nxt < mass_dof; ++nxt )
	    {
               cval[nxt] = oldc[nxt] + (nd+1)*dc[nxt];
	    }
	    temp = oldt + (nd+1)*dt;
	    ux = oldu + (nd+1)*du;
	    uy = oldv + (nd+1)*dv;
            uz = oldw + (nd+1)*dw;
	    press = oldp + (nd+1)*dp;
            pot = oldpot + (nd+1)*dpot;
            for ( int nxt = 0; nxt < surf_dof; ++nxt )
	    {
               cvals[nxt] = oldcs[nxt] + (nd+1)*dcs[nxt];
	    }
	    if ( int_flags->mass_eqns == solve_mass )
	    {
               n_ptr->first_values->initial_c = new myvar [mass_dof];
               for (int nxt = 0; nxt < mass_dof; ++nxt )
	       {
                  n_ptr->first_values->initial_c[nxt] = cval[nxt];
                  n_ptr->nodal_solutions->conc[nxt] = cval[nxt];
	       }
	    }

	    if ( int_flags->temp_eqns == solve_temp )
	    {
               n_ptr->first_values->initial_t = temp;
               n_ptr->nodal_solutions->temp = temp; 
	    }

	    if ( int_flags->vel_eqns == solve_vel )
	    {
	       n_ptr->first_values->initial_u = ux;
	       n_ptr->first_values->initial_v = uy;
               if ( vel_dof > 2 )
                  n_ptr->first_values->initial_w = uz;
               n_ptr->nodal_solutions->vel[0] = ux;
               n_ptr->nodal_solutions->vel[1] = uy;
               if ( vel_dof > 2 )
                  n_ptr->nodal_solutions->vel[2] = uz; 
	    }
	    if ( int_flags->press_eqns == solve_press )
	       n_ptr->first_values->initial_p = press;

            if ( int_flags->pot_eqns == solve_pot )
	    {
	       n_ptr->first_values->initial_pot = pot;
               n_ptr->nodal_solutions->pot = pot;
	    }
   
            if ( int_flags->surf_eqns == solve_surf )
	    {
               n_ptr->first_values->initial_csurf = new myvar [surf_dof];
               for (int nxt = 0; nxt < surf_dof; ++nxt )
	       {
                  n_ptr->first_values->initial_csurf[nxt] = cvals[nxt];
                  n_ptr->nodal_solutions->surf_conc[nxt] = cvals[nxt]; 
	       }
	    }
            if (n_item!=0) n_item = n_item->next;
	    if (n_item!=0) n_ptr = n_item->value;
	 }
      }
      oldnum = initial_values->node_number;
      for ( int nxt = 0; nxt < mass_dof; ++nxt )
      {
         oldc[nxt] = cval[nxt];
      }
      oldt = temp; oldu = ux; oldv = uy; oldw = uz;
      oldp = press; oldpot = pot;
      for ( int nxt = 0; nxt < surf_dof; ++nxt )
      {
         oldcs[nxt] = cvals[nxt];
      }
   }
}

void List::read_in_nodal_values ( integration_flags* int_flags,
   initial_node_values* initial_values )
{
   cin >> initial_values->node_number;

   initial_values->initial_t = 0.0;
   initial_values->initial_u = 0.0;
   initial_values->initial_v = 0.0;
   initial_values->initial_w = 0.0;
   initial_values->initial_p = 0.0;
   initial_values->initial_k = 0.0;
   initial_values->initial_e = 0.0;
   initial_values->initial_pot = 0.0;
   if ( int_flags->mass_eqns == solve_mass )
   {
      for ( int nxt = 0; nxt < int_flags->mass_degrees_of_freedom; ++nxt )
      {
         cin >> initial_values->initial_c[nxt];
         if ( int_flags->con_logs == take_logs )
         {
            if ( initial_values->initial_c[nxt] > 1.0e-23 )
               initial_values->initial_c[nxt] =
                  log(initial_values->initial_c[nxt]);
            else
               initial_values->initial_c[nxt] = log ( 1.0e-23 );
	 }
      }
   }

   if ( int_flags->temp_eqns == solve_temp )
      cin >> initial_values->initial_t;

   if ( int_flags->vel_eqns == solve_vel )
   {
      cin >> initial_values->initial_u;
      cin >> initial_values->initial_v;
      if ( int_flags->vel_degrees_of_freedom > 2 )
        cin >> initial_values->initial_w;
      if ( int_flags->turb_eqns == solve_turb )
      { 
         cin >> initial_values->initial_k;
         cin >> initial_values->initial_e;
      }
   }

   if ( int_flags->pot_eqns == solve_pot )
      cin >> initial_values->initial_pot;

   if ( int_flags->surf_eqns == solve_surf )
   {
      for ( int nxt = 0; nxt < int_flags->surf_degrees_of_freedom; ++nxt )
      {
         cin >> initial_values->initial_csurf[nxt];
         if ( int_flags->con_logs == take_logs )
         {
            if ( initial_values->initial_csurf[nxt] > 1.0e-23 )
               initial_values->initial_csurf[nxt] =
                  log(initial_values->initial_csurf[nxt]);
            else
               initial_values->initial_csurf[nxt] = log ( 1.0e-23 );
	 }
      }
   }

   cin >> initial_values->generate;
}

void List::get_initial_pressures ( integration_flags* int_flags )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   int cnter = 0;
   while (e_item != 0)
   {
      while ( (e_ptr->element_number < 0 || 
               e_ptr->is_it_a_special_particle_element == 
                     special_particle_element || 
                     e_ptr->dimension == 1) && e_item!= 0)
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
         if (e_item == 0) return;
      }

      if ( e_item == 0 ) continue;
      // assign space for element
      e_ptr->initial_press = 
         new myvar [e_ptr->number_of_pressure_basis_fcns];
      for ( int j = 0; j < e_ptr->number_of_pressure_basis_fcns; j++ )
      {
         cin >> e_ptr->initial_press[j];
         cnter += 1;
         e_ptr->current_pressure[j] = e_ptr->initial_press[j];
         if ( int_flags->piston_motion != no_piston )
	 {
            e_ptr->current_pressure[j] = int_flags->pressure_min;
            if ( j > 0 ) e_ptr->current_pressure[j] = 0.0;
	 }
      }
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
      
      while ( e_item != 0 && 
        e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
   }

   return;
}

void List::set_current_pressure_space ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;

   while (e_item != 0)
   {
      while ( e_ptr->element_number < 0 || e_ptr->dimension == 1 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
         if ( e_item == 0 ) continue;
      }

      if ( e_item == 0 ) continue;
      e_ptr->current_pressure = 
         new myvar [e_ptr->number_of_pressure_basis_fcns];
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;

      while ( e_item != 0 && 
        e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
   }
   return;
}

void List::setup_initial_pressures ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;

   while (e_item != 0)
   {
      while ( e_ptr->element_number < 0 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      // assign space for element
      e_ptr->current_pressure = 
         new myvar [e_ptr->number_of_pressure_basis_fcns];
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
      while ( e_item != 0 && 
        e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
   }
}

void List::get_initial_field 
   ( integration_flags* int_flags, equation_groups matrix_group,
     solution_vectors* soln_vec )
{
   // get initial nodal values and 
   // collect them in the current guess for the solution vector

   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   int mass_degrees_of_freedom = int_flags->mass_degrees_of_freedom;
   int vel_degrees_of_freedom = int_flags->vel_degrees_of_freedom;
   int surf_degrees_of_freedom = int_flags->surf_degrees_of_freedom;
   int mass_eqn, temp_eqn, vel_eqn, turbk_eqn, turbe_eqn;
   int part_eqn, pot_eqn, surf_eqn, line_eqn;
   while ( n_item != 0 )
   {
      if ( matrix_group == all_equations || matrix_group == temperature_only )
      {
         if ( int_flags->mass_eqns == solve_mass )
         {
	    mass_eqn = n_ptr->first_mass_eqn;
            if ( mass_eqn > 0 )
	    {
               for ( int nxt = 0; nxt < mass_degrees_of_freedom; ++nxt )
  	       {
 	          soln_vec->current_guess[mass_eqn-1+nxt] =
                     n_ptr->first_values->initial_c[nxt];
	       }
	    }
         }
   
         if ( int_flags->temp_eqns == solve_temp )
         {
	    temp_eqn = n_ptr->first_temp_eqn;
	    if ( temp_eqn > 0 )
	       soln_vec->current_guess[temp_eqn-1] = n_ptr->first_values->initial_t;
         }
      }

      if ( int_flags->vel_eqns == solve_vel && 
         (matrix_group == all_equations || matrix_group == velocity_only))
      {
	 vel_eqn = n_ptr->first_vel_eqn;
         part_eqn = n_ptr->first_particle_eqn;
	 if ( vel_eqn > 0 )
	 {
            if ( n_ptr->center_mark == at_the_center )
            {
               soln_vec->current_guess[vel_eqn-1] = 
                  n_ptr->first_values->initial_v;
               if ( vel_degrees_of_freedom > 2 )
                 soln_vec->current_guess[vel_eqn] = n_ptr->first_values->initial_w;
            }
            else
            {
	       soln_vec->current_guess[vel_eqn-1] = n_ptr->first_values->initial_u;
	       soln_vec->current_guess[vel_eqn] = n_ptr->first_values->initial_v;
               if ( vel_degrees_of_freedom > 2 )
                  soln_vec->current_guess[vel_eqn+1] = n_ptr->first_values->initial_w;
               if ( int_flags->particle_eqns == solve_particle && 
                       part_eqn > 0 )
                  soln_vec->current_guess[part_eqn-1] = n_ptr->first_values->initial_rot;
            } 
	 }
         if ( int_flags->turb_eqns == solve_turb )
	 {
            turbk_eqn = n_ptr->first_turbk_eqn;
            turbe_eqn = n_ptr->first_turbe_eqn;
            if ( turbk_eqn > 0 )
	    {
	       soln_vec->current_guess[turbk_eqn-1] = 
                  n_ptr->first_values->initial_k;
	       soln_vec->current_guess[turbe_eqn-1] = 
                  n_ptr->first_values->initial_e;
	    }
	 }
      }

      if ( int_flags->pot_eqns == solve_pot && 
         ( matrix_group == all_equations || matrix_group == temperature_only ))
      {
	 pot_eqn = n_ptr->first_pot_eqn;
	 if ( pot_eqn > 0 )
	       soln_vec->current_guess[pot_eqn-1] = n_ptr->first_values->initial_pot;
      }

      if ( int_flags->surf_eqns == solve_surf &&  
         ( matrix_group == all_equations || matrix_group == temperature_only ))
      {
         surf_eqn = n_ptr->first_surf_eqn;
         if ( surf_eqn > 0 )
	 {
            for ( int nxt = 0; nxt < surf_degrees_of_freedom; ++nxt )
  	    {
 	       soln_vec->current_guess[surf_eqn-1+nxt] =
                  n_ptr->first_values->initial_csurf[nxt];
	    }
	 }
      }
      
      if ( n_ptr->node_type == line_node &&  
         ( matrix_group == all_equations || matrix_group == temperature_only ))
      {
	 line_eqn = n_ptr->first_moving_eqn;
	 if ( line_eqn > 0 )
	    soln_vec->current_guess[line_eqn-1] = -0.02;
      }
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
   }
}

void List::get_initial_element_field ( solution_vectors* soln_vec )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0)
   {
      while ( e_ptr->element_number < 0 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      if ( e_ptr->number_of_pressure_basis_fcns > 0 )
      {
         for ( int j = 0; j < e_ptr->number_of_pressure_basis_fcns; ++j )
         {
            int press_eqn = e_ptr->press_equation_numbers[j];
            soln_vec->current_guess[press_eqn-1] = e_ptr->initial_press[j];
	 }
      }
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
      while ( e_item != 0 && 
         e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
   }
   return;
}

void List::renumber_equations ( )
{
  // not used any more: renumber_equations_separately used instead
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while ( e_item != 0 )
   {
      while ( e_ptr->element_number < 0 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      e_ptr->renumber_equations ( );
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
      while ( e_item != 0 && 
         e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      } 
   }
}

void List::renumber_equations_separately ( equation_groups* matrix_groups )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while ( e_item != 0 )
   {
      while ( e_ptr->element_number < 0 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      e_ptr->renumber_equations_separately ( matrix_groups );
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
      while ( e_item != 0 && 
         e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      } 
   }
}

Node* List::find_node_ptr ( int n_number )
{
   // this routine finds the node pointer that corresponds to
   // a node number
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   bool found = false;
   int test = 0;
   while ( n_item != 0 && found == false )
   {
      test = n_ptr->node_number;
      if (test == n_number)
      {
	 found = true;
	 return n_ptr;
      }
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
   }
   return ( n_ptr );
}

void List::find_vval ( )
{
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;

   while ( n_item != 0 )
   {
     if ( n_ptr->particle_ptr != 0 ) n_ptr->check_vval ( );
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
   }
}

Element* List::find_element_ptr ( int e_number )
{
   // this routine finds the node pointer that corresponds to
   // a node number
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   bool found = false;
   int test = 0;
   while (e_item != 0 && found == false)
   {
      test = e_ptr->element_number;
      if (test == e_number)
      {
	 found = true;
	 return e_ptr;
      }
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
   }
   return ( e_ptr );
}

void List::count_field_eqn_numbers ( integration_flags* int_flags )
{
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   int mass_dof = int_flags->mass_degrees_of_freedom;
   int vel_dof = int_flags->vel_degrees_of_freedom;
   int surf_dof = int_flags->surf_degrees_of_freedom;
   int current_fixed = int_flags->number_of_field_fixed + 1;
   int_flags->numbers_of_equations[0] = 1;
   int vel_matrix = 0;
   if ( int_flags->matrix_groups[1] == velocity_only )
   {
      int_flags->numbers_of_equations[1] = 1;
      vel_matrix = 1;
   }
   int press_matrix = 0;
   if ( int_flags->matrix_groups[2] == pressure_only )
   {
      int_flags->numbers_of_equations[2] = 1;
      press_matrix = 2;
   }

   while (n_item != 0)
   {
      //  if there are concentration field equations.....
      if ( int_flags->mass_eqns == solve_mass )
      {
	 if (n_ptr->c_values == 0)
	 {
	    n_ptr->first_mass_eqn = int_flags->numbers_of_equations[0];
            int_flags->numbers_of_equations[0] += mass_dof;
	 }
	 else
	 {
	    n_ptr->first_mass_eqn = -current_fixed;
            for ( int nxt = 0; nxt < mass_dof; ++nxt )
	    {
	       n_ptr->c_values->constrained_number[nxt] =
                   -current_fixed - nxt;
	    }
	    current_fixed += mass_dof;
	 }
      }

      //  if there are temperature equations.....
      if ( int_flags->temp_eqns == solve_temp )
      {
	 if (n_ptr->t_values == 0)
	 {
	    n_ptr->first_temp_eqn = int_flags->numbers_of_equations[0];
            ++int_flags->numbers_of_equations[0];
	 }
	 else
	 {
	    n_ptr->first_temp_eqn = -current_fixed;
	    n_ptr->t_values->constrained_number[0] = -current_fixed;
	    ++current_fixed;
	 }
      }

      //  if there are velocity equations.....
      if ( int_flags->vel_eqns == solve_vel )
      {
	 // is node on particle surface?
         if ( n_ptr->is_node_in_particle ==  node_on_particle_surface ||
              n_ptr->is_node_in_particle ==  node_in_particle_box )
         {
            n_ptr->first_vel_eqn = n_ptr->get_first_part_eqn ( );
            if ( n_ptr->first_vel_eqn < 0 )
	    {
               n_ptr->v_values->constrained_number [0] = 
                   n_ptr->first_vel_eqn;
               n_ptr->v_values->constrained_number [1] = 
                   n_ptr->first_vel_eqn - 1;
               n_ptr->v_values->constrained_number [2] = 
                   n_ptr->first_vel_eqn - 2; 
	    }
	 }
         else
	 {      
	    if ( n_ptr->v_values == 0)
	    {
	       n_ptr->first_vel_eqn = 
                   int_flags->numbers_of_equations[vel_matrix];
	       int_flags->numbers_of_equations[vel_matrix] += 2;
               if ( vel_dof > 2 ) 
                   ++int_flags->numbers_of_equations[vel_matrix];
	    }
	    else
	    {
               // check for center of cylinder
               if ( n_ptr->center_mark == at_the_center )
	       {
                  n_ptr->first_vel_eqn = 
                     int_flags->numbers_of_equations[vel_matrix];;
	          int_flags->numbers_of_equations[vel_matrix] += 
                     vel_dof - 1;
                  n_ptr->center_eqn = -current_fixed;
                  n_ptr->v_values->constrained_number[0] = -current_fixed;
	          n_ptr->v_values->constrained_number[1] = 0;
                  n_ptr->v_values->constrained_number[2] = 0; 
                  ++current_fixed;
	       }
               else
	       {
                  n_ptr->first_vel_eqn = -current_fixed;
	          n_ptr->v_values->constrained_number[0] = 
                      -current_fixed;
	          n_ptr->v_values->constrained_number[1] = 
                      -current_fixed - 1;
                  current_fixed += 2;
                  if ( vel_dof > 2 )
	          {
	             n_ptr->v_values->constrained_number[2] = 
                        -current_fixed - 2; 
                     ++current_fixed;
	          }
	       }
	    }
	 }
         if ( int_flags->turb_eqns == solve_turb )
	 {
            if ( n_ptr->turbk_values == 0)
	    {
	       n_ptr->first_turbk_eqn = 
                   int_flags->numbers_of_equations[vel_matrix];
	       int_flags->numbers_of_equations[vel_matrix] += 1;
	       n_ptr->first_turbe_eqn = 
                   int_flags->numbers_of_equations[vel_matrix];
	       int_flags->numbers_of_equations[vel_matrix] += 1;
	    }
	    else
	    {
               n_ptr->first_turbk_eqn = -current_fixed;
               n_ptr->first_turbe_eqn = -current_fixed - 1;
	       n_ptr->turbk_values->constrained_number[0] = 
                      -current_fixed;
	       n_ptr->turbe_values->constrained_number[0] = 
                      -current_fixed - 1;
               current_fixed += 2;
	    }
	 }
      }

      //  if there are pressure equations.....
/*  pressure equation numbers are added at the element level (not the
    node level) in List::assign_pressure_eqn_numbers  )
*/

      //  if there are potential equations.....
      if ( int_flags->pot_eqns == solve_pot )
      {
	 if (n_ptr->pot_values == 0)
	 {
	    n_ptr->first_pot_eqn = int_flags->numbers_of_equations[0];
	    ++int_flags->numbers_of_equations[0];
	 }
	 else
	 {
	    n_ptr->first_pot_eqn = -current_fixed;
	    n_ptr->pot_values->constrained_number[0] = -current_fixed;
	    ++current_fixed;
	 }
      }
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
   }

   int_flags->number_of_field_fixed = current_fixed - 1;
   
}

void List::assign_pressure_eqn_numbers ( integration_flags* int_flags )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   int current_fixed = int_flags->number_of_field_fixed + 1;
   int press_matrix = 0;
   if ( int_flags->matrix_groups[2] == pressure_only )
   {
      int_flags->numbers_of_equations[2] = 1;
      press_matrix = 2;
   }

   while (e_item != 0 && e_ptr != 0 )
   {
      while ( (e_ptr->element_number < 0 || 
               e_ptr->is_it_a_special_particle_element == 
                     special_particle_element ) && e_item!= 0)
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
         if (e_item == 0) return;
      }

      // see if this element has constrained pressures
      if ( e_ptr->press_values == 0 )
      {
         // increment equation count and set equation number arrays
         e_ptr->first_press_eqn = 
            int_flags->numbers_of_equations[press_matrix];

         int_flags->numbers_of_equations[press_matrix] += 
            e_ptr->number_of_pressure_basis_fcns;

         for ( int j = 0; j < e_ptr->number_of_pressure_basis_fcns; ++j )
         {
            e_ptr->press_equation_numbers[j] = e_ptr->first_press_eqn + j;
         }
      }
      else
      {
         // constrained pressures: assign a negative number
         e_ptr->first_press_eqn = -current_fixed;
         current_fixed += e_ptr->number_of_pressure_basis_fcns;
         for ( int j = 0; j < e_ptr->number_of_pressure_basis_fcns; ++j )
         {
            e_ptr->press_equation_numbers[j] = e_ptr->first_press_eqn - j;
            e_ptr->press_values->constrained_number[j] = 
               e_ptr->first_press_eqn - j;
         }
      }
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
      while ( e_item != 0 && 
        e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
   }

   int_flags->number_of_field_fixed = current_fixed - 1;
}


void List::fill_equation_number_arrays ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0)
   { 
      while ( (e_ptr->element_number < 0 || 
              e_ptr->is_it_a_special_particle_element == 
                     special_particle_element) &&
              e_item!= 0)
      { 
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
         if (e_item == 0) return;
      }

      
      e_ptr->fill_equation_number_arrays ( );
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
   }
}

void List::check_vel_eqn_numbers ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0 )
   {
      while ( e_ptr->element_number < 0 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      for ( int nod=0; nod < 12; ++nod )
      {
	 cout << e_ptr->vel_equation_numbers[nod] << " ";
      }
      cout << "\n";
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
   }
   return;
}

Element* List::find_equivalent_quad ( Element* line_elem )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
  
   int nodes_found = 0;
   while (e_item != 0)
   {
      nodes_found = 0;
      // find the element that contains all of the nodes of this one
      if ( e_ptr->number_of_nodes <= line_elem->number_of_nodes )
      {
	 e_item = e_item->next;
	 if (e_item != 0) e_ptr = e_item->value;
	 continue;
      }
      for ( int nod=0; nod < line_elem->number_of_nodes; ++nod )
      {
	 int conn = line_elem->connectivity [nod];
	 for ( int nd=0; nd < e_ptr->number_of_nodes; ++nd )
	 {
	    if ( e_ptr->connectivity[nd] == conn )
	    {
		++nodes_found;
		break;
	    }
	 }
	 // if nodes_found is the same as (nod+1) keep going
	 if ( nodes_found < (nod+1) ) break;
      }
      if ( nodes_found == line_elem->number_of_nodes ) return e_ptr;
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;
      while ( e_item != 0 && 
         e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      } 
    }
    return line_elem;
}

void List::find_element_ptrs_from_element_numbers ( List* element_list )
{
   Item_Moving* m_item = top_moving;
   Moving_boundary_entity* m_ptr = top_moving->value;

   // assign element pointers to particles
   while ( m_item != 0 )
   {
      // loop through element numbers and get the corresponding pointer
      for ( int j = 0; j < m_ptr->elements_per_particle; ++j )
      {
         m_ptr->element_ptrs[j] =
	   element_list->find_element_ptr ( m_ptr->particle_elements[j] );
      }
      m_ptr->set_element_particle_pointers ( );
      m_item = m_item->next;
      if (m_item!=0) m_ptr = m_item->value;
   }
}

void List::set_up_eqn_arrays ( )
{
   Item_Moving* m_item = top_moving;
   Moving_boundary_entity* m_ptr = top_moving->value;
   while ( m_item != 0 )
   {
      m_ptr->set_up_eqn_arrays ( );
      m_item = m_item->next;
      if (m_item!=0) m_ptr = m_item->value;
   }
}

void List::display_element_list ( )
{
   cout << "this is the element display routine  \n";
   // loop through the linked list, calling element display
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0 )
   {
      while ( e_item != 0 && 
        e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      echo_data << "element number: " << e_ptr->element_number << "  ";
      for (int nod=0; nod < e_ptr->number_of_nodes; ++nod)
      {
	 echo_data << e_ptr->connectivity[nod] << " ";
      }
/*
      if ( e_ptr->element_particle_type == element_contains_particle )
      {
         cout << "print out the particle list: \n";
         for ( int k = 0; k < e_ptr->number_of_intersecting_particle_nodes; ++k )
         {
            cout << e_ptr->intersecting_particle_nodes[k]->node_number << "  ";
	 }
         cout << "\n";
      }
*/
      cout << "\n";
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;
      while ( e_item != 0 && 
         e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      } 
   }
}

void List::assign_shape_fcns ( )
{
   // loop through the linked list, calling element display
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0)
   {
      while ( e_ptr->element_number < 0 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      if ( e_ptr->element_particle_type == element_contains_particle )
         e_ptr->assign_shape_fcns ( );
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;
      while ( e_item != 0 && 
         e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      } 
   }
}

void List::display_initial_velocities ( )
{
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   while ( n_item != 0 )
   {
       cout << "node number: " << n_ptr->node_number << "  initial u and v: " << n_ptr->first_values->initial_u << "  " << n_ptr->first_values->initial_v << "  first_vel_eqn:  " << n_ptr->first_vel_eqn << "\n";
       n_item = n_item->next;
       if ( n_item != 0 ) n_ptr = n_item->value;
   }  
}

void List::display_node_list ( )
{
   // loop through the linked list, calling node display
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   while (n_item != 0)
   {
      echo_data << "node number: " << n_ptr->node_number << " ";
      echo_data << n_ptr->x_val << " " << n_ptr->y_val << " ";
      // show constrained values
      if (n_ptr->c_values != 0)
	 echo_data << "constrained_c: " << n_ptr->c_values->value[0] << " ";
      if (n_ptr->t_values != 0)
	 echo_data << "constrained_t: " << n_ptr->t_values->value[0] << " ";
      if (n_ptr->v_values != 0)
	 echo_data << "constrained_v: " << n_ptr->v_values->value[0] << " "
		   << n_ptr->v_values->value[1] << " " <<
		   n_ptr->v_values->constrained_number[0] << " " <<
		   n_ptr->v_values->constrained_number[1] << " ";
      if (n_ptr->pot_values != 0)
	 echo_data << "constrained_pot: " << n_ptr->pot_values->value[0] << " ";
      echo_data << "first_mass_number: " << n_ptr->first_mass_eqn << " ";
      echo_data << "first_temp_number: " << n_ptr->first_temp_eqn << " ";
      echo_data << "first_pot_number: " << n_ptr->first_pot_eqn << " ";
      echo_data << n_ptr->first_values->initial_t << " " <<
		   n_ptr->first_values->initial_u << " " <<
                   n_ptr->first_values->initial_v << " " <<
                   n_ptr->first_values->initial_pot << " ";
      echo_data << "\n";
      n_item = n_item->next;
      if (n_item != 0) n_ptr = n_item->value;
   }
}

void List::print_post_processor ( integration_flags* int_flags )
{
  cout << "start of print_post_processor: " << endl;
   // each node currently holds a structure containing an updated version of
   // its own set of solutions  - in nodal_solutions
   myvar value1, value2, value3;
   post_data.precision(12);
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   int mass_degrees_of_freedom = int_flags->mass_degrees_of_freedom;
   int vel_degrees_of_freedom = int_flags->vel_degrees_of_freedom;
   int surf_degrees_of_freedom = int_flags->surf_degrees_of_freedom;
   int mass_eqn, vel_eqn, surf_eqn, turbk_eqn, turbe_eqn;
   while (n_item != 0 )
   {
      // first print out x and y values
      cout << n_ptr->x_val << "   " << n_ptr->y_val << "   ";
      post_data << n_ptr->x_val << "   " << n_ptr->y_val << "   ";
      if ( int_flags->mass_eqns == solve_mass )
      {
         mass_eqn = n_ptr->first_mass_eqn;
         if ( mass_eqn > 0 )
         {
            for ( int nxt = 0; nxt < mass_degrees_of_freedom; ++nxt )
            { 
               if ( int_flags->con_logs == dont_take_logs )
                  post_data << n_ptr->nodal_solutions->conc[nxt] << "  ";
               else
                  post_data << exp (n_ptr->nodal_solutions->conc[nxt]) << "  ";
	    }
	 }
         else
	 {
            for ( int nxt = 0; nxt < mass_degrees_of_freedom; ++nxt )
            { 
               value1 = n_ptr->get_constrained_value
               ( mass_eqn-nxt, concentration, int_flags  );
               if ( int_flags->con_logs == dont_take_logs )
                  post_data << value1 << "   ";
               else
                  post_data << exp (value1) << "   ";
            }
         }
      }

      if ( int_flags->temp_eqns == solve_temp )
      {
	 if ( n_ptr->first_temp_eqn > 0 )
            post_data << n_ptr->nodal_solutions->temp << "  ";
         else
	 {
            value1 = n_ptr->get_constrained_value
               ( n_ptr->first_temp_eqn, temperature, int_flags );
            post_data << value1 << "   ";
         }
      }

      if ( int_flags->vel_eqns == solve_vel )
      {
	cout << "node number: " << n_ptr->node_number << "  ";
         cout << n_ptr->nodal_solutions->vel[0] << "   "; 
         cout << n_ptr->nodal_solutions->vel[1] << endl;;
         // if this node is just defining particle structure:
         // do not print out info
	 vel_eqn = n_ptr->first_vel_eqn;

         // if this node is a particle node: velocity is the sum
         // of the translational and rotational velocity components

         // if it is inside a particle, no velocities get printed
         if ( n_ptr->print_flag == do_not_print )
         {
            value1 = 0.0;
            value2 = 0.0;
            post_data << value1 << "   ";
            post_data << value2 << "   ";
	 }
         else
         {
            if ( n_ptr->node_type == particle_node )
            {
               if ( vel_eqn > 0 )
               {
                  value1 = n_ptr->nodal_solutions->vel[0];
                  value2 = n_ptr->nodal_solutions->vel[1];
                  value3 = n_ptr->nodal_solutions->vel[2];
               }
               else
               {
		 cout << "asking it to print particle node: " << endl;
                  if (n_ptr->v_values != 0)
		  {
		    cout << "calling get constrained: " << vel_eqn << endl;
                     value1 = n_ptr->get_constrained_value
                       (n_ptr->v_values->constrained_number[0], velocity, int_flags );
                     value2 =  n_ptr->get_constrained_value
                       (n_ptr->v_values->constrained_number[1], velocity, int_flags );
                     value3 = n_ptr->get_constrained_value
                       (n_ptr->v_values->constrained_number[2], velocity, int_flags );
		  }
	       }
               if ( n_ptr->tangential_direction != 0 )
               { 
                  value1 += value3 * n_ptr->tangential_direction->direction[0];
                  value2 += value3 * n_ptr->tangential_direction->direction[1];
	       }

               post_data << value1 << "   ";
               post_data << value2 << "   ";
               // post_data << value3 << "   ";
	    }
            
            if ( n_ptr->node_type == piston_node || 
                 n_ptr->node_type == time_dep_bc_node )
            {
               value1 = 0.0;
               value2 = n_ptr->get_constrained_value ( -1, velocity, int_flags );

               post_data << value1 << "   ";
               post_data << value2 << "   ";
	    }

            if ( n_ptr->node_type != particle_node && 
                 n_ptr->node_type != piston_node && 
                 n_ptr->node_type != time_dep_bc_node)
            {
	       if ( vel_eqn > 0 )
	       {
                  if ( n_ptr->center_eqn < 0 )
	          {
                     value1 = n_ptr->get_constrained_value
                           ( n_ptr->center_eqn, velocity, int_flags );
                     post_data << value1 << "   ";
                     post_data << n_ptr->nodal_solutions->vel[1] << "  ";
                     if ( vel_degrees_of_freedom > 2 )
                        post_data << n_ptr->nodal_solutions->vel[2] << "  ";
	          }
                  else
	          {
                     post_data << n_ptr->nodal_solutions->vel[0] << "   "; 
                     post_data << n_ptr->nodal_solutions->vel[1] << "  ";
                     if ( vel_degrees_of_freedom > 2 )
                        post_data << n_ptr->nodal_solutions->vel[2] << "  ";
	          }
	       }
               else
	       {
                  value1 = n_ptr->get_constrained_value
                       (vel_eqn, velocity, int_flags );
                  post_data << value1 << "   ";
                  value2 = n_ptr->get_constrained_value
                       (vel_eqn-1, velocity, int_flags );
                  post_data << value2 << "   ";
                  if ( vel_degrees_of_freedom > 2 )
	          {
                     value3 = n_ptr->get_constrained_value
                          (vel_eqn-2, velocity, int_flags );
                     post_data << value3 << "   ";
		  }
	       }
               if ( int_flags->turb_eqns == solve_turb )
	       {
                  turbk_eqn = n_ptr->first_turbk_eqn;
                  turbe_eqn = n_ptr->first_turbe_eqn;
                  if ( turbk_eqn > 0 )
	          {
                     post_data << n_ptr->nodal_solutions->turbk << "   "; 
                     post_data << n_ptr->nodal_solutions->turbe << "  ";
		  }
                  else
		  {
                     value1 = n_ptr->get_constrained_value
                         (turbk_eqn, turbulence_k, int_flags );
                     post_data << value1 << "   ";
                     value2 = n_ptr->get_constrained_value
                        (turbe_eqn, turbulence_e, int_flags );
                     post_data << value2 << "   ";
		  }
	       }
	    }
         }
      }

      if ( int_flags->pot_eqns == solve_pot )
      {
	 if ( n_ptr->first_pot_eqn > 0 )
            post_data << n_ptr->nodal_solutions->pot << "  ";
         else
	 {
            value1 = n_ptr->get_constrained_value
              ( n_ptr->first_pot_eqn, potential, int_flags );
            post_data << value1 << "   ";
         }
      }

      if ( int_flags->surf_eqns == solve_surf )
      {
         surf_eqn = n_ptr->first_surf_eqn;
         if ( surf_eqn > 0 )
         {
            post_surf_data << n_ptr->x_val << "   " << n_ptr->y_val << "   ";
            for ( int nxt = 0; nxt < surf_degrees_of_freedom; ++nxt )
            {
               if ( int_flags->con_logs == dont_take_logs )
                  post_surf_data << n_ptr->nodal_solutions->surf_conc[nxt] << "  ";
               else
	       post_surf_data << exp (n_ptr->nodal_solutions->surf_conc[nxt]) << "  "; 
	    }
            post_surf_data << "\n";
	 }
         else
         {
            if ( surf_eqn < 0 )
	    {
               for ( int nxt = 0; nxt < surf_degrees_of_freedom; ++nxt )
               { 
                  value1 = n_ptr->get_constrained_value
                     (surf_eqn-nxt, surface_con, int_flags  );
                  if ( int_flags->con_logs == dont_take_logs )
                     post_surf_data << value1 << "  ";
                  else
                     post_surf_data << exp (value1) << "   ";
	       }
               post_surf_data << "\n";
            }
         }
      }
      post_data << "\n";
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
   }
}

void List::print_pressures ( )
{
   int eqn; myvar value;
   post_data.precision(12);
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0)
   {
      while ( e_ptr->element_number < 0 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      for ( int nxt = 0; nxt < e_ptr->number_of_pressure_basis_fcns; 
                       ++nxt )
      { 
         eqn  = e_ptr->press_equation_numbers[nxt];
	 if ( eqn > 0 )
            post_data << e_ptr->current_pressure[nxt] << "  ";
         else if ( eqn == 0 )
            post_data << 0.0 << "  ";
         else
	 {
            value = e_ptr->get_constrained_press_value ( eqn );
            post_data << value << "   ";
         }
      }
      post_data << endl;
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
      while ( e_item != 0 && 
         e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      } 
   }
}

void List::show_quad_numbers ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while ( e_item != 0 )
   {
      while ( e_ptr->element_number < 0 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      e_ptr->show_quad_numbers ( );
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
      while ( e_item != 0 && 
         e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      } 
   }
}

void List::reset_renumber_flags ( )
{
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   while (n_item != 0 )
   {
      n_ptr->renumber = node_is_not_renumbered;
      n_ptr->renumber_1d = node_is_not_renumbered;
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
   }
}

void List::store_current_eqn_numbers (integration_flags* int_flags )
{
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   while (n_item != 0 )
   {
      n_ptr->stored_eqn_numbers->stored_c = n_ptr->first_mass_eqn;
      n_ptr->stored_eqn_numbers->stored_t = n_ptr->first_temp_eqn;
      n_ptr->stored_eqn_numbers->stored_u = n_ptr->first_vel_eqn;
      if ( n_ptr->first_vel_eqn > 0 )
      {
         n_ptr->stored_eqn_numbers->stored_v = n_ptr->first_vel_eqn+1;
         if ( int_flags->coordinate_flag == cylindrical )
            n_ptr->stored_eqn_numbers->stored_w = n_ptr->first_vel_eqn+2;
      }
      else
      {
         n_ptr->stored_eqn_numbers->stored_v = n_ptr->first_vel_eqn+1;
         if ( int_flags->coordinate_flag == cylindrical )
            n_ptr->stored_eqn_numbers->stored_w = n_ptr->first_vel_eqn+2;
      }
      n_ptr->stored_eqn_numbers->stored_pot = n_ptr->first_pot_eqn;
      n_ptr->stored_eqn_numbers->stored_csurf = n_ptr->first_surf_eqn;
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
   }
}

void List::store_pressure_eqn_numbers ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;

   while (e_item != 0)
   {
      e_ptr->old_press_eqn = e_ptr->first_press_eqn;
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;
      while ( e_item != 0 && 
        e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
   }
}


void List::check_all_the_elements ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   cout << "start of check_all_the_elements " << endl; 
   while (e_item != 0)
   {
      if ( e_ptr == 0 )
	cout << "the next element is zero " << endl;
      else
      {
	cout << e_ptr->element_number << "  ";
      }
      e_item = e_item->next;
      if (e_item!=0) e_ptr = e_item->value;
   }
   cout << endl;
}

void List::update_nodes_with_solutions ( integration_flags* int_flags, 
   equation_groups matrix_group, myvar* current_soln )
{
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;

   while (n_item != 0 )
   {
      if ( n_ptr->first_mass_eqn > 0 && 
         (matrix_group == all_equations || matrix_group == temperature_only))
      {
         for ( int j = 0; j < int_flags->mass_degrees_of_freedom; ++j )
	 {
            n_ptr->nodal_solutions->conc[j] = current_soln[n_ptr->first_mass_eqn+j-1];
	 }
      }
      if ( n_ptr->first_temp_eqn > 0 &&  
         (matrix_group == all_equations || matrix_group == temperature_only))
      {
         n_ptr->nodal_solutions->temp = current_soln[n_ptr->first_temp_eqn-1];
      }
      if ( n_ptr->first_vel_eqn > 0 &&  
         (matrix_group == all_equations || matrix_group == velocity_only))
      {
         for ( int j = 0; j < int_flags->vel_degrees_of_freedom; ++j )
	 {
            n_ptr->nodal_solutions->vel[j] = current_soln[n_ptr->first_vel_eqn+j-1];
	 }
         if ( n_ptr->node_type == particle_node && 
              int_flags->vel_degrees_of_freedom < 3 ) 
            n_ptr->nodal_solutions->vel[2] = current_soln[n_ptr->first_vel_eqn+1];
      }
       if ( n_ptr->first_turbk_eqn > 0 &&  
         (matrix_group == all_equations || matrix_group == velocity_only))
      {
         n_ptr->nodal_solutions->turbk = current_soln[n_ptr->first_turbk_eqn-1];
         n_ptr->nodal_solutions->turbe = current_soln[n_ptr->first_turbe_eqn-1];
      }
      if ( n_ptr->first_pot_eqn > 0 &&  
         (matrix_group == all_equations || matrix_group == temperature_only))
      {
         n_ptr->nodal_solutions->pot = current_soln[n_ptr->first_pot_eqn-1];
      }
      if ( n_ptr->first_surf_eqn > 0 && 
         (matrix_group == all_equations || matrix_group == temperature_only))
      {
         for ( int j = 0; j < int_flags->surf_degrees_of_freedom; ++j )
	 {
            n_ptr->nodal_solutions->surf_conc[j] = current_soln[n_ptr->first_surf_eqn+j-1];
	 }
      }
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
   }
}

void List::update_elements_with_solutions ( myvar* current_soln )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   cout << "start of update_elements_with_solutions: ppppppppppppppppppppppppppp " << endl;
   while (e_item != 0)
   {
      while ( (e_ptr->element_number < 0 || 
               e_ptr->is_it_a_special_particle_element == 
                     special_particle_element || 
               e_ptr->dimension == 1) && e_item!= 0)
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
         if (e_item == 0) return;
      }

      for ( int j = 0; j < e_ptr->number_of_pressure_basis_fcns; ++j )
      {
         if ( e_ptr->first_press_eqn > 0 )
	 {
            e_ptr->current_pressure[j] = 
               current_soln[e_ptr->first_press_eqn+j-1];

            if ( j == 0 )
               e_ptr->current_pressure[j] += e_ptr->base_pressure;
	 }
         else
	 {
            e_ptr->current_pressure[j] = e_ptr->get_constrained_press_value ( e_ptr->first_press_eqn+j-1 ); 
	 }
      }
      if ( e_ptr->element_number == 3 ) cout << "new pressure 3: " << e_ptr->current_pressure[0] << endl;
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;
      while ( e_item != 0 && 
        e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
   }
}

myvar List::compute_work_term ( )
{
   myvar total_work = 0.0;
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0)
   {
      while ( e_ptr->element_number < 0 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      if ( e_ptr->dimension == 2 )
         total_work += e_ptr->compute_work_term ( );
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;
   }

   return ( total_work );
}

void List::save_old_pressures ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0)
   {
      while ( e_ptr->element_number < 0 || e_ptr->dimension == 1 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
         if ( e_item == 0 ) continue;
      }

      if ( e_item == 0 ) continue;
      e_ptr->old_pressure = e_ptr->current_pressure[0];
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;
      while ( e_item != 0 && 
        e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
   }
}

void List::run_through_the_nodes ( )
{
      Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   int node_number = n_ptr->node_number;
   while (n_item != 0 )
   {
     if ( node_number > 500 ) cout << " node: " << node_number << "  ";
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
      if (n_item != 0) node_number = n_ptr->node_number;
   }
   cout << endl;
}

void List::find_562 ( )
{
  cout << "start of find_562: " << endl;
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0)
   {
      if (e_ptr->element_number == 562 )
      {
	cout << "found 562 " << endl;
        cout << "press_equations: " << e_ptr->press_equation_numbers << "  " << e_ptr->press_equation_numbers[0] << endl;
      }
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;
   }
}

void List::check_deriv ( ) 
{
   cout << "start of check_deriv: ";
   Element* e_ptr = top_element->value;
   cout << " top deriv: " << e_ptr->deriv << endl;
}
