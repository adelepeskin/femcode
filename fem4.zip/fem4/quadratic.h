#ifndef QUADRATIC_H
#define QUADRATIC_H

#include "property_model.h"
#include "mytypes.h"

// FORTRAN iterative-solver interface
extern "C"
{
   myvar quad_solver_ ( myvar*, myvar*, myvar* );
   myvar find_b_ ( myvar* );
   myvar find_dbdt_ ( myvar* );
}

class quadratic: public Property_model
{
   friend class Element;
   public:
      quadratic ( density_models, model_types );
      myvar find_density ( myvar, myvar );
      myvar find_dp_dt ( myvar, myvar );
      myvar find_enthalpy ( myvar, myvar, myvar );
   protected:
};

#endif
