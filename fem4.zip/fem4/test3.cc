#include <stdio.h>
#include <fstream.h>
#include <math.h>

double max ( double first, double second )
{
   if ( first > second ) return first;
   return second;
}
int min ( int first, int second )
{
   if ( first < second ) return first;
   return second;
}

int max ( int first, int second )
{
   if ( first > second ) return first;
   return second;
}
double dot_product ( double* vector_a, double* vector_b, int length )
{
   double product = 0.0;
   if ( length < 1 ) return product;
   printf("starting point: %f %f\n",vector_a[0],vector_b[0]);
   for ( int cnt = 0; cnt < length; cnt++ )
   {
      product += vector_a [cnt] * vector_b [cnt];
      printf("prod: %f  a: %f   b: %f\n",product,vector_a[cnt],vector_b[cnt]);
   }
   printf("length: %d, product: %f\n",length,product);
   return product;
}

int main( int argc, char** argv )
{
  // set up the solver
  double* matrix = new double[16];
  for (int i = 0; i < 16; ++i) {
    matrix[i] = 1.0;
  }
  matrix[0] = 2.0;
  matrix[3] = 2.0;
  matrix[8] = 2.0;
  matrix[15] = 2.0;

  int* left = new int[4];
  int* diag = new int[4];

  left[0] = 0;
  left[1] = 1;
  left[2] = 2;
  left[3] = 3;

  diag[0] = 0;
  diag[1] = 3;
  diag[2] = 8;
  diag[3] = 15;

  int number_of_equations = 4;
  double* solution = new double[4];
  double* delta_soln = new double[4];
  double* rhs = new double[4];
  rhs[0] = 5.0;
  rhs[1] = 5.0;
  rhs[2] = 5.0;
  rhs[3] = 5.0;
  delta_soln[0] = 0.0;
  delta_soln[1] = 0.0;
  delta_soln[2] = 0.0;
  delta_soln[3] = 0.0;
  solution[0] = 1.0;
  solution[1] = 1.0;
  solution[2] = 1.0;
  solution[3] = 1.0;
  int matrix_size = 16;
  double machine_zero = 1.0e-10;

   // this solver will find the difference between the current_soln
   // and the next guess
   // store the current solution in dela_soln and add on the
   // calculated delta at the end
   for ( int q = 0; q < number_of_equations; ++q )
     {
      delta_soln[q] = solution[q];
     }
   int row_last_diag = 0;  int col_last_diag = 0;
   int row_top = 0;        int col_top = 0;
   int row_diag = 0;       int col_diag = 0;
   int row_left = 0;       int col_left = 0;
   int row_start_left = 0; int col_start_left = 0;
   int row_start_top = 0;  int col_start_top = 0;
   int first = 0;
   int overlap_starts = 0; int col_pt = 0;
   int row_pt1 = 0;        int row_pt2 = 0;
   double hold;             int diff = 0;
   int first_one;          int last_one;
   int first_sub;          int last_sub;
   int current_memory = 16;
   int check_first;        int check_last;
   int memory_size;
   solution = rhs; 
   int number_of_blocks = 1;

   // loop over the number of matrix blocks needed
   //for ( int block = 0; block < number_of_blocks; ++ block )
   //{
   first_one = 0;
   last_one = 3;
   int block = 0;
   
   // loop on subordinate blocks
   memory_size = 0;
   int sub = 0;
   first_sub = 0;
   last_sub = 15;
   row_diag = 0;
       
   for ( int row = 0; row < 4; ++row ) {
     if ( row == 0 ) continue;
     if ( diag[row] < diag[row-1] )
       row_last_diag = -1;
     else
       row_last_diag = diag[row-1];
     row_diag = diag [row];
     row_left = left [row];
     if ( (row+1) == first_one )
       row_top = (row_diag) - row_left;
     else
       row_top = (row_diag - row_last_diag) - row_left - 1;
     
     row_start_left = row + 1 - row_left;
     row_start_top = row + 1 - row_top;
     // see if this subblock is used here
     check_first = max ( first_sub-1,
			 min(row_start_left,row_start_top)-1 );
     check_last = min ( row, last_sub );
     
     if ( check_first <= check_last ) {
       for ( int col = check_first; col < check_last; ++col ) {
	 if ( col <= 1 )
	   col_last_diag = 0;
	 else {
	   if ((col+1) == first_sub  )
	     col_last_diag = -1;
	   else
	     col_last_diag = diag [col-1];
	 }
	 col_diag = diag [col];
	 col_left = left [col];
	 col_top = 0;
	 col_start_left = 0;
	 col_start_top = 0;
	 if ( col > 0 ) {
	   col_top = (col_diag - col_last_diag) - col_left - 1;
	   col_start_left = col + 1 - col_left;
	   col_start_top = col + 1 - col_top;
	 }
		   
	 // find matrix ( row, col )
	 if ( row_start_left <= (col+1) ) {
	   overlap_starts = max ( row_start_left, col_start_top );
	   col_pt = col_diag - ( (col+1) - overlap_starts );
	   row_pt1 = row_diag - row_top - ( row - col );
	   row_pt2 = row_diag - row_top -
	     ( (row+1) - overlap_starts );
	   hold = 0.0;
	   if ( col_pt > -1 ) {
	     diff = col + 1 - overlap_starts;
	     if ( diff > 0 ) hold = dot_product
	       (&matrix[row_pt2], &matrix[col_pt], diff );
	   }
	   matrix [row_pt1] =
	     ( matrix[row_pt1] - hold ) / matrix[col_diag];
	   if ( number_of_blocks > 1 && block == sub )
	     matrix [row_pt1] = matrix [row_pt1];
	   printf("update matrix 1 at %d: %f\n",row_pt1,matrix[row_pt1]);
	 }
		   
	 // find matrix ( col, row )
	 if ( row_start_top <= (col+1) ) {
	   overlap_starts = max ( row_start_top, col_start_left );
	   col_pt = col_diag - col_top -
	     ( (col+1) - overlap_starts );
	   row_pt1 = row_diag - ( row - col );
	   row_pt2 = row_diag - ( (row+1) - overlap_starts );
	   hold = 0.0;
	   if ( col_pt > -1 ) {
	     diff = col + 1 - overlap_starts;
	     if ( diff > 0 ) hold = dot_product
	       ( &matrix[col_pt], &matrix[row_pt2], diff );
	     matrix [row_pt1] = matrix [row_pt1] - hold;
	     if ( number_of_blocks > 1 && block == sub )
	       matrix [row_pt1] = matrix [row_pt1];
	   printf("update matrix 2 at %d: %f\n",row_pt1,matrix[row_pt1]);
	   }
	 }
       }
     }
     printf("point a\n");
               
     // find matrix ( row, row )
     overlap_starts = max ( row_start_left, row_start_top );
     row_pt1 = row_diag - row_top - ( (row+1) - overlap_starts );
     row_pt2 = row_diag - ( (row+1) - overlap_starts );
     hold = 0.0;
     diff = row + 1 - overlap_starts;
     if ( diff > 0 ) hold = dot_product
       ( &matrix[row_pt1], &matrix[row_pt2], diff);
     matrix [row_diag] = matrix [row_diag] - hold;
     if ( number_of_blocks > 1 )
       matrix [row_diag] = matrix [row_diag];
     printf("update matrix 3 at %d: %f\n",row_diag,matrix[row_diag]);
     
     // check for zero pivot
     if (fabs(matrix[row_diag]) <= machine_zero) {
       printf("zero pivot on row: %d\n",row);
       // matrix[row_diag] = machine_zero;
       break;
     }
	   
     // reduce the right hand side
     row_pt1 = row_diag - row_top - ( (row+1) - row_start_left );
     hold = 0.0;
     diff = row + 1 - row_start_left;
     if ( diff > 0 ) hold = dot_product ( &matrix[row_pt1],
					  &solution[row_start_left-1], diff );
     solution [row] = rhs [row] - hold;
   }

   printf("point b\n");
   // second loop on blocks
   block = 0;
   first_one = 0;
   last_one = 15;
   
   printf("matrix before back substitution: \n");
   for (int kk = 0; kk < 16; ++kk) {
     printf(" %f ",matrix[kk]);
   }
   printf("\n");

   // back substitution to find the solution
   int row_above = last_one - 1;
   int diag_above = diag[row_above];
   int row_pt;
   for ( int row = 3; row >= 0; --row ) {
     ++row_above;
     row_diag = diag [ row ];
     row_left = left [ row ];
     if ( row == 0 ) 
       diag_above = 0;
     else {
       if ( (row+1) == first_one )
	 diag_above = -1;
       else
	 diag_above = diag [ row-1 ];
     }
     row_top = (row_diag - diag_above) - row_left - 1;
     row_start_top = row + 1 - row_top;
     solution [row] = solution [row] / matrix [ row_diag ];
     if ( row_start_top <= row_above ) {
       row_pt = row_diag - row_top;
       for ( int place = row_start_top-1; place < row; ++place ) {   
	 solution [place] = solution [place]
	   - matrix [row_pt] * solution [row];
	 ++row_pt;
       }
     }
   }

   printf("point7: solution: \n");
   // add the delta solution found onto the current guess of the solution
   for ( int q = 0; q < number_of_equations; ++q ) {
     printf("solution: %f\n",solution[q]);
   }
}

