#include "mytypes.h"
#include "el.h"
#include "el-2d.h"
#include <fstream.h>

void four_node_element::find_derivatives_with_particles ( )
{
   // find shape functions for elements depending upon which sides 
   // contain the particle nodes

   // this function assumes the element will have two boundary node 
   // points along a side
   myvar sum = 0.0;

   // start with all 4 corners as bilinear functions: subtract midside
   // quadratric functions off according to each of 6 node locations:
   deriv->shape[0] = (-1.0/2.0)*(point_s-1.0)*
	             (-1.0/2.0)*(point_t-1.0);
   deriv->shape[1] = ( 1.0/2.0)*(point_s+1.0)*
                     (-1.0/2.0)*(point_t-1.0);
   deriv->shape[2] = ( 1.0/2.0)*(point_s+1.0)*
                     ( 1.0/2.0)*(point_t+1.0);
   deriv->shape[3] = (-1.0/2.0)*(point_s-1.0)*
	             ( 1.0/2.0)*(point_t+1.0);

   // local derivatives
   deriv->local_deriv_s[0] = (-1.0/2.0)*
                             (-1.0/2.0)*(point_t-1.0);
   deriv->local_deriv_s[1] = ( 1.0/2.0)*
                             (-1.0/2.0)*(point_t-1.0);
   deriv->local_deriv_s[2] = ( 1.0/2.0)*
                             ( 1.0/2.0)*(point_t+1.0);
   deriv->local_deriv_s[3] = (-1.0/2.0)*
	                     ( 1.0/2.0)*(point_t+1.0);

   deriv->local_deriv_t[0] = (-1.0/2.0)*(point_s-1.0)*
                             (-1.0/2.0);
   deriv->local_deriv_t[1] = ( 1.0/2.0)*(point_s+1.0)*
                             (-1.0/2.0);
   deriv->local_deriv_t[2] = ( 1.0/2.0)*(point_s+1.0)*
                             ( 1.0/2.0);
   deriv->local_deriv_t[3] = (-1.0/2.0)*(point_s-1.0)*
	                     ( 1.0/2.0);

   if ( sides_for_particle == one_and_two )
   {
      if ( point_s < pval )
         deriv->shape[4] = - (0.5)*(point_t-1.0)*(point_s+1.0)/(pval+1.0);
      else
         deriv->shape[4] = - (0.5)*(point_t-1.0)*(point_s-1.0)/(pval-1.0); 

      if ( point_t < qval )
         deriv->shape[5] =   (0.5)*(point_s+1.0)*(point_t+1.0)/(qval+1.0);
      else
         deriv->shape[5] =   (0.5)*(point_s+1.0)*(point_t-1.0)/(qval-1.0); 
      
      fract_p = (1.0 - pval)/2.0;
      deriv->shape[0] -= fract_p * deriv->shape[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[1] -= fract_q * deriv->shape[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[2] -= fract_q * deriv->shape[5];
      
      // local derivatives
      if ( point_s < pval )
         deriv->local_deriv_s[4] = - (0.5)*(point_t-1.0)/(pval+1.0);
      else
         deriv->local_deriv_s[4] = - (0.5)*(point_t-1.0)/(pval-1.0);
      if ( point_t < qval )
         deriv->local_deriv_s[5] =   (0.5)*(point_t+1.0)/(qval+1.0);
      else
         deriv->local_deriv_s[5] =   (0.5)*(point_t-1.0)/(qval-1.0);
      
      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_s[0] -= fract_p * deriv->local_deriv_s[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_s[1] -= fract_q * deriv->local_deriv_s[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_s[2] -= fract_q * deriv->local_deriv_s[5];
      
      if ( point_s < pval )
         deriv->local_deriv_t[4] = - (0.5)*(point_s+1.0)/(pval+1.0);
      else
         deriv->local_deriv_t[4] = - (0.5)*(point_s-1.0)/(pval-1.0);
      if ( point_t < qval )
         deriv->local_deriv_t[5] =   (0.5)*(point_s+1.0)/(qval+1.0);
      else
         deriv->local_deriv_t[5] =   (0.5)*(point_s+1.0)/(qval-1.0);

      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_t[0] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4]; 
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_t[1] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_t[2] -= fract_q * deriv->local_deriv_t[5];
   }

   if ( sides_for_particle == one_and_three )
   {
      // pval is on side one, qval is on side three
      if ( point_s < pval )
         deriv->shape[4] = - (0.5)*(point_t-1.0)*(point_s+1.0)/(pval+1.0);
      else
         deriv->shape[4] = - (0.5)*(point_t-1.0)*(point_s-1.0)/(pval-1.0); 

      if ( point_s < qval )
         deriv->shape[5] =   (0.5)*(point_t+1.0)*(point_s+1.0)/(qval+1.0);
      else
         deriv->shape[5] =   (0.5)*(point_t+1.0)*(point_s-1.0)/(qval-1.0); 
      
      fract_p = (1.0 - pval)/2.0;
      deriv->shape[0] -= fract_p * deriv->shape[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[2] -= fract_q * deriv->shape[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[5];

      // local derivatives
      if ( point_s < pval )
	deriv->local_deriv_s[4] = - (0.5)*(point_t-1.0)/(pval+1.0);
      else
         deriv->local_deriv_s[4] = - (0.5)*(point_t-1.0)/(pval-1.0);
      if ( point_s < qval )
         deriv->local_deriv_s[5] =   (0.5)*(point_t+1.0)/(qval+1.0);
      else
         deriv->local_deriv_s[5] =   (0.5)*(point_t+1.0)/(qval-1.0);

      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_s[0] -= fract_p * deriv->local_deriv_s[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_s[2] -= fract_q * deriv->local_deriv_s[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[5];

      if ( point_s < pval )
         deriv->local_deriv_t[4] = - (0.5)*(point_s+1.0)/(pval+1.0);
      else
         deriv->local_deriv_t[4] = - (0.5)*(point_s-1.0)/(pval-1.0);
      if ( point_s < qval )
         deriv->local_deriv_t[5] =   (0.5)*(point_s+1.0)/(qval+1.0);
      else
         deriv->local_deriv_t[5] =   (0.5)*(point_s-1.0)/(qval-1.0);

      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_t[0] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_t[2] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[5];
   }

   if ( sides_for_particle == one_and_four )
   {
      // pval is on side one, qval is on side four
      if ( point_s < pval )
         deriv->shape[4] = - (0.5)*(point_t-1.0)*(point_s+1.0)/(pval+1.0);
      else
         deriv->shape[4] = - (0.5)*(point_t-1.0)*(point_s-1.0)/(pval-1.0); 

      if ( point_t < qval )
         deriv->shape[5] = - (0.5)*(point_s-1.0)*(point_t+1.0)/(qval+1.0);
      else
         deriv->shape[5] = - (0.5)*(point_s-1.0)*(point_t-1.0)/(qval-1.0); 
      
      fract_p = (1.0 - pval)/2.0;
      deriv->shape[0] -= fract_p * deriv->shape[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[0] -= fract_q * deriv->shape[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[5];
      
      // local derivatives
      if ( point_s < pval )
	deriv->local_deriv_s[4] = - (0.5)*(point_t-1.0)/(pval+1.0);
      else
         deriv->local_deriv_s[4] = - (0.5)*(point_t-1.0)/(pval-1.0);
      if ( point_t < qval )
         deriv->local_deriv_s[5] = - (0.5)*(point_t+1.0)/(qval+1.0);
      else
         deriv->local_deriv_s[5] = - (0.5)*(point_t-1.0)/(qval-1.0);
      
      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_s[0] -= fract_p * deriv->local_deriv_s[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_s[0] -= fract_q * deriv->local_deriv_s[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[5];

      if ( point_s < pval )
	deriv->local_deriv_t[4] = - (0.5)*(point_s+1.0)/(pval+1.0);
      else
         deriv->local_deriv_t[4] = - (0.5)*(point_s-1.0)/(pval-1.0);
      if ( point_t < qval )
         deriv->local_deriv_t[5] = - (0.5)*(point_s-1.0)/(qval+1.0);
      else
         deriv->local_deriv_t[5] = - (0.5)*(point_s-1.0)/(qval-1.0);

      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_t[0] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_t[0] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[5];
   }
   
   if ( sides_for_particle == two_and_three )
   {
      // pval is on side 2, qval is on side three
      if ( point_t < pval )
         deriv->shape[4] =   (0.5)*(point_s+1.0)*(point_t+1.0)/(pval+1.0);
      else
         deriv->shape[4] =   (0.5)*(point_s+1.0)*(point_t-1.0)/(pval-1.0); 

      if ( point_s < qval )
         deriv->shape[5] =   (0.5)*(point_t+1.0)*(point_s+1.0)/(qval+1.0);
      else
         deriv->shape[5] =   (0.5)*(point_t+1.0)*(point_s-1.0)/(qval-1.0); 
      
      fract_p = (1.0 - pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[2] -= fract_p * deriv->shape[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[2] -= fract_q * deriv->shape[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[5]; 

      // local derivatives
      if ( point_t < pval )
         deriv->local_deriv_s[4] =   (0.5)*(point_t+1.0)/(pval+1.0);
      else
         deriv->local_deriv_s[4] =   (0.5)*(point_t-1.0)/(pval-1.0);
      if ( point_s < qval )
         deriv->local_deriv_s[5] =   (0.5)*(point_t+1.0)/(qval+1.0);
      else
         deriv->local_deriv_s[5] =   (0.5)*(point_t+1.0)/(qval-1.0);
      
      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_s[2] -= fract_p * deriv->local_deriv_s[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_s[2] -= fract_q * deriv->local_deriv_s[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[5];

      if ( point_t < pval )
         deriv->local_deriv_t[4] =   (0.5)*(point_s+1.0)/(pval+1.0);
      else
         deriv->local_deriv_t[4] =   (0.5)*(point_s+1.0)/(pval-1.0);
      if ( point_s < qval )
         deriv->local_deriv_t[5] =   (0.5)*(point_s+1.0)/(qval+1.0);
      else
         deriv->local_deriv_t[5] =   (0.5)*(point_s-1.0)/(qval-1.0);
      
      fract_p = (1.0 - qval)/2.0;
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + qval)/2.0;
      deriv->local_deriv_t[2] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_t[2] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[5];
   }

   if ( sides_for_particle == two_and_four )
   {
      // pval is on side 2, qval is on side four
      if ( point_t < pval )
         deriv->shape[4] =   (0.5)*(point_s+1.0)*(point_t+1.0)/(pval+1.0);
      else
         deriv->shape[4] =   (0.5)*(point_s+1.0)*(point_t-1.0)/(pval-1.0); 

      if ( point_t < qval )
         deriv->shape[5] = - (0.5)*(point_s-1.0)*(point_t+1.0)/(qval+1.0);
      else
         deriv->shape[5] = - (0.5)*(point_s-1.0)*(point_t-1.0)/(qval-1.0); 
      
      fract_p = (1.0 - pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[2] -= fract_p * deriv->shape[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[0] -= fract_q * deriv->shape[5];

      // local derivatives
      if ( point_t < pval )
         deriv->local_deriv_s[4] =   (0.5)*(point_t+1.0)/(pval+1.0);
      else
         deriv->local_deriv_s[4] =   (0.5)*(point_t-1.0)/(pval-1.0);
      if ( point_t < qval )
         deriv->local_deriv_s[5] = - (0.5)*(point_t+1.0)/(qval+1.0);
      else
         deriv->local_deriv_s[5] = - (0.5)*(point_t-1.0)/(qval-1.0);
      
      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_s[2] -= fract_p * deriv->local_deriv_s[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_s[0] -= fract_q * deriv->local_deriv_s[5];

      if ( point_t < pval )
         deriv->local_deriv_t[4] =   (0.5)*(point_s+1.0)/(pval+1.0);
      else
         deriv->local_deriv_t[4] =   (0.5)*(point_s+1.0)/(pval-1.0);
      if ( point_t < qval )
         deriv->local_deriv_t[5] = - (0.5)*(point_s-1.0)/(qval+1.0);
      else
         deriv->local_deriv_t[5] = - (0.5)*(point_s-1.0)/(qval-1.0);
      
      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_t[2] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_t[0] -= fract_q * deriv->local_deriv_t[5];
   }

   if ( sides_for_particle == three_and_four )
   {
      // pval is on side 3, qval is on side 4
      if ( point_s < pval )
         deriv->shape[4] =   (0.5)*(point_t+1.0)*(point_s+1.0)/(pval+1.0);
      else
         deriv->shape[4] =   (0.5)*(point_t+1.0)*(point_s-1.0)/(pval-1.0); 

      if ( point_t < qval )
         deriv->shape[5] = - (0.5)*(point_s-1.0)*(point_t+1.0)/(qval+1.0);
      else
         deriv->shape[5] = - (0.5)*(point_s-1.0)*(point_t-1.0)/(qval-1.0); 
      
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[2] -= fract_p * deriv->shape[4];
      fract_p = (1.0 - pval)/2.0;
      deriv->shape[3] -= fract_p * deriv->shape[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[0] -= fract_q * deriv->shape[5];
      
      // local derivatives
      if ( point_s < pval )
	 deriv->local_deriv_s[4] =   (0.5)*(point_t+1.0)/(pval+1.0);
       else
          deriv->local_deriv_s[4] =   (0.5)*(point_t+1.0)/(pval-1.0);
       if ( point_t < qval )
          deriv->local_deriv_s[5] = - (0.5)*(point_t+1.0)/(qval+1.0);
       else
          deriv->local_deriv_s[5] = - (0.5)*(point_t-1.0)/(qval-1.0);
      
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_s[2] -= fract_p * deriv->local_deriv_s[4];
      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_s[3] -= fract_p * deriv->local_deriv_s[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_s[0] -= fract_q * deriv->local_deriv_s[5];

      if ( point_s < pval )
	deriv->local_deriv_t[4] =   (0.5)*(point_s+1.0)/(pval+1.0);
      else
         deriv->local_deriv_t[4] =   (0.5)*(point_s-1.0)/(pval-1.0);
      if ( point_t < qval )
         deriv->local_deriv_t[5] = - (0.5)*(point_s-1.0)/(qval+1.0);
      else
         deriv->local_deriv_t[5] = - (0.5)*(point_s-1.0)/(qval-1.0);

      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_t[2] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_t[3] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_t[0] -= fract_q * deriv->local_deriv_t[5];
   }
   
   // if both extra points are on the same side, pval < qval 
   //(it is set that way in the element routines - el-2d.cc, etc.)

   // define points half way between the endpoints and p and q.
   myvar p1 = (pval-1.0)/2.0;
   myvar q1 = (qval+1.0)/2.0;
   myvar m1 = (mval+1.0)/2.0;
   myvar n1 = (nval+1.0)/2.0;
   if ( sides_for_particle == one_and_one )
   {
      if ( point_s <= p1 )
      {
         deriv->shape[4] = -(0.5)*(point_s+1.0)*(point_t-1.0)/(pval+1.0);
         deriv->shape[5] = (0.25)*(point_s+1.0)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_s[4] = -(0.5)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_s[5] = (0.25)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_t[4] = -(0.5)*(point_s+1.0)/(pval+1.0);
         deriv->local_deriv_t[5] = (0.25)*(point_s+1.0)/(pval+1.0);
      }
      
      if ( p1 <= point_s && point_s <= pval )
      {
         deriv->shape[4] =  -(0.5)*(point_s+1.0)*(point_t-1.0)/(pval+1.0);
         deriv->shape[5] = -(0.25)*(point_s-pval)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_s[4] = -(0.5)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_s[5] = -(0.25)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_t[4] = -(0.5)*(point_s+1.0)/(pval+1.0);
         deriv->local_deriv_t[5] = -(0.25)*(point_s-pval)/(pval+1.0);
      }
      if ( pval <= point_s && point_s <= qval )
      {
         deriv->shape[4] =  -(0.5)*(point_s-qval)*(point_t-1.0)/(pval-qval);
         deriv->shape[5] = (0.5)*(point_s-pval)*(point_t-1.0)/(pval-qval);
         deriv->local_deriv_s[4] = -(0.5)*(point_t-1.0)/(pval-qval);
         deriv->local_deriv_s[5] = (0.5)*(point_t-1.0)/(pval-qval);
         deriv->local_deriv_t[4] = -(0.5)*(point_s-qval)/(pval-qval);
         deriv->local_deriv_t[5] = (0.5)*(point_s-pval)/(pval-qval);
      }
      if ( qval <= point_s && point_s <= q1 )
      {
         deriv->shape[4] = -(0.25)*(point_s-qval)*(point_t-1.0)/(qval-1.0);
         deriv->shape[5] = -(0.5)*(point_s-1.0)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_s[4] = -(0.25)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_s[5] = -(0.5)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_t[4] = -(0.25)*(point_s-qval)/(qval-1.0);
         deriv->local_deriv_t[5] = -(0.5)*(point_s-1.0)/(qval-1.0);
      }
      if ( q1 <= point_s )
      {
         deriv->shape[4] =  (0.25)*(point_s-1.0)*(point_t-1.0)/(qval-1.0);
         deriv->shape[5] = -(0.5)*(point_s-1.0)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_s[4] = (0.25)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_s[5] = -(0.5)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_t[4] = (0.25)*(point_s-1.0)/(qval-1.0);
         deriv->local_deriv_t[5] = -(0.5)*(point_s-1.0)/(qval-1.0);
      }

      fract_p = (1.0 - pval)/2.0;
      deriv->shape[0] -= fract_p * deriv->shape[4];
      deriv->local_deriv_s[0] -= fract_p * deriv->local_deriv_s[4];
      deriv->local_deriv_t[0] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[0] -= fract_q * deriv->shape[5];
      deriv->local_deriv_s[0] -= fract_q * deriv->local_deriv_s[5];
      deriv->local_deriv_t[0] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[1] -= fract_q * deriv->shape[5];
      deriv->local_deriv_s[1] -= fract_q * deriv->local_deriv_s[5];
      deriv->local_deriv_t[1] -= fract_q * deriv->local_deriv_t[5];
   }

   if ( sides_for_particle == two_and_two )
   {
      if ( point_t <= p1 )
      {
         deriv->shape[4] = (0.5)*(point_t+1.0)*(point_s+1.0)/(pval+1.0);
         deriv->shape[5] = -(0.25)*(point_t+1.0)*(point_s+1.0)/(pval+1.0);
         deriv->local_deriv_s[4] = (0.5)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_s[5] = -(0.25)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_t[4] = (0.5)*(point_s+1.0)/(pval+1.0);
         deriv->local_deriv_t[5] = -(0.25)*(point_s+1.0)/(pval+1.0);
      }
      
      if ( p1 <= point_t && point_t <= pval )
      {
         deriv->shape[4] = (0.5)*(point_t+1.0)*(point_s+1.0)/(pval+1.0);
         deriv->shape[5] = (0.25)*(point_t-pval)*(point_s+1.0)/(pval+1.0);
         deriv->local_deriv_s[4] = (0.5)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_s[5] = (0.25)*(point_t-pval)/(pval+1.0);;
         deriv->local_deriv_t[4] = (0.5)*(point_s+1.0)/(pval+1.0);
         deriv->local_deriv_t[5] = (0.25)*(point_s+1.0)/(pval+1.0);
      }
      if ( pval <= point_t && point_t <= qval )
      {
         deriv->shape[4] = (0.5)*(point_t-qval)*(point_s+1.0)/(pval-qval);
         deriv->shape[5] = -(0.5)*(point_t-pval)*(point_s+1.0)/(pval-qval);
         deriv->local_deriv_s[4] = (0.5)*(point_t-qval)/(pval-qval);
         deriv->local_deriv_s[5] = -(0.5)*(point_t-pval)/(pval-qval);
         deriv->local_deriv_t[4] = (0.5)*(point_s+1.0)/(pval-qval);
         deriv->local_deriv_t[5] = -(0.5)*(point_s+1.0)/(pval-qval);
      }
      if ( qval <= point_t && point_t <= q1 )
      {
         deriv->shape[4] = (0.25)*(point_t-qval)*(point_s+1.0)/(qval-1.0);
         deriv->shape[5] = (0.5)*(point_t-1.0)*(point_s+1.0)/(qval-1.0);
         deriv->local_deriv_s[4] = (0.25)*(point_t-qval)/(qval-1.0);
         deriv->local_deriv_s[5] = (0.5)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_t[4] = (0.25)*(point_s+1.0)/(qval-1.0);
         deriv->local_deriv_t[5] = (0.5)*(point_s+1.0)/(qval-1.0);
      }
      if ( q1 <= point_t )
      {
         deriv->shape[4] = -(0.25)*(point_t-1.0)*(point_s+1.0)/(qval-1.0);
         deriv->shape[5] = (0.5)*(point_t-1.0)*(point_s+1.0)/(qval-1.0);
         deriv->local_deriv_s[4] = -(0.25)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_s[5] =  (0.5)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_t[4] = -(0.25)*(point_s+1.0)/(qval-1.0);
         deriv->local_deriv_t[5] = (0.5)*(point_s+1.0)/(qval-1.0);
      }

      fract_p = (1.0 - pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[2] -= fract_p * deriv->shape[4];
      deriv->local_deriv_s[2] -= fract_p * deriv->local_deriv_s[4];
      deriv->local_deriv_t[2] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[1] -= fract_q * deriv->shape[5];
      deriv->local_deriv_s[1] -= fract_q * deriv->local_deriv_s[5];
      deriv->local_deriv_t[1] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[2] -= fract_q * deriv->shape[5];
      deriv->local_deriv_s[2] -= fract_q * deriv->local_deriv_s[5];
      deriv->local_deriv_t[2] -= fract_q * deriv->local_deriv_t[5];
        
   }

   if ( sides_for_particle == three_and_three )
   {
      if ( point_s <= p1 )
      {
         deriv->shape[4] = (0.5)*(point_s+1.0)*(point_t+1.0)/(pval+1.0);
         deriv->shape[5] = -(0.25)*(point_s+1.0)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_s[4] = (0.5)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_s[5] = -(0.25)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_t[4] = (0.5)*(point_s+1.0)/(pval+1.0);
         deriv->local_deriv_t[5] = -(0.25)*(point_s+1.0)/(pval+1.0);
      }
      
      if ( p1 <= point_s && point_s <= pval )
      {
         deriv->shape[4] = (0.5)*(point_s+1.0)*(point_t+1.0)/(pval+1.0);
         deriv->shape[5] = (0.25)*(point_s-pval)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_s[4] = (0.5)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_s[5] = (0.25)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_t[4] = (0.5)*(point_s+1.0)/(pval+1.0);
         deriv->local_deriv_t[5] = (0.25)*(point_s-pval)/(pval+1.0);
      }
      if ( pval <= point_s && point_s <= qval )
      {
         deriv->shape[4] = (0.5)*(point_s-qval)*(point_t+1.0)/(pval-qval);
         deriv->shape[5] = -(0.5)*(point_s-pval)*(point_t+1.0)/(pval-qval);
         deriv->local_deriv_s[4] = (0.5)*(point_t+1.0)/(pval-qval);
         deriv->local_deriv_s[5] = -(0.5)*(point_t+1.0)/(pval-qval);
         deriv->local_deriv_t[4] = (0.5)*(point_s-qval)/(pval-qval);
         deriv->local_deriv_t[5] = -(0.5)*(point_s-pval)/(pval-qval);
      }
      if ( qval <= point_s && point_s <= q1 )
      {
         deriv->shape[4] = (0.25)*(point_s-qval)*(point_t+1.0)/(qval-1.0);
         deriv->shape[5] = (0.5)*(point_s-1.0)*(point_t+1.0)/(qval-1.0);
         deriv->local_deriv_s[4] = (0.25)*(point_t+1.0)/(qval-1.0);
         deriv->local_deriv_s[5] = (0.5)*(point_t+1.0)/(qval-1.0);
         deriv->local_deriv_t[4] = (0.25)*(point_s-qval)/(qval-1.0);
         deriv->local_deriv_t[5] = (0.5)*(point_s-1.0)/(qval-1.0);
      }
      if ( q1 <= point_s )
      {
         deriv->shape[4] = -(0.25)*(point_s-1.0)*(point_t+1.0)/(qval-1.0);
         deriv->shape[5] = (0.5)*(point_s-1.0)*(point_t+1.0)/(qval-1.0);
         deriv->local_deriv_s[4] = -(0.25)*(point_t+1.0)/(qval-1.0);
         deriv->local_deriv_s[5] = (0.5)*(point_t+1.0)/(qval-1.0);
         deriv->local_deriv_t[4] = -(0.25)*(point_s-1.0)/(qval-1.0);
         deriv->local_deriv_t[5] = (0.5)*(point_s-1.0)/(qval-1.0);
      }

      fract_p = (1.0 - pval)/2.0;
      deriv->shape[3] -= fract_p * deriv->shape[4];
      deriv->local_deriv_s[3] -= fract_p * deriv->local_deriv_s[4];
      deriv->local_deriv_t[3] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[2] -= fract_p * deriv->shape[4];
      deriv->local_deriv_s[2] -= fract_p * deriv->local_deriv_s[4];
      deriv->local_deriv_t[2] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[5];
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[5];
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[2] -= fract_q * deriv->shape[5];
      deriv->local_deriv_s[2] -= fract_q * deriv->local_deriv_s[5];
      deriv->local_deriv_t[2] -= fract_q * deriv->local_deriv_t[5];
   }

   if ( sides_for_particle == four_and_four )
   {
      if ( point_t <= p1 )
      {
         deriv->shape[4] = -(0.5)*(point_t+1.0)*(point_s-1.0)/(pval+1.0);
         deriv->shape[5] =-(0.25)*(point_t+1.0)*(point_s-1.0)/(pval+1.0);
         deriv->local_deriv_s[4] = -(0.5)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_s[5] = (0.25)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_t[4] = -(0.5)*(point_s-1.0)/(pval+1.0);
         deriv->local_deriv_t[5] = (0.25)*(point_s-1.0)/(pval+1.0);
      }
      
      if ( p1 <= point_t && point_t <= pval )
      {
         deriv->shape[4] = -(0.5)*(point_t+1.0)*(point_s-1.0)/(pval+1.0);
         deriv->shape[5] = -(0.25)*(point_t-pval)*(point_s-1.0)/(pval+1.0);
         deriv->local_deriv_s[4] = -(0.5)*(point_t+1.0)/(pval+1.0);
         deriv->local_deriv_s[5] = -(0.25)*(point_t-pval)/(pval+1.0);
         deriv->local_deriv_t[4] = -(0.5)*(point_s-1.0)/(pval+1.0);
         deriv->local_deriv_t[5] = -(0.25)*(point_s-1.0)/(pval+1.0);
      }
      if ( pval <= point_t && point_t <= qval )
      {
         deriv->shape[4] = -(0.5)*(point_t-qval)*(point_s-1.0)/(pval-qval);
         deriv->shape[5] = (0.5)*(point_t-pval)*(point_s-1.0)/(pval-qval);
         deriv->local_deriv_s[4] = -(0.5)*(point_t-qval)/(pval-qval);
         deriv->local_deriv_s[5] = (0.5)*(point_t-pval)/(pval-qval);
         deriv->local_deriv_t[4] = -(0.5)*(point_s-1.0)/(pval-qval);
         deriv->local_deriv_t[5] = (0.5)*(point_s-1.0)/(pval-qval);
      }
      if ( qval <= point_t && point_t <= q1 )
      {
         deriv->shape[4] = -(0.25)*(point_t-qval)*(point_s-1.0)/(qval-1.0);
         deriv->shape[5] = -(0.5)*(point_t-1.0)*(point_s-1.0)/(qval-1.0);
         deriv->local_deriv_s[4] = -(0.25)*(point_t-qval)/(qval-1.0);
         deriv->local_deriv_s[5] = -(0.5)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_t[4] = -(0.25)*(point_s-1.0)/(qval-1.0);
         deriv->local_deriv_t[5] = -(0.5)*(point_s-1.0)/(qval-1.0);
      }
      if ( q1 <= point_t )
      {
         deriv->shape[4] =  (0.25)*(point_t-1.0)*(point_s-1.0)/(qval-1.0);
         deriv->shape[5] = -(0.5)*(point_t-1.0)*(point_s-1.0)/(qval-1.0);
         deriv->local_deriv_s[4] =  (0.25)*(1.0-point_t)/(qval-1.0);
         deriv->local_deriv_s[5] = -(0.5)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_t[4] =  (0.25)*(point_s-1.0)/(qval-1.0);
         deriv->local_deriv_t[5] = -(0.5)*(point_s-1.0)/(qval-1.0);
      }

      fract_p = (1.0 - pval)/2.0;
      deriv->shape[0] -= fract_p * deriv->shape[4];
      deriv->local_deriv_s[0] -= fract_p * deriv->local_deriv_s[4];
      deriv->local_deriv_t[0] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[3] -= fract_p * deriv->shape[4];
      deriv->local_deriv_s[3] -= fract_p * deriv->local_deriv_s[4];
      deriv->local_deriv_t[3] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[0] -= fract_q * deriv->shape[5];
      deriv->local_deriv_s[0] -= fract_q * deriv->local_deriv_s[5];
      deriv->local_deriv_t[0] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[5];
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[5];
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[5];
   }

   if ( sides_for_particle == one_and_one_and_two_and_four )
   {
      // pval and qval on side 1
      if ( point_s <= p1 )
      {
         deriv->shape[4] = -(0.5)*(point_s+1.0)*(point_t-1.0)/(pval+1.0);
         deriv->shape[5] = (0.25)*(point_s+1.0)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_s[4] = -(0.5)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_s[5] = (0.25)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_t[4] = -(0.5)*(point_s+1.0)/(pval+1.0);
         deriv->local_deriv_t[5] = (0.25)*(point_s+1.0)/(pval+1.0);
      }
      
      if ( p1 <= point_s && point_s <= pval )
      {
         deriv->shape[4] =  -(0.5)*(point_s+1.0)*(point_t-1.0)/(pval+1.0);
         deriv->shape[5] = -(0.25)*(point_s-pval)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_s[4] = -(0.5)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_s[5] = -(0.25)*(point_t-1.0)/(pval+1.0);
         deriv->local_deriv_t[4] = -(0.5)*(point_s+1.0)/(pval+1.0);
         deriv->local_deriv_t[5] = -(0.25)*(point_s-pval)/(pval+1.0);
      }
      if ( pval <= point_s && point_s <= qval )
      {
         deriv->shape[4] =  -(0.5)*(point_s-qval)*(point_t-1.0)/(pval-qval);
         deriv->shape[5] = (0.5)*(point_s-pval)*(point_t-1.0)/(pval-qval);
         deriv->local_deriv_s[4] = -(0.5)*(point_t-1.0)/(pval-qval);
         deriv->local_deriv_s[5] = (0.5)*(point_t-1.0)/(pval-qval);
         deriv->local_deriv_t[4] = -(0.5)*(point_s-qval)/(pval-qval);
         deriv->local_deriv_t[5] = (0.5)*(point_s-pval)/(pval-qval);
      }
      if ( qval <= point_s && point_s <= q1 )
      {
         deriv->shape[4] = -(0.25)*(point_s-qval)*(point_t-1.0)/(qval-1.0);
         deriv->shape[5] = -(0.5)*(point_s-1.0)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_s[4] = -(0.25)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_s[5] = -(0.5)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_t[4] = -(0.25)*(point_s-qval)/(qval-1.0);
         deriv->local_deriv_t[5] = -(0.5)*(point_s-1.0)/(qval-1.0);
      }
      if ( q1 <= point_s )
      {
         deriv->shape[4] = (0.25)*(point_s-1.0)*(point_t-1.0)/(qval-1.0);
         deriv->shape[5] = -(0.5)*(point_s-1.0)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_s[4] = (0.25)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_s[5] = -(0.5)*(point_t-1.0)/(qval-1.0);
         deriv->local_deriv_t[4] = (0.25)*(point_s-1.0)/(qval-1.0);
         deriv->local_deriv_t[5] = -(0.5)*(point_s-1.0)/(qval-1.0);
      }

      fract_p = (1.0 - pval)/2.0;
      deriv->shape[0] -= fract_p * deriv->shape[4];
      deriv->local_deriv_s[0] -= fract_p * deriv->local_deriv_s[4];
      deriv->local_deriv_t[0] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[0] -= fract_q * deriv->shape[5];
      deriv->local_deriv_s[0] -= fract_q * deriv->local_deriv_s[5];
      deriv->local_deriv_t[0] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[1] -= fract_q * deriv->shape[5];
      deriv->local_deriv_s[1] -= fract_q * deriv->local_deriv_s[5];
      deriv->local_deriv_t[1] -= fract_q * deriv->local_deriv_t[5];


      // mval is on side 2, nval is on side 4
      if ( point_t < mval )
         deriv->shape[6] =   (0.5)*(point_s+1.0)*(point_t+1.0)/(mval+1.0);
      else
         deriv->shape[6] =   (0.5)*(point_s+1.0)*(point_t-1.0)/(mval-1.0); 

      if ( point_t < nval )
         deriv->shape[7] = - (0.5)*(point_s-1.0)*(point_t+1.0)/(nval+1.0);
      else
         deriv->shape[7] = - (0.5)*(point_s-1.0)*(point_t-1.0)/(nval-1.0); 
      
      fract_p = (1.0 - mval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[6];
      fract_p = (1.0 + mval)/2.0;
      deriv->shape[2] -= fract_p * deriv->shape[6];
      fract_q = (1.0 + nval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[7];
      fract_q = (1.0 - nval)/2.0;
      deriv->shape[0] -= fract_q * deriv->shape[7];

      // local derivatives
      if ( point_t < mval )
         deriv->local_deriv_s[6] =   (0.5)*(point_t+1.0)/(mval+1.0);
      else
         deriv->local_deriv_s[6] =   (0.5)*(point_t-1.0)/(mval-1.0);
      if ( point_t < nval )
         deriv->local_deriv_s[7] = - (0.5)*(point_t+1.0)/(nval+1.0);
      else
         deriv->local_deriv_s[7] = - (0.5)*(point_t-1.0)/(nval-1.0);
      
      fract_p = (1.0 - mval)/2.0;
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[6];
      fract_p = (1.0 + mval)/2.0;
      deriv->local_deriv_s[2] -= fract_p * deriv->local_deriv_s[6];
      fract_q = (1.0 + nval)/2.0;
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[7];
      fract_q = (1.0 - nval)/2.0;
      deriv->local_deriv_s[0] -= fract_q * deriv->local_deriv_s[7];

      if ( point_t < mval )
         deriv->local_deriv_t[6] =   (0.5)*(point_s+1.0)/(mval+1.0);
      else
         deriv->local_deriv_t[6] =   (0.5)*(point_s+1.0)/(mval-1.0);
      if ( point_t < nval )
         deriv->local_deriv_t[7] = - (0.5)*(point_s-1.0)/(nval+1.0);
      else
         deriv->local_deriv_t[7] = - (0.5)*(point_s-1.0)/(nval-1.0);
      
      fract_p = (1.0 - mval)/2.0;
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[6];
      fract_p = (1.0 + mval)/2.0;
      deriv->local_deriv_t[2] -= fract_p * deriv->local_deriv_t[6];
      fract_q = (1.0 + nval)/2.0;
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[7];
      fract_q = (1.0 - nval)/2.0;
      deriv->local_deriv_t[0] -= fract_q * deriv->local_deriv_t[7];
   }

   if ( sides_for_particle == two_and_two_and_one_and_three )
   {
      // pval on side 1, qval and mval on side 2, nval on side 3
      q1 = (qval-1.0)/2.0;
      m1 = (mval+1.0)/2.0;
      // this part is the same as in the two_and_two case
      // using qval and mval instead of pval and qval
      if ( point_t <= q1 )
      {
         deriv->shape[5] = (0.5)*(point_t+1.0)*(point_s+1.0)/(qval+1.0);
         deriv->shape[6] = -(0.25)*(point_t+1.0)*(point_s+1.0)/(qval+1.0);
         deriv->local_deriv_s[5] = (0.5)*(point_t+1.0)/(qval+1.0);
         deriv->local_deriv_s[6] = -(0.25)*(point_t+1.0)/(qval+1.0);
         deriv->local_deriv_t[5] = (0.5)*(point_s+1.0)/(qval+1.0);
         deriv->local_deriv_t[6] = -(0.25)*(point_s+1.0)/(qval+1.0);
      }
      
      if ( q1 <= point_t && point_t <= qval )
      {
         deriv->shape[5] = (0.5)*(point_t+1.0)*(point_s+1.0)/(qval+1.0);
         deriv->shape[6] = (0.25)*(point_t-qval)*(point_s+1.0)/(qval+1.0);
         deriv->local_deriv_s[5] = (0.5)*(point_t+1.0)/(qval+1.0);
         deriv->local_deriv_s[6] = (0.25)*(point_t-qval)/(qval+1.0);;
         deriv->local_deriv_t[5] = (0.5)*(point_s+1.0)/(qval+1.0);
         deriv->local_deriv_t[6] = (0.25)*(point_s+1.0)/(qval+1.0);
      }
      if ( qval <= point_t && point_t <= mval )
      {
         deriv->shape[5] = (0.5)*(point_t-mval)*(point_s+1.0)/(qval-mval);
         deriv->shape[6] = -(0.5)*(point_t-qval)*(point_s+1.0)/(qval-mval);
         deriv->local_deriv_s[5] = (0.5)*(point_t-mval)/(qval-mval);
         deriv->local_deriv_s[6] = -(0.5)*(point_t-qval)/(qval-mval);
         deriv->local_deriv_t[5] = (0.5)*(point_s+1.0)/(qval-mval);
         deriv->local_deriv_t[6] = -(0.5)*(point_s+1.0)/(qval-mval);
      }
      if ( mval <= point_t && point_t <= m1 )
      {
         deriv->shape[5] = (0.25)*(point_t-mval)*(point_s+1.0)/(mval-1.0);
         deriv->shape[6] = (0.5)*(point_t-1.0)*(point_s+1.0)/(mval-1.0);
         deriv->local_deriv_s[5] = (0.25)*(point_t-mval)/(mval-1.0);
         deriv->local_deriv_s[6] = (0.5)*(point_t-1.0)/(mval-1.0);
         deriv->local_deriv_t[5] = (0.25)*(point_s+1.0)/(mval-1.0);
         deriv->local_deriv_t[6] = (0.5)*(point_s+1.0)/(mval-1.0);
      }
      if ( m1 <= point_t )
      {
         deriv->shape[5] = -(0.25)*(point_t-1.0)*(point_s+1.0)/(mval-1.0);
         deriv->shape[6] = (0.5)*(point_t-1.0)*(point_s+1.0)/(mval-1.0);
         deriv->local_deriv_s[5] = -(0.25)*(point_t-1.0)/(mval-1.0);
         deriv->local_deriv_s[6] = (0.5)*(point_t-1.0)/(mval-1.0);
         deriv->local_deriv_t[5] = -(0.25)*(point_s+1.0)/(mval-1.0);
         deriv->local_deriv_t[6] = (0.5)*(point_s+1.0)/(mval-1.0);
      }

      fract_p = (1.0 - qval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[5];
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[5];
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[5];
      fract_p = (1.0 + qval)/2.0;
      deriv->shape[2] -= fract_p * deriv->shape[5];
      deriv->local_deriv_s[2] -= fract_p * deriv->local_deriv_s[5];
      deriv->local_deriv_t[2] -= fract_p * deriv->local_deriv_t[5];
      fract_q = (1.0 - mval)/2.0;
      deriv->shape[1] -= fract_q * deriv->shape[6];
      deriv->local_deriv_s[1] -= fract_q * deriv->local_deriv_s[6];
      deriv->local_deriv_t[1] -= fract_q * deriv->local_deriv_t[6];
      fract_q = (1.0 + mval)/2.0;
      deriv->shape[2] -= fract_q * deriv->shape[6];
      deriv->local_deriv_s[2] -= fract_q * deriv->local_deriv_s[6];
      deriv->local_deriv_t[2] -= fract_q * deriv->local_deriv_t[6];

      // this part is the same as in the one_and_three case
      // using pval and nval instead of pval and qval
      // pval is on side one, nval is on side three
      if ( point_s < pval )
         deriv->shape[4] = - (0.5)*(point_t-1.0)*(point_s+1.0)/(pval+1.0);
      else
         deriv->shape[4] = - (0.5)*(point_t-1.0)*(point_s-1.0)/(pval-1.0); 

      if ( point_s < nval )
         deriv->shape[7] =   (0.5)*(point_t+1.0)*(point_s+1.0)/(nval+1.0);
      else
         deriv->shape[7] =   (0.5)*(point_t+1.0)*(point_s-1.0)/(nval-1.0); 
      
      fract_p = (1.0 - pval)/2.0;
      deriv->shape[0] -= fract_p * deriv->shape[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      fract_q = (1.0 + nval)/2.0;
      deriv->shape[2] -= fract_q * deriv->shape[7];
      fract_q = (1.0 - nval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[7];

      // local derivatives
      if ( point_s < pval )
	deriv->local_deriv_s[4] = - (0.5)*(point_t-1.0)/(pval+1.0);
      else
         deriv->local_deriv_s[4] = - (0.5)*(point_t-1.0)/(pval-1.0);
      if ( point_s < nval )
         deriv->local_deriv_s[7] =   (0.5)*(point_t+1.0)/(nval+1.0);
      else
         deriv->local_deriv_s[7] =   (0.5)*(point_t+1.0)/(nval-1.0);

      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_s[0] -= fract_p * deriv->local_deriv_s[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      fract_q = (1.0 + nval)/2.0;
      deriv->local_deriv_s[2] -= fract_q * deriv->local_deriv_s[7];
      fract_q = (1.0 - nval)/2.0;
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[7];

      if ( point_s < pval )
         deriv->local_deriv_t[4] = - (0.5)*(point_s+1.0)/(pval+1.0);
      else
         deriv->local_deriv_t[4] = - (0.5)*(point_s-1.0)/(pval-1.0);
      if ( point_s < nval )
         deriv->local_deriv_t[7] =   (0.5)*(point_s+1.0)/(nval+1.0);
      else
         deriv->local_deriv_t[7] =   (0.5)*(point_s-1.0)/(nval-1.0);

      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_t[0] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 + nval)/2.0;
      deriv->local_deriv_t[2] -= fract_q * deriv->local_deriv_t[7];
      fract_q = (1.0 - nval)/2.0;
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[7];
   }

   if ( sides_for_particle == three_and_three_and_two_and_four )
   {
      // pval on side 2, qval and mval on side 3, nval on side 4
      q1 = (qval-1.0)/2.0;
      m1 = (mval+1.0)/2.0;
      // this part is the same as in the three_and_three case
      // using qval and mval instead of pval and qval

      if ( point_s <= q1 )
      {
         deriv->shape[5] = (0.5)*(point_s+1.0)*(point_t+1.0)/(qval+1.0);
         deriv->shape[6] = -(0.25)*(point_s+1.0)*(point_t+1.0)/(qval+1.0);
         deriv->local_deriv_s[5] = (0.5)*(point_t+1.0)/(qval+1.0);
         deriv->local_deriv_s[6] = -(0.25)*(point_t+1.0)/(qval+1.0);
         deriv->local_deriv_t[5] = (0.5)*(point_s+1.0)/(qval+1.0);
         deriv->local_deriv_t[6] = -(0.25)*(point_s+1.0)/(qval+1.0);
      }
      
      if ( q1 <= point_s && point_s <= qval )
      {
         deriv->shape[5] = (0.5)*(point_s+1.0)*(point_t+1.0)/(qval+1.0);
         deriv->shape[6] = (0.25)*(point_s-qval)*(point_t+1.0)/(qval+1.0);
         deriv->local_deriv_s[5] = (0.5)*(point_t+1.0)/(qval+1.0);
         deriv->local_deriv_s[6] = (0.25)*(point_t+1.0)/(qval+1.0);
         deriv->local_deriv_t[5] = (0.5)*(point_s+1.0)/(qval+1.0);
         deriv->local_deriv_t[6] = (0.25)*(point_s-qval)/(qval+1.0);
      }
      if ( qval <= point_s && point_s <= mval )
      {
         deriv->shape[5] = (0.5)*(point_s-mval)*(point_t+1.0)/(qval-mval);
         deriv->shape[6] = -(0.5)*(point_s-qval)*(point_t+1.0)/(qval-mval);
         deriv->local_deriv_s[5] = (0.5)*(point_t+1.0)/(qval-mval);
         deriv->local_deriv_s[6] = -(0.5)*(point_t+1.0)/(qval-mval);
         deriv->local_deriv_t[5] = (0.5)*(point_s-mval)/(qval-mval);
         deriv->local_deriv_t[6] = -(0.5)*(point_s-qval)/(qval-mval);
      }
      if ( mval <= point_s && point_s <= m1 )
      {
         deriv->shape[5] = (0.25)*(point_s-mval)*(point_t+1.0)/(mval-1.0);
         deriv->shape[6] = (0.5)*(point_s-1.0)*(point_t+1.0)/(mval-1.0);
         deriv->local_deriv_s[5] = (0.25)*(point_t+1.0)/(mval-1.0);
         deriv->local_deriv_s[6] = (0.5)*(point_t+1.0)/(mval-1.0);
         deriv->local_deriv_t[5] = (0.25)*(point_s-mval)/(mval-1.0);
         deriv->local_deriv_t[6] = (0.5)*(point_s-1.0)/(mval-1.0);
      }
      if ( m1 <= point_s )
      {
         deriv->shape[5] = -(0.25)*(point_s-1.0)*(point_t+1.0)/(mval-1.0);
         deriv->shape[6] = (0.5)*(point_s-1.0)*(point_t+1.0)/(mval-1.0);
         deriv->local_deriv_s[5] = -(0.25)*(point_t+1.0)/(mval-1.0);
         deriv->local_deriv_s[6] = (0.5)*(point_t+1.0)/(mval-1.0);
         deriv->local_deriv_t[5] = -(0.25)*(point_s-1.0)/(mval-1.0);
         deriv->local_deriv_t[6] = (0.5)*(point_s-1.0)/(mval-1.0);
      }

      fract_p = (1.0 - qval)/2.0;
      deriv->shape[3] -= fract_p * deriv->shape[5];
      deriv->local_deriv_s[3] -= fract_p * deriv->local_deriv_s[5];
      deriv->local_deriv_t[3] -= fract_p * deriv->local_deriv_t[5];
      fract_p = (1.0 + qval)/2.0;
      deriv->shape[2] -= fract_p * deriv->shape[5];
      deriv->local_deriv_s[2] -= fract_p * deriv->local_deriv_s[5];
      deriv->local_deriv_t[2] -= fract_p * deriv->local_deriv_t[5];
      fract_q = (1.0 - mval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[6];
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[6];
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[6];
      fract_q = (1.0 + mval)/2.0;
      deriv->shape[2] -= fract_q * deriv->shape[6];
      deriv->local_deriv_s[2] -= fract_q * deriv->local_deriv_s[6];
      deriv->local_deriv_t[2] -= fract_q * deriv->local_deriv_t[6];

      // this part is the same as in the two_and_four case
      // using pval and nval instead of pval and qval
      // pval is on side 2, nval is on side 4

      if ( point_t < pval )
         deriv->shape[4] =   (0.5)*(point_s+1.0)*(point_t+1.0)/(pval+1.0);
      else
         deriv->shape[4] =   (0.5)*(point_s+1.0)*(point_t-1.0)/(pval-1.0); 

      if ( point_t < nval )
         deriv->shape[7] = - (0.5)*(point_s-1.0)*(point_t+1.0)/(nval+1.0);
      else
         deriv->shape[7] = - (0.5)*(point_s-1.0)*(point_t-1.0)/(nval-1.0); 
      
      fract_p = (1.0 - pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[2] -= fract_p * deriv->shape[4];
      fract_q = (1.0 + nval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[7];
      fract_q = (1.0 - nval)/2.0;
      deriv->shape[0] -= fract_q * deriv->shape[7];

      // local derivatives
      if ( point_t < pval )
         deriv->local_deriv_s[4] =   (0.5)*(point_t+1.0)/(pval+1.0);
      else
         deriv->local_deriv_s[4] =   (0.5)*(point_t-1.0)/(pval-1.0);
      if ( point_t < nval )
         deriv->local_deriv_s[7] = - (0.5)*(point_t+1.0)/(nval+1.0);
      else
         deriv->local_deriv_s[7] = - (0.5)*(point_t-1.0)/(nval-1.0);
      
      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_s[2] -= fract_p * deriv->local_deriv_s[4];
      fract_q = (1.0 + nval)/2.0;
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[7];
      fract_q = (1.0 - nval)/2.0;
      deriv->local_deriv_s[0] -= fract_q * deriv->local_deriv_s[7];

      if ( point_t < pval )
         deriv->local_deriv_t[4] =   (0.5)*(point_s+1.0)/(pval+1.0);
      else
         deriv->local_deriv_t[4] =   (0.5)*(point_s+1.0)/(pval-1.0);
      if ( point_t < nval )
         deriv->local_deriv_t[7] = - (0.5)*(point_s-1.0)/(nval+1.0);
      else
         deriv->local_deriv_t[7] = - (0.5)*(point_s-1.0)/(nval-1.0);
      
      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_t[2] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 + nval)/2.0;
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[7];
      fract_q = (1.0 - nval)/2.0;
      deriv->local_deriv_t[0] -= fract_q * deriv->local_deriv_t[7];
   }

   if ( sides_for_particle == four_and_four_and_one_and_three )
   {
      // mval and nval are on side 4
      m1 = (mval-1.0)/2.0;
      n1 = (nval+1.0)/2.0;
      if ( point_t <= m1 )
      {
         deriv->shape[6] = -(0.5)*(point_t+1.0)*(point_s-1.0)/(mval+1.0);
         deriv->shape[7] =-(0.25)*(point_t+1.0)*(point_s-1.0)/(mval+1.0);
         deriv->local_deriv_s[6] = -(0.5)*(point_t+1.0)/(mval+1.0);
         deriv->local_deriv_s[7] = (0.25)*(point_t+1.0)/(mval+1.0);
         deriv->local_deriv_t[6] = -(0.5)*(point_s-1.0)/(mval+1.0);
         deriv->local_deriv_t[7] = (0.25)*(point_s-1.0)/(mval+1.0);
      }
      
      if ( m1 <= point_t && point_t <= mval )
      {
         deriv->shape[6] = -(0.5)*(point_t+1.0)*(point_s-1.0)/(mval+1.0);
         deriv->shape[7] = -(0.25)*(point_t-mval)*(point_s-1.0)/(mval+1.0);
         deriv->local_deriv_s[6] = -(0.5)*(point_t+1.0)/(mval+1.0);
         deriv->local_deriv_s[7] = -(0.25)*(point_t-mval)/(mval+1.0);
         deriv->local_deriv_t[6] = -(0.5)*(point_s-1.0)/(mval+1.0);
         deriv->local_deriv_t[7] = -(0.25)*(point_s-1.0)/(mval+1.0);
      }
      if ( mval <= point_t && point_t <= nval )
      {
         deriv->shape[6] = -(0.5)*(point_t-nval)*(point_s-1.0)/(mval-nval);
         deriv->shape[7] = (0.5)*(point_t-mval)*(point_s-1.0)/(mval-nval);
         deriv->local_deriv_s[6] = -(0.5)*(point_t-nval)/(mval-nval);
         deriv->local_deriv_s[7] = (0.5)*(point_t-mval)/(mval-nval);
         deriv->local_deriv_t[6] = -(0.5)*(point_s-1.0)/(mval-nval);
         deriv->local_deriv_t[7] = (0.5)*(point_s-1.0)/(mval-nval);
      }
      if ( nval <= point_t && point_t <= n1 )
      {
         deriv->shape[6] = -(0.25)*(point_t-nval)*(point_s-1.0)/(nval-1.0);
         deriv->shape[7] = -(0.5)*(point_t-1.0)*(point_s-1.0)/(nval-1.0);
         deriv->local_deriv_s[6] = -(0.25)*(point_t-nval)/(nval-1.0);
         deriv->local_deriv_s[7] = -(0.5)*(point_t-1.0)/(nval-1.0);
         deriv->local_deriv_t[6] = -(0.25)*(point_s-1.0)/(nval-1.0);
         deriv->local_deriv_t[7] = -(0.5)*(point_s-1.0)/(nval-1.0);
      }
      if ( n1 <= point_t )
      {
         deriv->shape[6] = (0.25)*(point_t-1.0)*(point_s-1.0)/(nval-1.0);
         deriv->shape[7] = -(0.5)*(point_t-1.0)*(point_s-1.0)/(nval-1.0);
         deriv->local_deriv_s[6] = (0.25)*(point_t-1.0)/(nval-1.0);
         deriv->local_deriv_s[7] = -(0.5)*(point_t-1.0)/(nval-1.0);
         deriv->local_deriv_t[6] = (0.25)*(point_s-1.0)/(nval-1.0);
         deriv->local_deriv_t[7] = -(0.5)*(point_s-1.0)/(nval-1.0);
      }

      fract_p = (1.0 - mval)/2.0;
      deriv->shape[0] -= fract_p * deriv->shape[6];
      deriv->local_deriv_s[0] -= fract_p * deriv->local_deriv_s[6];
      deriv->local_deriv_t[0] -= fract_p * deriv->local_deriv_t[6];
      fract_p = (1.0 + mval)/2.0;
      deriv->shape[3] -= fract_p * deriv->shape[6];
      deriv->local_deriv_s[3] -= fract_p * deriv->local_deriv_s[6];
      deriv->local_deriv_t[3] -= fract_p * deriv->local_deriv_t[6];
      fract_q = (1.0 - nval)/2.0;
      deriv->shape[0] -= fract_q * deriv->shape[7];
      deriv->local_deriv_s[0] -= fract_q * deriv->local_deriv_s[7];
      deriv->local_deriv_t[0] -= fract_q * deriv->local_deriv_t[7];
      fract_q = (1.0 + nval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[7];
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[7];
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[7]; 

      // pval on side 1, qval on side 3
      if ( point_s < pval )
         deriv->shape[4] = - (0.5)*(point_t-1.0)*(point_s+1.0)/(pval+1.0);
      else
         deriv->shape[4] = - (0.5)*(point_t-1.0)*(point_s-1.0)/(pval-1.0); 

      if ( point_s < qval )
         deriv->shape[5] =   (0.5)*(point_t+1.0)*(point_s+1.0)/(qval+1.0);
      else
         deriv->shape[5] =   (0.5)*(point_t+1.0)*(point_s-1.0)/(qval-1.0); 
      
      fract_p = (1.0 - pval)/2.0;
      deriv->shape[0] -= fract_p * deriv->shape[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->shape[1] -= fract_p * deriv->shape[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->shape[2] -= fract_q * deriv->shape[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->shape[3] -= fract_q * deriv->shape[5];

      // local derivatives
      if ( point_s < pval )
	deriv->local_deriv_s[4] = - (0.5)*(point_t-1.0)/(pval+1.0);
      else
         deriv->local_deriv_s[4] = - (0.5)*(point_t-1.0)/(pval-1.0);
      if ( point_s < qval )
         deriv->local_deriv_s[5] =   (0.5)*(point_t+1.0)/(qval+1.0);
      else
         deriv->local_deriv_s[5] =   (0.5)*(point_t+1.0)/(qval-1.0);

      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_s[0] -= fract_p * deriv->local_deriv_s[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_s[1] -= fract_p * deriv->local_deriv_s[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_s[2] -= fract_q * deriv->local_deriv_s[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_s[3] -= fract_q * deriv->local_deriv_s[5];

      if ( point_s < pval )
         deriv->local_deriv_t[4] = - (0.5)*(point_s+1.0)/(pval+1.0);
      else
         deriv->local_deriv_t[4] = - (0.5)*(point_s-1.0)/(pval-1.0);
      if ( point_s < qval )
         deriv->local_deriv_t[5] =   (0.5)*(point_s+1.0)/(qval+1.0);
      else
         deriv->local_deriv_t[5] =   (0.5)*(point_s-1.0)/(qval-1.0);

      fract_p = (1.0 - pval)/2.0;
      deriv->local_deriv_t[0] -= fract_p * deriv->local_deriv_t[4];
      fract_p = (1.0 + pval)/2.0;
      deriv->local_deriv_t[1] -= fract_p * deriv->local_deriv_t[4];
      fract_q = (1.0 + qval)/2.0;
      deriv->local_deriv_t[2] -= fract_q * deriv->local_deriv_t[5];
      fract_q = (1.0 - qval)/2.0;
      deriv->local_deriv_t[3] -= fract_q * deriv->local_deriv_t[5];  
   }

   // find the global derivatives
   // the deriv structure holds information for the mapping: 
   // deriv->dx_ds, deriv->dx_dt, deriv->dy_ds, deriv->dy_dt
   // deriv->determinant 

   // find the global derivatives - this is a sub-parametric mapping
   // the mapping is from the cooresponding 4-node element
   for ( int nod = 0; nod < 6; ++nod )
   {
      deriv->global_deriv_x [nod] =
	 deriv->ds_dx * deriv->local_deriv_s[nod] +
	 deriv->dt_dx * deriv->local_deriv_t[nod];
      deriv->global_deriv_y [nod] =
	 deriv->ds_dy * deriv->local_deriv_s[nod] +
	 deriv->dt_dy * deriv->local_deriv_t[nod];
   }
}

void nine_node_element::find_derivatives_with_particles ( )
{
}  


