#ifndef CHEM_H
#define CHEM_H

class Element;
class Mesh;

class Chemical_reaction
{
   friend class Mesh;
   friend class Element;
   //friend class One_d_element;
   //friend class Two_d_element;
   friend class List;
   public:
      Chemical_reaction
         ( int, type_of_reaction, int, int, int, int, 
           myvar, myvar, myvar, myvar, reaction_temp_term );
      myvar assemble_rate ( int );
      myvar assemble_rate_derivative ( int, int );
      myvar assemble_temp_derivative ( int );
      myvar assemble_energy_term ( );
      myvar assemble_d_energy ( );

   protected:
      int reaction_number;
      type_of_reaction type;
      int number_of_single_forward_reactants;
      int number_of_single_backward_reactants;
      int number_of_double_forward_reactants;
      int number_of_double_backward_reactants;
      int* single_forward_reactants;
      int* single_backward_reactants;
      int* double_forward_reactants;
      int* double_backward_reactants;
      Element* elem;
      static integration_flags* int_flags;
      static myvar* current_soln;
      static int temperature_dof;
      static int last_mass_dof;
      static const myvar r_in_kcals;
      myvar tempval;
      myvar k_1;
      myvar k_2;
      myvar E_a;
      myvar beta;
      reaction_temp_term temp_term;
};

#endif
