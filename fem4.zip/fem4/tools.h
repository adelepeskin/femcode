#ifndef TOOLS_H
#define TOOLS_H

int min ( int first, int second );

int max ( int first, int second );
myvar max ( myvar first, myvar second );

myvar dot_product ( myvar* vector_a, myvar* vector_b, int length );

void multiply_two_matrices ( myvar* a, int n, int m, myvar* b,
			     int p, myvar* product, myvar factor );

void transpose_a_matrix ( myvar* a, int n, int m, myvar* at );

myvar invert_a_3_by_3_matrix ( myvar* matrix );
// overwrites original matrix with its inverse

myvar det_of_3_by_3_matrix ( myvar* matrix );
// returns determinant; leaves matrix intact

myvar distance_between_points ( myvar* pointa, myvar* pointb );

myvar time_piston_rate 
   ( myvar a, myvar b, myvar c, myvar d, myvar current_time );
// gives a trig function


myvar get_timed_velocities ( myvar time, myvar vel_param );

#endif
