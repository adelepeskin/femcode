#include "particles.h"

// define private static member constants
int Particle::nodes_per_particle;
phase_properties* Particle::phase;

Particle::Particle ( int number, integration_flags* itf )
   :Moving_boundary_entity ( itf )
{
   particle_number = number;
   node_ptrs = 0;
   nodes_intersecting_elements = 0;
   center_node = 0;
   particle_nodes = 0;
   old_node_ptr = 0;
   dof_for_movement = 3;
   zero_element = 0;
   part_equation_numbers = 0;
   v_values = 0;
   press_values = 0;
   part_move = f_of_velocities;
}

myvar Particle::find_particle_radius ( int old_number_of_nodes )
{
   // find the particle radius, given the center point (last point in list)
   // and a radial point (use the first in the last)

   myvar distance = 
     node_ptrs[old_number_of_nodes-1]->distance_between_nodes(node_ptrs[0]);
   return distance;
}

void Particle::move_the_mesh_forward  ( myvar* rnew )
{
   cout << "start of move_the_mesh_forward \n";
   // first store the old particle node coordinates
   cout << "inside move the mesh forward " << endl;
   cout << "print out the first 4 solutions: " << rnew[0] << "  " << rnew[1] << "  " << rnew[2] << "  " << rnew[3] << "  " << rnew[4] << "  " << rnew[5] << endl;
   
   cout << "first print the current element list: ";
   for ( int p = 0; p < elements_per_particle; ++p )
   {
     cout << element_ptrs[p]->element_number << "  ";
   }
   cout << endl;

   Node* n_ptr;
   for ( int nod = 0; nod < number_of_intersection_points; ++nod )
   {
      n_ptr = nodes_intersecting_elements[nod];
      n_ptr->old_x = n_ptr->x_val;
      n_ptr->old_y = n_ptr->y_val;
   }

   // to move the particle forward, move the center node, then calculate
   // new intersection points

   // the first degree of freedom is translational motion
   myvar u_trans, v_trans, w_rot, time_move;
   int eqn = nodes_intersecting_elements[0]->first_vel_eqn;
   if ( eqn > 0 )
   {
      u_trans = rnew [eqn-1];
      v_trans = rnew [eqn];
      w_rot = rnew [eqn+1];
   }
   else
   {
      if (part_move == time_dep_constraints)
      {
         time_move = get_timed_velocities(int_flags->current_time, int_flags->r );
         u_trans = v_values->value[0]*time_move;
         v_trans = v_values->value[1]*time_move;
         w_rot = 0.0e0;
      }
      else
      {
         u_trans = v_values->value[0];
         v_trans = v_values->value[1];
         w_rot = v_values->value[2];
      }
   }

   eqn = nodes_intersecting_elements[0]->first_particle_eqn;
   cout << "print u,v,w at time: " << int_flags->current_time << "  " << u_trans << "  " << v_trans << "  " << w_rot << endl;

   // move the center node
   center_node->x_val += int_flags->step_size * u_trans;
   center_node->y_val += int_flags->step_size * v_trans;
   cout << "new center: " << center_node->x_val << "  " << center_node->y_val << endl;

   cout << "in move the mesh: print the elements: " << elements_per_particle << endl;
   for ( int pp = 0; pp < elements_per_particle; ++pp )
   {
     cout << element_ptrs[pp]->element_number << "  ";
   }
   cout << endl;

   // find new particle - element intersections
   rezero_particle_info ( );
   rezero_elements_for_particle_info ( );

   //display_intersection_info ( );
}

void Particle::move_the_mesh_back ( )
{
   cout << "start of move the mesh back  \n";

   // replace the nodes
   Node* n_ptr;
   for ( int nod = 0; nod < number_of_intersection_points; ++nod )
   {
      // now find the velocities at each node and move the node
      n_ptr = nodes_intersecting_elements[nod];
      cout << "move back node: " << n_ptr->node_number << "  from: " << n_ptr->x_val << "  " << n_ptr->y_val << "  to: "; 
      n_ptr->old_coordinates ( );
      cout << n_ptr->x_val << "  " << n_ptr->y_val << "\n";
      n_ptr->has_node_moved = node_has_not_been_moved;
   }

   // replace the element information
   // replace_old_element_info ( );
}

void Particle::save_old_coordinates ( )
{
   Node* n_ptr;
   for ( int numnod = 0; numnod < number_of_intersection_points; ++numnod )
   {
      n_ptr = nodes_intersecting_elements [numnod];
      cout << "print out node number : " << n_ptr << "  " << n_ptr->node_number << endl;
      // n_ptr->save_old_coordinates ( );
   }
}

void Particle::put_back_original_coordinates ( )
{
   Node* n_ptr;
   for ( int numnod = 0; numnod < nodes_per_particle; ++numnod )
   {
      n_ptr = node_ptrs [numnod];
      n_ptr->put_back_original_coordinates ( );
   }
}

void Particle::rezero_particle_info ( )
{
   number_of_intersection_points = 0;
   cout << "rezeroing done: " << endl;
}

void Particle::rezero_elements_for_particle_info ( )
{
   for ( int j = 0; j < elements_per_particle; ++j )
   {
      element_ptrs[j]->rezero_elements_for_particle_info ( );
   }
}

void Particle::find_particle_element_intersections ( )
{
   // find all the intersections between this particle and the sides of
   // elements in the mesh

   // first save all of the old element information
   // if ( int_flags->moving_flag == boundary_moves )
   //   save_old_element_info ( );

   // element pointers for this particle are in element_ptrs
   bool intersection_test = false, same_int_test = false;
   int number_els = elements_per_particle;
   number_of_intersection_points = 0;
   for ( int nelem = 0; nelem < elements_per_particle; ++nelem )
   {
      if ( element_ptrs[nelem] == 0 ) continue;
      // for each element, find particle intersection points
      intersection_test = element_ptrs[nelem]->find_intersection_points ( this );
   }
}

void Particle::set_up_eqn_arrays ( )
{
  cout << "start of set_up_eqn_arrays: " << endl;
   Element* e_ptr; int trans_eqn; int vel_dof;
   for ( int numel = 0; numel < elements_per_particle; ++numel )
   {
      e_ptr = element_ptrs[numel];
      vel_dof = e_ptr->vel_degrees_of_freedom;

      if ( e_ptr->element_particle_type == element_contains_particle )
      {
         // set up particle equation number array with:
         // first:  translation d.o.f. equation numbers
         // then: rotational d.o.f. equation number
         if (e_ptr->total_nodes>e_ptr->number_of_nodes)
            trans_eqn = e_ptr->connect_ptrs[e_ptr->number_of_nodes]->first_vel_eqn;
         e_ptr->part_equation_numbers[0] = trans_eqn;
         if ( trans_eqn > 0 )
         {
            e_ptr->part_equation_numbers[1] = trans_eqn + 1; 
            e_ptr->part_equation_numbers[2] = trans_eqn + 2;
         }
         else
         {
            e_ptr->part_equation_numbers[1] = trans_eqn - 1; 
            e_ptr->part_equation_numbers[2] = trans_eqn - 2;
         }
      }
      else
      {
         e_ptr->part_equation_numbers[0] = 0;
         e_ptr->part_equation_numbers[1] = 0;
         e_ptr->part_equation_numbers[2] = 0;
      }
   }
}

bool Particle::is_element_on_particle_list ( Element* e_ptr )
{
   bool test = false;
   for ( int j = 0; j < elements_per_particle; ++j )
   {
      if ( e_ptr == element_ptrs[j] )
      {
         test = true;
         break;
      }
   }

   return ( test );
}

bool Particle::is_element_on_old_particle_list ( Element* e_ptr )
{

   bool test = false;
   for ( int j = 0; j < elements_per_particle; ++j )
   {
      if ( e_ptr == old_particle_info->old_e_ptrs[j] )
      {
         test = true;
         break;
      }
   }

   return ( test );
}

Node* Particle::find_the_closest_particle_node ( myvar* xy )
{
   Node* n_ptr = nodes_intersecting_elements[0];
   myvar distance = n_ptr->distance_between_point_and_node ( xy );
   myvar next_distance;

   for ( int j = 1; j < number_of_intersection_points; ++j )
   {
      next_distance = 
         nodes_intersecting_elements[j]->distance_between_point_and_node ( xy );
      if ( next_distance < distance )
      {
         n_ptr = nodes_intersecting_elements[j];
         distance = next_distance;
      }
   }

   return ( n_ptr );
}

int Particle::is_node_on_list ( myvar* xy )
{
   int old_number = -1;
   Node* n_ptr; myvar distance = 0;
   for ( int j = 0; j < number_of_intersection_points; ++j )
   {
      n_ptr = nodes_intersecting_elements[j];
      if ( n_ptr != 0 )
      {
         distance = n_ptr->distance_between_point_and_node ( xy );
         if ( distance < kind_of_small )
         {
            // old node found
            old_number = j;
            break;
         }
      }
   }

   return ( old_number );
}

void Particle::save_old_element_info ( )
{
   // save element pointers and side numbers and intersecting node pointers
   for ( int j = 0; j < elements_per_particle; ++j )
   {
      old_particle_info->old_e_ptrs[j] = element_ptrs[j];
      for ( int k = 0; k < number_of_intersections_per_element; ++k )
      {
         old_particle_info->old_side_numbers[number_of_intersections_per_element*j+k] = 
            element_ptrs[j]->side_numbers[k];

         old_particle_info->old_node_ptrs[number_of_intersections_per_element*j+k] =
            element_ptrs[j]->connect_ptrs[element_ptrs[j]->number_of_nodes+k];
      }
   }
}

void Particle::replace_old_element_info ( )
{
   // check current list of element to see if any should be taken off
   bool test = true; 
   int vel_dof = element_ptrs[0]->vel_degrees_of_freedom;
   int numnod = element_ptrs[0]->number_of_nodes;

   // if elements are not on the new list: zero out particle information
   for ( int j = 0; j < elements_per_particle; ++j )
   {
      if ( element_ptrs[j] == 0 ) continue;
      test = is_element_on_old_particle_list ( element_ptrs[j] );
      if ( test == false )
      {
         for ( int k = 0; k < number_of_intersections_per_element; ++k )
         {
            element_ptrs[j]->side_numbers[k] = 0;
            element_ptrs[j]->connect_ptrs[numnod+k] = 0;
         }
         for ( k = 0; k < number_of_intersections_per_element; ++k )
         {
            for ( int m = 0; m < vel_dof; ++m )
            {
               element_ptrs[j]->vel_equation_numbers[vel_dof*numnod + vel_dof*k + m] = 0;
   	    }
         }
         element_ptrs[j]->total_nodes = numnod;
         element_ptrs[j]->element_particle_type = element_has_no_particle;
         element_ptrs[j]->extra_node_flag = element_has_no_extra_nodes;
         element_ptrs[j]->sides_for_particle = no_sides;
      }
   }

   for ( j = 0; j < elements_per_particle; ++j )
   {
      element_ptrs[j] = old_particle_info->old_e_ptrs[j];
      if ( element_ptrs[j] == 0 ) continue;
      for ( int k = 0; k < number_of_intersections_per_element; ++k )
      {
         element_ptrs[j]->side_numbers[k] =
         old_particle_info->old_side_numbers[number_of_intersections_per_element*j+k]; 
         element_ptrs[j]->connect_ptrs[numnod+k] = 
         old_particle_info->old_node_ptrs[number_of_intersections_per_element*j+k];
      }
      for ( k = 0; k < number_of_intersections_per_element; ++k )
      {
         for ( int m = 0; m < vel_dof; ++m )
         {
            element_ptrs[j]->vel_equation_numbers[vel_dof*numnod + vel_dof*k + m] =
               element_ptrs[j]->connect_ptrs[numnod+k]->first_vel_eqn + m;
	 }
      }
      element_ptrs[j]->extra_node_flag = element_has_extra_nodes;
      element_ptrs[j]->element_particle_type = element_contains_particle;
      element_ptrs[j]->assign_shape_fcns ( );  
   }      
}

void Particle::display_intersection_info ( )
{
   // print out particle intersections
   cout << "final particle intersections: " << endl;
   for ( int j = 0; j < number_of_intersection_points; ++j )
   {
      cout << nodes_intersecting_elements[j]->x_val << "  " << nodes_intersecting_elements[j]->y_val << endl;
   }

   // print out element intersections
   // cout << "final element intersections: " << endl;
   for ( j = 0; j < elements_per_particle; ++j )
   {
       for ( int k = 0; k < element_ptrs[j]->number_of_intersecting_particle_nodes; ++k )
       {
	 // cout << element_ptrs[j]->intersecting_particle_nodes[k]->x_val << "  " << element_ptrs[j]->intersecting_particle_nodes[k]->y_val << endl;
       }
    }
   // cout << "write out list of special tags after update: " << endl;
      for ( int p = 0; p < 9; ++p )
      {    
	//cout << line_element_ptrs[p]->is_it_a_special_particle_element << "  ";
      }  
}

void Particle::display_particle_intersection_data ( )
{
   cout << "first display elements, side numbers, node numbers, and vel eqns: \n";
   int numnod = element_ptrs[0]->number_of_nodes;
   for ( int j = 0; j < elements_per_particle; ++j )
   {
      cout << element_ptrs[j]->element_number << "    side numbers:  " << element_ptrs[j]->side_numbers[0] << "  " << element_ptrs[j]->side_numbers[1] << "\n";

      cout << "   extra node numbers:   " << element_ptrs[j]->connect_ptrs[numnod]->node_number << "  " << element_ptrs[j]->connect_ptrs[numnod]->x_val << "  " << element_ptrs[j]->connect_ptrs[numnod]->y_val << "   " << element_ptrs[j]->connect_ptrs[numnod+1]->node_number << "  " << element_ptrs[j]->connect_ptrs[numnod+1]->x_val << "  " << element_ptrs[j]->connect_ptrs[numnod+1]->y_val << "\n";

      cout << "    vel equation numbers: " << element_ptrs[j]->vel_equation_numbers[8] << "  " << element_ptrs[j]->vel_equation_numbers[9] << "  " << element_ptrs[j]->vel_equation_numbers[10] << "  " << element_ptrs[j]->vel_equation_numbers[11] << "  " << "\n";

      cout << "    part equation numbers: " << element_ptrs[j]->part_equation_numbers[0] << "  " << element_ptrs[j]->part_equation_numbers[1] << "  " << element_ptrs[j]->part_equation_numbers[2] << "\n";
   } 

   // list of intersecting nodes
   cout << "print out list of nodes_intersecting_elements:  \n";
   for ( int nod = 0; nod < number_of_intersection_points; ++nod )
   {
      cout << nodes_intersecting_elements[nod]->node_number << "  " << nodes_intersecting_elements[nod]->x_val << "  " << nodes_intersecting_elements[nod]->y_val << "\n";
   }
}

void Particle::find_all_the_nodes_inside ( )
{
   // for the set of particle elements: tag all nodes inside the particle
}

void Particle::assign_the_box ( )
{
   particle_box->xmin = center_node->x_val - radius;
   particle_box->xmax = center_node->x_val + radius;
   particle_box->ymin = center_node->y_val - radius;
   particle_box->ymax = center_node->y_val + radius;
   particle_box->zmin = 0.0;
   particle_box->zmax = 0.0;
}

void Particle::store_old_particle_box_values ( )
{
   particle_box->old_xmin = particle_box->xmin;
   particle_box->old_ymin = particle_box->ymin;
   particle_box->old_xmax = particle_box->xmax;
   particle_box->old_ymax = particle_box->ymax;
}

void Particle::find_direction_of_movement ( )
{   
   // if particle has moved, note it's direction (for remeshing)
   myvar delta_top = particle_box->ymax - particle_box->old_ymax; 
   myvar delta_bottom = particle_box->old_ymin - particle_box->ymin; 
   myvar delta_left = particle_box->old_xmin - particle_box->xmin; 
   myvar delta_right = particle_box->xmax - particle_box->old_xmax;
   cout << "delta_top: " << delta_top << "  " << "delta_bottom: " << delta_bottom << "delta_left: " << delta_left << "delta_right: " << delta_right << endl;    
      myvar biggest = delta_top;
   r_region->direction = top;
   if ( delta_bottom > biggest )
   { 
      r_region->direction = bottom;
      biggest = delta_bottom;
   }
   if ( delta_left > biggest )
   { 
      r_region->direction = left;
       biggest = delta_left;      
   }
   if ( delta_right > biggest )
   { 
      r_region->direction = right;
      biggest = delta_right;      
   }
   cout << "print the final direction find_particle_boxes: " << r_region->direction << endl;
}

void Particle::define_region_box ( )
{
   // define the minimum and maximum x and y values
   r_region->region_box->xmin = r_region->first_node_ptr->x_val;
   r_region->region_box->ymax = r_region->first_node_ptr->y_val;

   r_region->region_box->xmax = r_region->region_box->xmin + 
      r_region->grid_x*r_region->old_cols_of_elements;
   r_region->region_box->ymin = r_region->region_box->ymax -
      r_region->grid_y*r_region->old_rows_of_elements;

   cout << "region box: x: " << r_region->region_box->xmin << "  to " << r_region->region_box->xmax << " grid_x: " << r_region->grid_x << "  old_cols: " << r_region->old_cols_of_elements << "  y: " << r_region->region_box->ymin << "  to " << r_region->region_box->ymax << endl;
}

void Particle::is_particle_box_in_region_box ( )
{
   r_region->box_flag = inside;
   if ( particle_box->ymax > r_region->region_box->ymax ) 
      r_region->box_flag = outside;
   if ( particle_box->xmin < r_region->region_box->xmin ) 
      r_region->box_flag = outside;
   if ( particle_box->xmax > r_region->region_box->xmax ) 
      r_region->box_flag = outside;
   if ( particle_box->ymin < r_region->region_box->ymin ) 
      r_region->box_flag = outside;
   cout << "checking particle box in or out: x: " << particle_box->xmin << "  " << particle_box->xmax << "  y: " << particle_box->ymin << "  " << particle_box->ymax << "  vs region_box: x:" << r_region->region_box->xmin << "  " << r_region->region_box->xmax << "  y: " << r_region->region_box->ymin << "  " << r_region->region_box->ymax << "  in? " << r_region->box_flag << endl;
}

int Particle::find_first_eqn ( )
{
   int first_eqn = zero_element->part_equation_numbers[0];
   return ( first_eqn );
}

void Particle::set_element_particle_pointers ( )
{
   for ( int j = 0; j < elements_per_particle; ++j )
   {
      element_ptrs[j]->p_ptr = this;
   }
}

void Particle::put_nodes_inside_particle_boxes ( )
{
  // loop through nodes in the region
  // define as inside or outside the box
  // set first_vel_eqn correctly

   Node* n_ptr;
   myvar distance;
   for ( int j = 0; j <  elements_per_particle; ++j )
   {
      for ( int k = 0; k < element_ptrs[j]->total_nodes; ++ k )
      {
         n_ptr = element_ptrs[j]->connect_ptrs[k];
         n_ptr->is_node_in_particle = node_not_in_particle_box;
         // check to see if the distance from the node to the 
         // particle center is less than the radius
         distance = center_node->distance_between_nodes ( n_ptr );
         if ( distance < (1.001*radius) )
	 { 
            n_ptr->is_node_in_particle = node_in_particle_box;
            find_rotation_angle ( n_ptr );
            // assign this node any velocity constraints put on the particle
            n_ptr->v_values = v_values;
            n_ptr->first_vel_eqn = part_equation_numbers[0];
            // if node is right on the surface, say so
            if ( distance > (0.999*radius) && distance < (1.001*radius))
               n_ptr->is_node_in_particle = node_on_particle_surface;
	 }
         else
	 {
	    // make the first node eqn something positive
            n_ptr->first_vel_eqn = 10;
	 }
      }
   }

   // set center node
   center_node->is_node_in_particle = node_in_particle_box;
   center_node->first_vel_eqn = part_equation_numbers[0];
   if ( center_node->first_vel_eqn < 0 )
      center_node->v_values = v_values;
}

void Particle::find_rotation_angle ( Node* n_ptr )
{
   // find the direction of rotation angle for a particle node
   //    = tangential vector

   // find the radial vector in the direction from the center node to a
   // particle node = radial vector;

   // these should be perpendicular: |tangential| = 1.0; |radial| = radius;
   
   myvar top[2]; myvar radial_distance;
   top[0] = center_node->x_val;
   top[1] = center_node->y_val + radius;

   // return if node is the center
   if ( n_ptr == center_node ) return;

   // return if node is original particle definition node
   if ( n_ptr->first_particle == node_from_original_particle ) return;

   // if node doesn't have a vector assigned already, assign one
   if ( n_ptr->tangential_direction == 0 )
   {
      n_ptr->tangential_direction = new vector ( 0.0, 0.0, 0.0 );
      n_ptr->radial_direction = new vector ( 0.0, 0.0, 0.0 );
   }

   // find the distance from the center node
   radial_distance = n_ptr->distance_to_another_node ( center_node );

   // find the angle from the vertical that is the rotation angle for
   // this node
   // first determine what quadrant of the particle the node is in
   int quadrant = 1;

   // first check for nodes at quadrant corners
   if ( fabs(n_ptr->x_val - center_node->x_val) < small ||
        fabs(n_ptr->y_val - center_node->y_val) < small )
   {
      // node is directly above or below the center node
      if ( fabs(n_ptr->x_val - center_node->x_val) < small )
      {
         n_ptr->tangential_direction->direction[0] = 1.0;
         if ( n_ptr->y_val > center_node->y_val ) 
            n_ptr->tangential_direction->direction[0] = -1.0;
         n_ptr->tangential_direction->direction[1] = 0.0;
      }
      else
      {
         n_ptr->tangential_direction->direction[0] = 0.0;
         n_ptr->tangential_direction->direction[1] = 1.0;
         if ( center_node->x_val > n_ptr->x_val )
            n_ptr->tangential_direction->direction[1] = -1.0;
      }
      n_ptr->tangential_direction->make_a_normalized_vector_a_given_length 
            ( radial_distance/radius );
      n_ptr->radial_direction->set_up_a_vector ( radius, 
            n_ptr->x_val - center_node->x_val,
            n_ptr->y_val - center_node->y_val );
      return;
   }

   // compare the x and y coordinates with those of the center node
   if ( (n_ptr->x_val - center_node->x_val) > small )
   {
      // quadrants 1 and 2
      if ( (center_node->y_val - n_ptr->y_val) > small )
         quadrant = 2;  
   }
   else
   {
      // quadrant 3 and 4
      if ( (center_node->y_val - n_ptr->y_val) > small )
         quadrant = 3;
      else
         quadrant = 4;
   }

   myvar angle = 0.0; myvar segment_length = 0.0; myvar x_dist, y_dist;
   if ( quadrant == 1 )
   {
      y_dist = n_ptr->y_val - center_node->y_val;
      x_dist = n_ptr->x_val - center_node->x_val;
      n_ptr->tangential_direction->direction[0] = y_dist;
      n_ptr->tangential_direction->direction[1] = -x_dist;
   }
   if ( quadrant == 2 )
   {
      y_dist = center_node->y_val - n_ptr->y_val;
      x_dist = n_ptr->x_val - center_node->x_val;
      n_ptr->tangential_direction->direction[0] = -y_dist;
      n_ptr->tangential_direction->direction[1] = -x_dist;
   }
   if ( quadrant == 3 )
   {
      y_dist = center_node->y_val - n_ptr->y_val;
      x_dist = center_node->x_val - n_ptr->x_val;
      n_ptr->tangential_direction->direction[0] = -y_dist;
      n_ptr->tangential_direction->direction[1] = x_dist; 
   }
   if ( quadrant == 4 )
   {
      y_dist = n_ptr->y_val - center_node->y_val;
      x_dist = center_node->x_val - n_ptr->x_val;
      n_ptr->tangential_direction->direction[0] = y_dist;
      n_ptr->tangential_direction->direction[1] = x_dist; 
   }

   n_ptr->tangential_direction->direction[2] = 0.0;
   n_ptr->tangential_direction->normalize_vector ( );

   // n_ptr->tangential_direction->display_vector ( );

   // make tangential vector = 1.0 for nodes on particle surface
   // r/R for internal nodes

   // so find (distance from center/radius)
   radial_distance = n_ptr->distance_to_another_node ( center_node );
   radial_distance = radial_distance / radius;
   n_ptr->tangential_direction->make_a_normalized_vector_a_given_length 
      ( radial_distance );

   // radial direction: [0]:n_ptr->x_val - center_node->x_val;
   //                   [1]:n_ptr->y_val - center_node->y_val;
   // length = radius
   n_ptr->radial_direction->set_up_a_vector ( radius, 
          n_ptr->x_val - center_node->x_val,
          n_ptr->y_val - center_node->y_val );
}

void Particle::display_line_element_data ( )
{
   cout << "start of display line_element_data " << endl;
   Element* e_ptr;
   for ( int j = 0; j < number_of_line_elements; ++j )
   {
     e_ptr = line_element_ptrs[j];
     cout << "print next line element info: " << e_ptr->element_number << " from:  " << e_ptr->connect_ptrs[0]->x_val << "  " << e_ptr->connect_ptrs[0]->y_val << "  to: " << e_ptr->connect_ptrs[1]->x_val << "  " <<  e_ptr->connect_ptrs[1]->y_val << "  empty: " << e_ptr->is_it_empty << endl;
   }
   cout << endl;
}

void Particle::take_node_off_list ( Node* n_ptr )
{
   // first find the node on the list
   Node* n_ptr2; int found = 0;
   for ( int j = 0; j < number_of_intersection_points; ++j )
   {
      n_ptr2 = nodes_intersecting_elements[j];
      if ( n_ptr2 == n_ptr ) found = j;
   }

   if ( found > 0 )
   {
      for ( int j = found; j < number_of_intersection_points-1; ++j )
      {
         nodes_intersecting_elements[j] = nodes_intersecting_elements[j+1];
      } 
      number_of_intersection_points -= 1; 
   }
}

void Particle::define_new_region ( remesh_region* region )
{
   // define the element array for this particle
   int first_el = region->first_element_in_region;
   int counter = 0;

   // fill the element pointer array

   for ( int row = 0; row < region->old_rows_of_elements; ++row )
   {
      for ( int col = 0; col < region->old_cols_of_elements; ++col )
      {
         particle_elements[counter] = region->first_element_in_region +
           row * region->elements_per_row + col;
         cout << particle_elements[counter] << "  ";
         ++counter; 
      }
      cout << endl;
   }
}

void Particle::print_particle_elements ( )
{
   cout << "particle elements: " << elements_per_particle << "  ";
   for ( int pp = 0; pp < elements_per_particle; ++pp )
   {
     cout << element_ptrs[pp]->element_number << "  ";
   }
   cout << endl;

   cout << "line elements: " << number_of_line_elements << "  ";
   for ( pp = 0; pp < number_of_line_elements; ++pp )
   {
     cout << line_element_ptrs[pp]->element_number << "  ";
   }
   cout << endl;

   cout << "quad elements: " << number_of_line_element_quads << "  ";
   for ( pp = 0; pp < number_of_line_element_quads; ++pp )
   {
     cout << line_element_quads[pp]->element_number << "  ";
   }
   cout << endl;  
}
