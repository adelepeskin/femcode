#include "node.h"

Node::Node (int number, myvar xx, myvar yy)
{
   node_number = number;
   x = xx;
   y = yy;
   ueqn = -1;
   veqn = -1;
   constrained = false;
   initialu = 0.0;
   initialv = 0.0;
   uval = 0.0;
   vval = 0.0;
   //printf("new node: %d %f %f\n",node_number,x,y);
}

myvar Node::getValue( int eqn ) {
  myvar value = 0.0;
  if (eqn == ueqn) 
    value = uval;
  else if (eqn == veqn)
    value = vval;
  return value;
}
