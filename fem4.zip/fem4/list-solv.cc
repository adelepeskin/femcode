#include "el.h"
#include "tools.h"
#include "sorts.h"
#include "lists.h"
#include "mover.h"
#include "node.h"
#include "solver.h"
#include "solver-it.h"
#include "solver-sky.h"
#include <math.h>
#include <fstream.h>

void List::fix_sizes_for_skyline ( Solver_structure* mysolve,
     integration_flags* int_flags, skyline_sizes* sky_sizes )
{
   // for each element: setup up skyline structure only for the equations that are put into this matrix
   equation_groups matrix_group = mysolve->matrix_group;
   cout << "current matrix group: " << matrix_group << endl;

   int* left = sky_sizes->left_sides;
   int* diag = sky_sizes->diagonals;
   int num_eqns = mysolve->number_of_equations;
   for ( int k = 0; k < num_eqns; ++k )
   {
      left [k] = 0;
      diag [k] = 0;
   }

   // first determine largest length from diagonal to the left
   // for each equation
   int mass_dof = int_flags->mass_degrees_of_freedom;
   int surf_dof = int_flags->surf_degrees_of_freedom;
   int vel_dof = int_flags->vel_degrees_of_freedom;
   int free_surf_dof = int_flags->number_of_free_surf_equations;
   int numnod = 0; int numtot = 0;
   int mass_num = 0; int vel_num = 0;
   int qnum = 0; int qmass = 0; int qvel = 0; 
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   fill_diag_flag fill_flag = dont_fill_diag;
   while (e_item != 0)
   {
      while ( e_ptr->element_number < 0 || 
              e_ptr->is_it_a_special_particle_element == 
                     special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }

      numnod = e_ptr->number_of_nodes;
      if ( e_ptr->dimension == one_dimensional )
      {
         fill_flag = fill_diag;
         qnum = e_ptr->quad_number_of_nodes;
         qmass = mass_dof * qnum;
         qvel = vel_dof * qnum;
        if (matrix_group == all_equations || matrix_group == temperature_only)
	{ 
	   // assign space for moving boundary equations
            if ( e_ptr->moving_type == line )
            {
 	       assign_skyline ( numnod, numnod, left, diag,
	          e_ptr->el_equation_numbers, e_ptr->el_equation_numbers, 
                  fill_flag );

	       // assign space for rhs derivatives for moving boundary equations
	       fill_flag = dont_fill_diag;
               assign_skyline ( numnod, qmass, left, diag,
	          e_ptr->el_equation_numbers, e_ptr->quad_c_eqns, fill_flag );
	    }

            if ( e_ptr->elem_bc->mass_bc[0] == chemical_rxn )
	    {
               assign_skyline ( numnod, qmass, left, diag,
	          e_ptr->el_equation_numbers, e_ptr->quad_c_eqns, fill_flag ); 
               if ( int_flags->temp_eqns == solve_temp )
                  assign_skyline ( numnod, qnum, left, diag,
	          e_ptr->el_equation_numbers, e_ptr->quad_temp_eqns, fill_flag );
               if ( e_ptr->elem_bc->free_surf_bc[0] == free_surf &&
                  int_flags->initial_flag == not_solving_for_initial)
                  assign_skyline ( numnod, qnum*surf_dof, left, diag,
	          e_ptr->el_equation_numbers, e_ptr->surf_equation_numbers,
                  fill_flag );
	    }

            // assign space for surface reactants
            if ( e_ptr->elem_bc->surf_bc[0] != none )
	    {
               assign_skyline ( surf_dof*numnod, surf_dof*numnod, left, diag,
                  e_ptr->surf_equation_numbers, e_ptr->surf_equation_numbers,
                  fill_flag ); 
               assign_skyline ( surf_dof*numnod, qmass, left, diag,
                  e_ptr->surf_equation_numbers, e_ptr->quad_c_eqns, fill_flag );
               assign_skyline ( surf_dof*numnod, qnum, left, diag,
	          e_ptr->surf_equation_numbers, e_ptr->quad_temp_eqns, fill_flag );
               assign_skyline ( qmass, surf_dof*numnod, left, diag,
                  e_ptr->quad_c_eqns, e_ptr->surf_equation_numbers, fill_flag ); 
	    }

            if ( e_ptr->elem_bc->mass_bc[0] == diffuse_adsorption ||
                 e_ptr->elem_bc->mass_bc[0] == polymer_adsorption)
	    {
               assign_skyline ( qmass, qmass, left, diag,
	          e_ptr->quad_c_eqns, e_ptr->quad_c_eqns, fill_flag );
               assign_skyline ( qnum, qmass, left, diag,
	          e_ptr->quad_pot_eqns, e_ptr->quad_c_eqns, fill_flag );
               assign_skyline ( qmass, qnum, left, diag,
	          e_ptr->quad_c_eqns, e_ptr->quad_pot_eqns, fill_flag );
            }

            if ( int_flags->moving_boundary_field == temperature &&
              e_ptr->moving != stationary )
            {
               assign_skyline ( numnod, qnum, left, diag,
                  e_ptr->el_equation_numbers, e_ptr->quad_temp_eqns,
                  fill_flag );
	    }

            if ( e_ptr->elem_bc->free_surf_bc[0] == free_surf )
	    {
               //dh_kinematic 
               assign_skyline ( numnod, numnod, left, diag,
                  e_ptr->el_equation_numbers, e_ptr->el_equation_numbers,
                  fill_flag );           
               //dh_stress
               assign_skyline ( free_surf_dof*numnod, numnod, left, diag,
                 e_ptr->free_surf_equation_numbers, e_ptr->el_equation_numbers,
                  fill_flag );
               // free_surf X free_surf
               assign_skyline ( free_surf_dof*numnod, 
                  free_surf_dof*numnod, left, diag,
                  e_ptr->free_surf_equation_numbers, 
                  e_ptr->free_surf_equation_numbers,
                  fill_flag );
	    }
	}

        if ( e_ptr->elem_bc->free_surf_bc[0] == free_surf &&
             matrix_group == all_equations )
	{
           //dv_kinematic
           assign_skyline ( numnod, qvel, left, diag,
                  e_ptr->el_equation_numbers, e_ptr->quad_vel_eqns,
                  fill_flag );
           //dv_stress
           assign_skyline ( free_surf_dof*numnod, qvel, left, diag,
                  e_ptr->free_surf_equation_numbers, e_ptr->quad_vel_eqns,
                  fill_flag );            
           //dp_stress
           assign_skyline ( free_surf_dof*numnod, 
                  e_ptr->number_of_pressure_basis_fcns, left, diag,
                  e_ptr->free_surf_equation_numbers, e_ptr->quad_press_eqns,
                  fill_flag );
	 } 

         // assign space for particle equations if particles are present
         if ( e_ptr->elem_bc->particle_bc[0] == particle_surface )
         {
            if (matrix_group == velocity_only || matrix_group == all_equations)
            {
               // particle constraint equations - translational velocities
               assign_skyline ( e_ptr->particle_degrees_of_freedom, 
                numnod*vel_dof, left, diag,
                e_ptr->part_equation_numbers, e_ptr->vel_equation_numbers,
                fill_flag ); 

               assign_skyline ( numnod*vel_dof, 
                e_ptr->particle_degrees_of_freedom, 
                left, diag,
                e_ptr->vel_equation_numbers, e_ptr->part_equation_numbers,
                fill_flag );

               // particle constraint equations - rotational velocity
               assign_skyline ( e_ptr->particle_degrees_of_freedom, 
                e_ptr->particle_degrees_of_freedom, left, diag,
                e_ptr->part_equation_numbers, e_ptr->part_equation_numbers,
                fill_flag );
	    }
            if (matrix_group == all_equations)
	    { 
               // particle constraint equations - pressure terms
               assign_skyline ( e_ptr->particle_degrees_of_freedom, 
                e_ptr->int_flags->press_degrees_of_freedom, left, diag,
                e_ptr->part_equation_numbers, e_ptr->press_equation_numbers,
                fill_flag );
	    }
	 }
      }

      if ( e_ptr->dimension == two_dimensional )
      {
         numtot = e_ptr->total_nodes;
         mass_num = numtot*e_ptr->mass_degrees_of_freedom;
         vel_num = numtot*e_ptr->vel_degrees_of_freedom;
         if ( int_flags->mass_eqns == solve_mass )
	 {
            if (matrix_group == all_equations || 
                matrix_group == temperature_only)
	    {
	       // assign space for diffusion-convection matrix
	       assign_skyline ( mass_num, mass_num, left, diag,
	       e_ptr->el_equation_numbers, e_ptr->el_equation_numbers,
               fill_flag );

               
               if ( int_flags->temp_eqns == solve_temp )
	       {
                  if ( int_flags->thermdiff_term_flag == include_thermdiff ||
                    int_flags->reaction_term_flag == include_reaction )
                  assign_skyline ( numnod, mass_num, left, diag,
	          e_ptr->temp_equation_numbers, e_ptr->el_equation_numbers,
                  fill_flag ); 
          
	          // assign space for moving mass matrix
	          if ( int_flags->field_flag == full )
	          assign_skyline ( numnod, mass_num, left, diag,
	          e_ptr->r_equation_numbers, e_ptr->el_equation_numbers,
                  fill_flag );
	       }
	    }
          
            if (matrix_group == all_equations )
	    {
	       // assign space for derivatives of velocities
	       if ( int_flags->vel_eqns == solve_vel && 
                 matrix_group == all_equations )
	       assign_skyline ( vel_num, mass_num, left, diag,
	       e_ptr->vel_equation_numbers, e_ptr->el_equation_numbers,
               fill_flag );
	    }
	 }

	 if ( int_flags->temp_eqns == solve_temp )
	 { 
            if (matrix_group == all_equations || 
                matrix_group == temperature_only)
	    {
	       // assign space for diffusion-convection matrix
	       assign_skyline ( numnod, numnod, left, diag,
	       e_ptr->temp_equation_numbers, e_ptr->temp_equation_numbers,
               fill_flag );

	       // assign space for moving mass matrix
	       if ( int_flags->field_flag == full )
	       assign_skyline ( numnod, numnod, left, diag,
	       e_ptr->r_equation_numbers, e_ptr->temp_equation_numbers,
               fill_flag );
	    }
            if (matrix_group == all_equations)
	    {
               // assign space for derivatives of velocities
	       if ( int_flags->vel_eqns == solve_vel )
	       assign_skyline ( vel_num, numnod, left, diag,
	       e_ptr->vel_equation_numbers, e_ptr->temp_equation_numbers,
               fill_flag );
	    }
	 }

	 if ( int_flags->vel_eqns == solve_vel )
         {
            if (matrix_group == all_equations || 
                matrix_group == velocity_only)
	    {
	       // assign space for diffusion-convection matrix
	       assign_skyline ( vel_num, vel_num, left, diag,
	       e_ptr->vel_equation_numbers, e_ptr->vel_equation_numbers,
               fill_flag );

               if (e_ptr->element_particle_type == element_contains_particle) 
                  assign_skyline ( vel_num, 
                  e_ptr->particle_degrees_of_freedom, left, diag,
	          e_ptr->vel_equation_numbers, e_ptr->part_equation_numbers,
                  fill_flag );

               if ( int_flags->turb_eqns == solve_turb )
	       {
                  // assign space for k-e matrices
	          assign_skyline ( numnod, numnod, left, diag,
	          e_ptr->turbk_equation_numbers, e_ptr->turbk_equation_numbers,
                  fill_flag );
	          assign_skyline ( numnod, numnod, left, diag,
	          e_ptr->turbe_equation_numbers, e_ptr->turbe_equation_numbers,
                  fill_flag );
	       }
	    }

            if ( matrix_group == all_equations )
	    {
	       // assign space for moving mass matrix
	       if ( int_flags->field_flag == full )
	          assign_skyline ( numnod, vel_num, left, diag,
	          e_ptr->r_equation_numbers, e_ptr->vel_equation_numbers,
                  fill_flag );

               // assign space for bouyancy terms if necessary
               if ( int_flags->buoy_term_flag != no_buoyancy )
                  assign_skyline ( numnod, vel_num, left, diag,
	          e_ptr->temp_equation_numbers, e_ptr->vel_equation_numbers,
                  fill_flag );
	    }

            // assign space for continuity equations if necessary
	    if ( int_flags->press_eqns == solve_press )
            {
               if ( matrix_group == all_equations )
	       {
                  // del p term in momentum equations 
	          assign_skyline ( vel_num, 
                  e_ptr->number_of_pressure_basis_fcns, left, diag,
                  e_ptr->vel_equation_numbers, e_ptr->press_equation_numbers,
                  fill_flag );
            
                  // del u term in continuity equations
                  assign_skyline ( e_ptr->number_of_pressure_basis_fcns, 
                  vel_num, left, diag,
                  e_ptr->press_equation_numbers, e_ptr->vel_equation_numbers,
                  fill_flag ); 
	       }

               // space for pXp 
               if ( matrix_group == all_equations ||
                    matrix_group == pressure_only )
                  assign_skyline ( e_ptr->number_of_pressure_basis_fcns, 
                  e_ptr->number_of_pressure_basis_fcns, left, diag,
                  e_ptr->press_equation_numbers, e_ptr->press_equation_numbers,
                  fill_flag );

               if ( int_flags->compress_flag == compressible )
               {
                  if ( matrix_group == all_equations )
		  {
                     assign_skyline ( vel_num, numnod, left, diag,
                        e_ptr->vel_equation_numbers, 
                        e_ptr->temp_equation_numbers, fill_flag );
  
                     assign_skyline ( e_ptr->number_of_pressure_basis_fcns,
                        numnod, left, diag, e_ptr->press_equation_numbers, 
                        e_ptr->temp_equation_numbers, fill_flag );

                     assign_skyline ( vel_num,
                        e_ptr->number_of_pressure_basis_fcns,
                        left, diag, e_ptr->vel_equation_numbers, 
                        e_ptr->press_equation_numbers, fill_flag );  
		  } 
	       }
	    }
	 }
         
         if ( int_flags->pot_eqns == solve_pot && 
           (matrix_group == all_equations || matrix_group == temperature_only))
         {
	    // assign space for diffusion-convection matrix
	    assign_skyline ( numnod, numnod, left, diag,
	       e_ptr->pot_equation_numbers, e_ptr->pot_equation_numbers,
               fill_flag );

	    // assign space for moving mass matrix
	    if ( int_flags->field_flag == full )
	       assign_skyline ( numnod, numnod, left, diag,
	          e_ptr->r_equation_numbers, e_ptr->pot_equation_numbers,
                  fill_flag );
	 }
       }
       e_item = e_item->next;
       if (e_item != 0) e_ptr = e_item->value;
       while ( e_item != 0 && 
               e_ptr->is_it_a_special_particle_element == special_particle_element )
       {
          e_item = e_item->next;
          if (e_item!=0) e_ptr = e_item->value;
       }
   }

   cout << "print out left: " << endl;
   for ( int j = 0; j < 10; ++j )
   {
     cout << left[j] << "  ";
   }
   cout << endl;
   cout << "print out diag: " << endl;
   for ( j = 0; j < 10; ++j )
   {
     cout << diag[j] << "  ";
   }
   cout << endl;
   // now assemble the diagonal array
   diag [0] = 0;
   for ( int eqn = 1; eqn < num_eqns; ++eqn)
   {
      diag [eqn] = diag [eqn-1] + 1 + left[eqn] + diag[eqn];
   }
   cout << "calling assign block structure: " << endl;
   assign_block_structure ( mysolve, sky_sizes );
   cout << "print out last diag entries: " << diag[num_eqns - 2] << "  " << diag[num_eqns - 1] << "\n";
}

void List::assign_skyline ( int num1, int num2, int* left, int* diag,
   int* eqn_numbers1, int* eqn_numbers2, fill_diag_flag fill_flag )
{
   int eqn1; int eqn2; int diff;
   for (int qn1 = 0; qn1 < num1; ++qn1)
   {
      eqn1 = eqn_numbers1 [qn1];
      if ( eqn1 <= 0 ) continue;
      for (int qn2 = 0; qn2 < num2; ++qn2)
      {
	 eqn2 = eqn_numbers2 [qn2];
	 if ( eqn2 <= 0 ) continue;
	 if ( eqn2 <= eqn1 )
	 {
	    diff = eqn1 - eqn2;
	    left [ eqn1-1 ] = max ( left[eqn1-1], diff );
	    if ( fill_flag == fill_diag )
	       diag [ eqn1-1 ] = max ( diag[eqn1-1], diff );
            else
               diag [ eqn1-1 ] = left [ eqn1-1 ];
         }
      }
   }
}

void List::assign_block_structure ( Solver_structure* mysolve,
   skyline_sizes* sky_sizes )
{
   int* diag = sky_sizes->diagonals;
   int num_eqns = mysolve->number_of_equations;
   cout << "in assign block structure: number of eqns: " << num_eqns << endl;

   if ( mysolve->setup_flag == first_time )
   {
      sky_sizes->first_eqn_in_block = new int [max_number_of_blocks];
      sky_sizes->last_eqn_in_block = new int [max_number_of_blocks];
   }
   sky_sizes->first_eqn_in_block[0] = 1;

   // find out how many blocks
   int total = 0; int last_end = 0;
   sky_sizes->number_of_blocks = 1;
   sky_sizes->size_of_block = sky_sizes->original_size_of_block;
   cout << "size of block: " << sky_sizes->size_of_block << endl;

   for ( int eqn = 0; eqn < num_eqns; ++eqn )
   {
      if ( (diag[eqn]-last_end) < sky_sizes->size_of_block ) continue;
      // reached end of block
      cout << "reached end of block at eqn: " << eqn << "  diag: " << diag[eqn] << "  last_end: " << last_end << endl;
      last_end = diag[eqn-1];
      sky_sizes->last_eqn_in_block[sky_sizes->number_of_blocks-1] = eqn;
      sky_sizes->first_eqn_in_block[sky_sizes->number_of_blocks] = eqn + 1;
      ++sky_sizes->number_of_blocks;
   }


   // the end of the last block holds the last equation
   sky_sizes->last_eqn_in_block[sky_sizes->number_of_blocks-1] = num_eqns;

   // make sure this is not too many blocks
   if ( sky_sizes->number_of_blocks > max_number_of_blocks )
   {
      cout << "error: more than maximum number of blocks \n";
      return;
   }   

   // reassign diag if more than 1 block
   if ( sky_sizes->number_of_blocks > 1 )
   {
      last_end = diag [sky_sizes->last_eqn_in_block[0]-1]+1; 
      for ( int block = 1; block < sky_sizes->number_of_blocks; ++block )
      {
         int first = sky_sizes->first_eqn_in_block[block];
         int last = sky_sizes->last_eqn_in_block[block];
         for ( int eqn = first-1; eqn < last; ++eqn )
         {
            diag[eqn] -= last_end; 
	 }
         last_end += diag [last-1] + 1;
      }
      sky_sizes->size_of_block = diag[num_eqns-1] + 1;
   }
   else
      sky_sizes->size_of_block = diag[num_eqns-1] + 1;
}


void List::fix_sizes_for_iterative ( Solver_structure* mysolve,
      integration_flags* int_flags, iterative_sizes* iter_sizes,
      int total_across )
{
   // for each element: setup up skyline structure only for the equations that are put into this matrix
   equation_groups matrix_group = mysolve->matrix_group;

   int num_eqns = mysolve->number_of_equations;
   cout << "at beginning of fix sizes: " << num_eqns << "\n";
   int* pivots = iter_sizes->pivots;
   for ( int k = 0; k < num_eqns; ++k )
   {
      pivots [k] = 0;
   }

   // set up working space to configure the data needed for the
   // iterative solver
   int dummy_size = 6 * num_eqns * total_across; 
   int* collect = new int [ dummy_size ];
   int* dummy = new int [num_eqns];
   // initialize collect with values larger than num_eqns
   for ( int j = 0; j < dummy_size; ++j )
   {
      collect [j] = num_eqns + 1;
   }
   int fill_row = 0;
   int mass_dof = int_flags->mass_degrees_of_freedom;
   int surf_dof = int_flags->surf_degrees_of_freedom;
   int vel_dof = int_flags->vel_degrees_of_freedom;
   int free_surf_dof = int_flags->number_of_free_surf_equations;
   int numnod = 0; 
   int qnum = 0; int qmass = 0; int qfree = 0; int qvel = 0;
   int mass_num = 0; int vel_num = 0; int numtot = 0;
   // Loop through elements assigning row_eqn numbers; Then formulate
   // pivot and row_start arrays from row_eqn information
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   int press_num = e_ptr->find_number_of_pressures ( );
   while (e_item != 0)
   {
      while ( e_item != 0 || 
               e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }

      numnod = e_ptr->number_of_nodes;
      if ( e_ptr->dimension == one_dimensional )
      {
         qnum = e_ptr->quad_number_of_nodes;
	 qmass = mass_dof * qnum;
         qfree = free_surf_dof * qnum;
         qvel = vel_dof * qnum;
         if ( e_ptr->moving_type  == line && 
         (matrix_group == all_equations || matrix_group == temperature_only ))
         {
	    // assign space for mass matrix
	    assign_iterative ( collect, total_across, num_eqns,
               numnod, numnod,
	       e_ptr->el_equation_numbers, e_ptr->el_equation_numbers );
	    // assign space for rhs derivatives for moving boundary equations
	    assign_iterative ( collect, total_across, num_eqns,
                numnod, qmass, 
	        e_ptr->el_equation_numbers, e_ptr->quad_c_eqns );
            if ( e_ptr->elem_bc->mass_bc[0] == chemical_rxn )
	    {
               assign_iterative ( collect, total_across, num_eqns,
                  numnod, qmass, 
	          e_ptr->el_equation_numbers, e_ptr->quad_c_eqns );
               if ( int_flags->temp_eqns == solve_temp )
                  assign_iterative ( collect, total_across, num_eqns,
                  numnod, qnum, 
	          e_ptr->el_equation_numbers, e_ptr->quad_temp_eqns );
               if ( e_ptr->elem_bc->free_surf_bc[0] == free_surf &&
                    int_flags->initial_flag == not_solving_for_initial )
                  assign_iterative ( collect, total_across, num_eqns,
                     numnod, qnum*surf_dof, e_ptr->el_equation_numbers, 
                     e_ptr->surf_equation_numbers );
	    }
	 }

         // assign space for surface reactants
         if ( e_ptr->elem_bc->surf_bc[0] != none &&  
          (matrix_group == all_equations || matrix_group == temperature_only ))
	 {
	    assign_iterative ( collect, total_across, num_eqns,
               surf_dof*numnod, surf_dof*numnod, 
	       e_ptr->surf_equation_numbers, e_ptr->surf_equation_numbers );
            assign_iterative ( collect, total_across, num_eqns,
               surf_dof*numnod, qmass, 
	       e_ptr->surf_equation_numbers, e_ptr->quad_c_eqns );
            assign_iterative ( collect, total_across, num_eqns,
               surf_dof*numnod, qnum, 
	       e_ptr->surf_equation_numbers, e_ptr->quad_temp_eqns );
            assign_iterative ( collect, total_across, num_eqns,
               qmass, surf_dof*numnod, e_ptr->quad_c_eqns,
	       e_ptr->surf_equation_numbers );
	 }

         if ( (e_ptr->elem_bc->mass_bc[0] == diffuse_adsorption ||
               e_ptr->elem_bc->mass_bc[0] == polymer_adsorption) && 
          (matrix_group == all_equations || matrix_group == temperature_only ))
	 {
            assign_iterative ( collect, total_across, num_eqns,
               qmass, qmass, 
	       e_ptr->quad_c_eqns, e_ptr->quad_c_eqns );
            assign_iterative ( collect, total_across, num_eqns,
               qnum, qmass, 
	       e_ptr->quad_pot_eqns, e_ptr->quad_c_eqns );
            assign_iterative ( collect, total_across, num_eqns,
               qmass, qnum, 
	       e_ptr->quad_c_eqns, e_ptr->quad_pot_eqns );
	 }
         if ( int_flags->moving_boundary_field == temperature &&
              e_ptr->moving != stationary &&
           (matrix_group == all_equations || matrix_group == temperature_only))
         {
            assign_iterative ( collect, total_across, num_eqns,
               numnod, qnum, 
               e_ptr->el_equation_numbers, e_ptr->quad_temp_eqns );
	 }

         if ( e_ptr->elem_bc->free_surf_bc[0] == free_surf)
	 {
            if (matrix_group == all_equations || 
                matrix_group == temperature_only) 
	    {
               //dh_kinematic 
               assign_iterative ( collect, total_across, num_eqns,
			       numnod, numnod, e_ptr->el_equation_numbers, 
                               e_ptr->el_equation_numbers);
               //dh_stress
               assign_iterative ( collect, total_across, num_eqns,
			       free_surf_dof*numnod, numnod, 
                               e_ptr->free_surf_equation_numbers, 
                               e_ptr->el_equation_numbers);
               //space for free_surf X free_surf
               assign_iterative ( collect, total_across, num_eqns,
			       free_surf_dof*numnod, 
                               free_surf_dof*numnod, 
                               e_ptr->free_surf_equation_numbers, 
                               e_ptr->free_surf_equation_numbers);
	    }

            if (matrix_group == all_equations )
	    {
               //dv_kinematic
               assign_iterative ( collect, total_across, num_eqns,
			       numnod, qfree, e_ptr->el_equation_numbers, 
                               e_ptr->quad_vel_eqns);
               //dv_stress
               assign_iterative ( collect, total_across, num_eqns,
			       free_surf_dof*numnod, qfree, 
                               e_ptr->free_surf_equation_numbers, 
                               e_ptr->quad_vel_eqns);
            
               //dp_stress
               assign_iterative ( collect, total_across, num_eqns,
			       free_surf_dof*numnod, 
                               press_num, 
                               e_ptr->free_surf_equation_numbers, 
                               e_ptr->quad_press_eqns);
	    }
         }
         
         // assign space for particle equations if particles are present
         if ( e_ptr->elem_bc->particle_bc[0] == particle_surface && 
            (matrix_group == velocity_only || matrix_group == all_equations))
         { 
            // particle constraint equations - translational velocities
            assign_iterative ( collect, total_across, num_eqns,
			       e_ptr->particle_degrees_of_freedom, 
                               qvel, 
                               e_ptr->part_equation_numbers, 
                               e_ptr->quad_vel_eqns);

            assign_iterative ( collect, total_across, num_eqns,
			       qvel, e_ptr->particle_degrees_of_freedom, 
                               e_ptr->quad_vel_eqns,
                               e_ptr->part_equation_numbers );

            // particle constraint equations - rotational velocity
            assign_iterative ( collect, total_across, num_eqns,
			       e_ptr->particle_degrees_of_freedom, 
                               e_ptr->particle_degrees_of_freedom, 
                               e_ptr->part_equation_numbers, 
                               e_ptr->part_equation_numbers );

            // particle constraint equations - pressure terms
            assign_iterative ( collect, total_across, num_eqns,
			       e_ptr->particle_degrees_of_freedom, 
                               press_num, 
                               e_ptr->part_equation_numbers, 
                               e_ptr->quad_press_eqns);
         }
      }
      if ( e_ptr->dimension == two_dimensional )
      {
         numtot = e_ptr->total_nodes;
         mass_num = numtot*e_ptr->mass_degrees_of_freedom;
         vel_num = numtot*e_ptr->vel_degrees_of_freedom;
	 if ( int_flags->mass_eqns == solve_mass &&  
           (matrix_group == all_equations || matrix_group == temperature_only))
	 {
	    // assign space for diffusion-convection matrix
	    assign_iterative ( collect, total_across, num_eqns,
               mass_num, mass_num,   
	       e_ptr->el_equation_numbers, e_ptr->el_equation_numbers );

	    // assign space for derivatives of velocities
	    if ( int_flags->vel_eqns == solve_vel &&  
                 matrix_group == all_equations )
	       assign_iterative ( collect, total_across, num_eqns,
               mass_num, vel_num,
	       e_ptr->el_equation_numbers, e_ptr->vel_equation_numbers );
            
            if ( int_flags->temp_eqns == solve_temp && 
           (matrix_group == all_equations || matrix_group == temperature_only))
	    {
               if ( int_flags->thermdiff_term_flag == include_thermdiff ||
                    int_flags->reaction_term_flag == include_reaction )
               assign_iterative ( collect, total_across, num_eqns,
               mass_num, numnod, 
	       e_ptr->el_equation_numbers, e_ptr->temp_equation_numbers );

	       // assign space for moving mass matrix
	       if ( int_flags->field_flag == full &&
                  int_flags->moving_flag == boundary_moves )
	             assign_iterative ( collect, total_across, num_eqns,
                     mass_num, numnod, 
	             e_ptr->el_equation_numbers, e_ptr->r_equation_numbers );
	    }
	 }

	 if ( int_flags->temp_eqns == solve_temp && 
          (matrix_group == all_equations || matrix_group == temperature_only ))
	 {
	    // assign space for diffusion-convection matrix
	    assign_iterative ( collect, total_across, num_eqns,
               numnod, numnod, 
	       e_ptr->temp_equation_numbers, e_ptr->temp_equation_numbers );

	    // assign space for moving mass matrix
	    if ( int_flags->field_flag == full &&
                 int_flags->moving_flag == boundary_moves )
	       assign_iterative ( collect, total_across, num_eqns,
               numnod, numnod, 
	       e_ptr->temp_equation_numbers, e_ptr->r_equation_numbers );

            // assign space for velocity derivatives
            if ( int_flags->vel_eqns == solve_vel && 
                 matrix_group == all_equations )
               assign_iterative ( collect, total_across, num_eqns,
               numnod, vel_num, 
	       e_ptr->temp_equation_numbers, e_ptr->vel_equation_numbers );
           
	 }

	 if ( int_flags->vel_eqns == solve_vel &&  
          (matrix_group == all_equations || matrix_group == velocity_only))
	 {
	    // assign space for diffusion-convection matrix
	    assign_iterative ( collect, total_across, num_eqns,
               vel_num, vel_num,   
	       e_ptr->vel_equation_numbers, e_ptr->vel_equation_numbers );

            if ( e_ptr->element_particle_type == element_contains_particle ) 
               assign_iterative ( collect, total_across, num_eqns,
                  vel_num, e_ptr->particle_degrees_of_freedom,   
	          e_ptr->vel_equation_numbers, e_ptr->part_equation_numbers );

            if ( int_flags->turb_eqns == solve_turb )
	    {
               // assign space for k-e matrices
               assign_iterative ( collect, total_across, num_eqns,
                  numnod, numnod, e_ptr->turbk_equation_numbers, 
                  e_ptr->turbk_equation_numbers );
               assign_iterative ( collect, total_across, num_eqns,
                  numnod, numnod, e_ptr->turbe_equation_numbers, 
                  e_ptr->turbe_equation_numbers );
	    }

            if ( matrix_group == all_equations )
	    {
	       // assign space for moving mass matrix
	       if ( int_flags->field_flag == full &&
                 int_flags->moving_flag == boundary_moves )
	          assign_iterative ( collect, total_across, num_eqns,
                  vel_num, numnod,   
	          e_ptr->vel_equation_numbers, e_ptr->r_equation_numbers );

               // assign space for bouyancy terms if necessary
               if ( int_flags->buoy_term_flag != no_buoyancy )
                  assign_iterative ( collect, total_across, num_eqns,
                  vel_num, numnod,    
	          e_ptr->vel_equation_numbers, e_ptr->temp_equation_numbers );
	    }

            // assign space for continuity equations if necessary
	    if ( int_flags->press_eqns == solve_press)
	    {
               if ( matrix_group == all_equations )
	       {
                  // del p term in momentum equation
	          assign_iterative ( collect, total_across, num_eqns,
                  vel_num, e_ptr->number_of_pressure_basis_fcns,    
	          e_ptr->vel_equation_numbers, e_ptr->press_equation_numbers );

                  // del u term in continuity equations
	          assign_iterative ( collect, total_across, num_eqns,
                  e_ptr->number_of_pressure_basis_fcns, vel_num,  
	          e_ptr->press_equation_numbers, e_ptr->vel_equation_numbers );
	       }

               // make space for pXp 
               if ( matrix_group == all_equations ||
                    matrix_group == pressure_only )
                  assign_iterative ( collect, total_across, num_eqns,
                  e_ptr->number_of_pressure_basis_fcns,
                  e_ptr->number_of_pressure_basis_fcns,   
	          e_ptr->press_equation_numbers, e_ptr->press_equation_numbers );

               if ( int_flags->compress_flag == compressible )
               {
                  if ( matrix_group == all_equations )
		  {
                     assign_iterative ( collect, total_across, num_eqns,
                        vel_num, numnod, e_ptr->vel_equation_numbers, 
                        e_ptr->temp_equation_numbers );

                     assign_iterative ( collect, total_across, num_eqns,
                       e_ptr->number_of_pressure_basis_fcns, numnod,
	               e_ptr->press_equation_numbers, 
                       e_ptr->temp_equation_numbers );

                     assign_iterative ( collect, total_across, num_eqns,
                       vel_num, e_ptr->number_of_pressure_basis_fcns,
	               e_ptr->vel_equation_numbers, 
                       e_ptr->press_equation_numbers );
		  }
	       }
            }
	 }
         
         if ( int_flags->pot_eqns == solve_pot &&  
           (matrix_group == all_equations || matrix_group == temperature_only))
         {
	    // assign space for diffusion-convection matrix
	    assign_iterative ( collect, total_across, num_eqns,
            numnod, numnod, 
	    e_ptr->pot_equation_numbers, e_ptr->pot_equation_numbers );

	    // assign space for moving mass matrix
	    if ( int_flags->field_flag == full )
	       assign_iterative ( collect, total_across, num_eqns,
               numnod, numnod,  
	       e_ptr->pot_equation_numbers, e_ptr->r_equation_numbers );
	 }
       }
       e_item = e_item->next;
       if (e_item != 0) e_ptr = e_item->value;
       while ( e_item != 0 && 
               e_ptr->is_it_a_special_particle_element == special_particle_element )
       {
          e_item = e_item->next;
          if (e_item!=0) e_ptr = e_item->value;
       }      
   }

   // compute space for row_eqns
   for ( j = 0; j < dummy_size; ++j )
   {
      if ( collect[j] < num_eqns+1 ) ++fill_row;
   }
cout << "number filled: " << fill_row << "\n";

   // assign space for row_eqns and fill it in
   int row_size = num_eqns + 1 + fill_row;
   cout << "fill_row: " << fill_row << "  row_size: " << row_size << endl;
   int* row_eqns = new int [row_size];

   iter_sizes->row_eqns = row_eqns;
   for ( int rw = 0; rw < num_eqns + 1 + fill_row; ++rw )
   {
      row_eqns[rw] = 0;
   }
   int row_place = num_eqns + 1;
   int collect_place = 0;
   row_eqns[0] = row_place;
   for ( int row = 0; row < num_eqns; ++row )
   {
      collect_place = total_across * row;
      for ( int col = 0; col < total_across; ++col )
      {
         // fill in pivot array
         if ( collect[collect_place] < num_eqns+1  )
         {
            row_eqns[row_place] = collect[collect_place];
            ++row_place;
            ++collect_place;
            if ( col == total_across-1 )
               row_eqns[row+1] = row_place;
         }
         else
         {
            row_eqns[row+1] = row_place;
            break;
         }
      }
   }

   // sort each row of equation numbers in row_eqns
   for ( row = 0; row < num_eqns; ++row )
   {
      int place = row_eqns[row];
      int size = row_eqns[row+1] - place;
      bsort ( &row_eqns[place], size );  
   }

   // set the pivot array
   int first = 0; int last = 0;
   for ( row = 0; row < num_eqns; ++row )
   {
      if ( row == 0 ) 
         first = row_eqns[0]; 
      else
         first = row_eqns[row];
      last = row_eqns[row+1] - 1;
      pivots[row] = 0;
      for ( int col = first; col <= last; ++col )
      {
         if ( row_eqns[col] == row+1 ) pivots[row] = col + 1;
      }
   }

   iter_sizes->a_matrix_size = pivots[num_eqns - 1];
cout << "matrix size here: " << iter_sizes->a_matrix_size << "\n";
   iter_sizes->b_matrix_size = pivots[num_eqns - 1];
   if ( iter_sizes->igauss > 0 )
   {
      // now set up the nop array
      int* dummy_nop = new int [ dummy_size ];
      // initialize array
      for ( int j = 0; j < dummy_size; ++j )
      {
         dummy_nop[j] = 0;
      }

      cout << "about to set up the nop array   \n";
      int nop_size = nopcnv_ ( collect, &iter_sizes->igauss, &num_eqns,
                              row_eqns,
                              dummy_nop, pivots, dummy, &dummy_size );
      // delete old big space and assign a new smaller one
      iter_sizes->b_matrix_size = nop_size;
      iter_sizes->nop = new int[num_eqns + 1 + iter_sizes->b_matrix_size];
      for ( int w = 0; w < num_eqns + 1 + iter_sizes->b_matrix_size; ++w )
      {
         iter_sizes->nop[w] = dummy_nop[w];
      }
      delete [] dummy_nop;
      cout << "print out nop_size after nopcnv: " << nop_size << "  " << iter_sizes->nop[num_eqns-1] << "  " << iter_sizes->nop[num_eqns] << "  " << iter_sizes->nop[num_eqns+1] << "\n";
   }
cout << "print out row_eqns after nopcnv: ";
for ( int w = 0; w < fill_row + 1 + num_eqns; ++w )
  {
     if ((fill_row + 1 + num_eqns) < 600 ) cout << row_eqns[w] << " ";
   }
   cout << "\n";
   delete [] collect;
   delete [] dummy;
}

void List::assign_iterative ( int* collect, int total_across, int numeqns,
     int num1, int num2, int* eqn_numbers1, int* eqn_numbers2 )
{
   // for each row of row_eqns, add column numbers to collect array
   int eqn1; int eqn2;

   for (int qn1 = 0; qn1 < num1; ++qn1)
   {
      eqn1 = eqn_numbers1 [qn1];
      if ( eqn1 <= 0 ) continue;
      int start_row = (eqn1-1) * total_across;
      for (int qn2 = 0; qn2 < num2; ++qn2)
      {
         eqn2 = eqn_numbers2 [qn2];
         if ( eqn2 <= 0 ) continue;
         // if equation 2 is not on eqn 1's list: add it
         for ( int q = 0; q < total_across; ++q )
         {
            if ( collect[start_row+q] == eqn2 ) break;
            if ( collect[start_row+q] > numeqns )
            {
               collect[start_row+q] = eqn2;
               break;
            } 
         }
      }
   }
}

void List::fill_skyline ( Solver_structure* mysolve,
    myvar* rhs_vector, skyline_sizes* sky_sizes )
{
   // fill the skyline matrix with element entries for the equations in this matrix
   equation_groups matrix_group = mysolve->matrix_group;

   int* left = sky_sizes->left_sides;
   int* diag = sky_sizes->diagonals;
   myvar* matrix = mysolve->matrix;

   // fill the first block into matrix; fill the other blocks into
   // matrix and then dump them out to files

   int blocks = sky_sizes->number_of_blocks;
   for ( int bl = blocks-1; bl >=  0; --bl )
   {
      int first = sky_sizes->first_eqn_in_block[bl];
      int last = sky_sizes->last_eqn_in_block[bl];
      cout << "print out first and last: " << first << "  " << last << endl;
      for ( int j = 0; j < mysolve->matrix_size; ++j )
      {
	matrix [j] = 0.0;
      }
      Item_Element* e_item = top_element;
      Element* e_ptr = top_element->value;
      while (e_item != 0)
      {
         e_ptr->e_matrix_into_skyline
	    ( left, diag, first, last, matrix, rhs_vector, matrix_group );
         e_item = e_item->next;
         if (e_item != 0) e_ptr = e_item->value;
         while ( e_item != 0 && 
         e_ptr->is_it_empty == empty )
         {
            e_item = e_item->next;
            if (e_item!=0) e_ptr = e_item->value;
         }      
      }

      // if there is more than one block, read the block to disc
      if ( blocks > 1 )
         mysolve->write_matrix_to_file
            ( bl, mysolve->matrix, mysolve->matrix_size );
   }
}

void List::fill_iterative ( Solver_structure* mysolve,
    myvar* rhs_vector, iterative_sizes* iter_sizes )
{
   // fill the iterative matrix with element entries for the equations in this matrix
   equation_groups matrix_group = mysolve->matrix_group;

   int* pivots = iter_sizes->pivots;
   int* row_eqns = iter_sizes->row_eqns;
   myvar* matrix = mysolve->matrix;
   for ( int j = 0; j < mysolve->matrix_size; ++j )
   {
	matrix [j] = 0.0;
   }
   int numeqns = mysolve->number_of_equations;
   for ( j = 0; j < numeqns; ++j )
   {
	rhs_vector [j] = 0.0;
   } 
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0)
   {
      e_ptr->e_matrix_into_iterative
	  ( row_eqns, matrix, rhs_vector, matrix_group );
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;;      
   }
}

void List::integrate ( equation_groups matrix_group )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0)
   {
      if ( e_ptr->element_number > 0 ) e_ptr->get_node_coordinates ( );
      e_ptr->fill_el_matrix ( matrix_group );
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;
      while ( e_item != 0 && 
         e_ptr->is_it_a_special_particle_element == special_particle_element )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }      
   }
}

void List::element_resid ( int number_of_equations, myvar* residual,
    solution_vectors* soln_vec, equation_groups matrix_group )
{
   for ( int eqn = 0; eqn < number_of_equations; ++eqn )
   {
      residual [eqn] = 0.0;
   }

   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;

   while (e_item != 0)
   {
      e_ptr->elem_residual_calc ( residual, soln_vec, matrix_group );
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;
      while ( e_item != 0 && 
         e_ptr->is_it_empty == empty )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
   }
}

void List::update_matrices ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   while (e_item != 0)
   {
      while ( e_ptr->element_number < 0 )
      {
         e_item = e_item->next;
         if (e_item!=0) e_ptr = e_item->value;
      }
      e_ptr->update_matrices ( );
      e_item = e_item->next;
      if (e_item != 0) e_ptr = e_item->value;;      
   }
}


void List::move_the_mesh_forward  ( myvar* rnew )
{
   Item_Moving* m_item = top_moving;
   Moving_boundary_entity* m_ptr = top_moving->value;
   while (m_item != 0 )
   {
      m_ptr->move_the_mesh_forward  ( rnew );
      m_item = m_item->next;
      if (m_item!=0) m_ptr = m_item->value;
   }
}

void List::move_the_mesh_back ( )
{
   Item_Moving* m_item = top_moving;
   Moving_boundary_entity* m_ptr = top_moving->value;
   while (m_item != 0 )
   {
      m_ptr->move_the_mesh_back (  );
      m_item = m_item->next;
      if (m_item!=0) m_ptr = m_item->value;
   }
}

void List::put_back_original_coordinates ( )
{
   Item_Moving* m_item = top_moving;
   Moving_boundary_entity* m_ptr = top_moving->value;
   while (m_item != 0 )
   {
      m_ptr->put_back_original_coordinates (  );
      m_item = m_item->next;
      if (m_item!=0) m_ptr = m_item->value;
   }
}

void List::save_old_coordinates ( )
{
   Item_Moving* m_item = top_moving;
   Moving_boundary_entity* m_ptr = top_moving->value;
   while (m_item != 0 )
   {
      m_ptr->save_old_coordinates ( );
      m_item = m_item->next;
      if (m_item!=0) m_ptr = m_item->value;
   }
}

void List::print_xy_for_restart ( )
{
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   while (n_item != 0 )
   {
      n_ptr->print_xy_for_restart ( );
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
   }
}

void List::read_xy_from_restart ( )
{
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   while (n_item != 0 )
   {
      n_ptr->read_xy_from_restart ( );
      n_item = n_item->next;
      if (n_item!=0) n_ptr = n_item->value;
   }
}

void List::original_slopes ( )
{
   Item_Moving* m_item = top_moving;
   Moving_boundary_entity* m_ptr = top_moving->value;
   while (m_item != 0 )
   {
      m_ptr->original_slopes ( );
      m_item = m_item->next;
      if (m_item!=0) m_ptr = m_item->value;
   }
}

