#include "mesh-fem.h"

Mesh::Mesh ( )
{
}

int Mesh::Set_up_mesh ( ) {
  // open the data file
  FILE* fp = fopen("mesh_input", "r");

  // read the file and set things up
  fscanf(fp, "%d %d %d", &number_of_nodes,&number_constrained,&number_of_elements);
  printf("%d %d %d\n",number_of_nodes,number_constrained,number_of_elements);
 
  // read in coordinates
  int num, mult, oldnum;
  float xx,yy,zz;
  myvar oldx, oldy;
  int cnt = 0;
  node_list = new Node*[number_of_nodes];
  while (cnt < number_of_nodes) {
    fscanf(fp, "%d %f %f %f %d",&num,&xx,&yy,&zz,&mult);
    //printf("reading: %d %f %f %f %d\n",num,xx,yy,zz,mult);
    if (mult < 1) {
      // just make a node
      node_list[cnt] = new Node(cnt, xx, yy);
      ++cnt;
      oldnum = num;
      oldx = xx;
      oldy = yy;
    }
    else {
      // generate a set
      int newnum = (num - oldnum) / mult;
      myvar dx = (xx - oldx) / newnum;
      myvar dy = (yy - oldy) / newnum;
      for (int nd = 0; nd < newnum; ++nd ) {
	xx = oldx + (nd+1)*dx;
	yy = oldy + (nd+1)*dy;
	node_list[cnt] = new Node(cnt, xx, yy);
	++cnt;	
      }
    }
  }

  // enter constrained
  cnt = 0;
  float uu,vv;
  while (cnt < number_constrained) {
    fscanf(fp, "%d %f %f %d",&num,&uu,&vv,&mult);
    //printf("num uu vv mult: %d %f %f %d\n",num,uu,vv,mult);
    if (mult < 1) {
      // update node num
      node_list[num-1]->uval = uu;
      node_list[num-1]->vval = vv;
      node_list[num-1]->constrained = true;
      //printf("fixed node %d %f %f\n",num,uu,vv);
      oldnum = num;
      oldx = uu;
      oldy = vv;
      ++cnt;
    }
    else {
      // generate a set
      int newnum = (num - oldnum) / mult;
      myvar dx = (uu - oldx) / newnum;
      myvar dy = (vv - oldy) / newnum;
      for (int nd = 0; nd < newnum; ++nd ) {
	uu = oldx + (nd+1)*dx;
	vv = oldy + (nd+1)*dy;
	num = oldnum + (nd+1)*mult;
	//printf("update: %d %f %f\n",num,uu,vv);
	// update node num
	node_list[num-1]->uval = uu;
	node_list[num-1]->vval = vv;
	node_list[num-1]->constrained = true;
	++cnt;	
      }
    }
  }
  printf("cnt after constrained: %d\n",cnt);

  // input initial solution
  cnt = 0;
  while (cnt < number_of_nodes) {
    fscanf(fp, "%d %f %f %d",&num,&uu,&vv,&mult);
    printf("next init: %d %f %f %d\n",num,uu,vv,mult);
    if (mult < 1) {
      // update node num
      node_list[num-1]->initialu = uu;
      node_list[num-1]->initialv = vv;
      oldnum = num;
      oldx = uu;
      oldy = vv;
      ++cnt;
      //printf("cnt: %d node: %d valu: %f\n",cnt,num,uu);
    }
    else {
      // generate a set
      int newnum = (num - oldnum) / mult;
      myvar dx = (uu - oldx) / newnum;
      myvar dy = (vv - oldy) / newnum;
      for (int nd = 0; nd < newnum; ++nd ) {
	uu = oldx + (nd+1)*dx;
	vv = oldy + (nd+1)*dy;
	num = oldnum + (nd+1)*mult;
	// update node num
	node_list[num-1]->initialu = uu;
	node_list[num-1]->initialv = vv;
	++cnt;	
      }
    }
  }
  printf("cnt for initial values: %d\n",cnt);
 
   // initial the element computation space
   int amount_of_space = 2000;
   myvar* computation_space = new myvar[amount_of_space];
  // enter element connectivities
  element_list = new Element*[number_of_elements];
  for (int i = 0; i <number_of_elements; i++) {
    element_list[i] = new Element(i, computation_space);
    // read in element
    fscanf(fp, "%d %d %d %d %d %d %d %d %d",
	   &element_list[i]->connectivity[0],
	   &element_list[i]->connectivity[1],
	   &element_list[i]->connectivity[2],
	   &element_list[i]->connectivity[3],
	   &element_list[i]->connectivity[4],
	   &element_list[i]->connectivity[5],
	   &element_list[i]->connectivity[6],
	   &element_list[i]->connectivity[7],
	   &element_list[i]->connectivity[8]);
    // input starts at node 1, not 0; subtract 1 from everything
    element_list[i]->connectivity[0] -= 1;
    element_list[i]->connectivity[1] -= 1;
    element_list[i]->connectivity[2] -= 1;
    element_list[i]->connectivity[3] -= 1;
    element_list[i]->connectivity[4] -= 1;
    element_list[i]->connectivity[5] -= 1;
    element_list[i]->connectivity[6] -= 1;
    element_list[i]->connectivity[7] -= 1;
    element_list[i]->connectivity[8] -= 1;
    /*printf("%d %d %d %d %d %d %d %d %d\n",
	   element_list[i]->connectivity[0],
	   element_list[i]->connectivity[1],
	   element_list[i]->connectivity[2],
	   element_list[i]->connectivity[3],
	   element_list[i]->connectivity[4],
	   element_list[i]->connectivity[5],
	   element_list[i]->connectivity[6],
	   element_list[i]->connectivity[7],
	   element_list[i]->connectivity[8]);*/

    // assign node pointers
    element_list[i]->connect_ptrs = new Node*[9];
    for (int j = 0; j < 9; ++j) {
      element_list[i]->connect_ptrs[j] = 
	node_list[element_list[i]->connectivity[j]];
    }
  }

  // find the total number of equations to solve and return
  int totalnum = 0;
  int nconstr = 0;
  for (int j = 0; j < number_of_nodes; ++j) {
    // see if this node is constrained
    if (node_list[j]->constrained) {
      node_list[j]->ueqn = nconstr - 1;
      --nconstr;
      node_list[j]->veqn = nconstr - 1;
      //printf("node: %d u %d v %d\n",j,node_list[j]->ueqn,node_list[j]->veqn);
      --nconstr;
    }
    else {
      node_list[j]->ueqn = totalnum;
      ++totalnum;
      node_list[j]->veqn = totalnum;
      //printf("node: %d u %d v %d\n",j,node_list[j]->ueqn,node_list[j]->veqn);
      ++totalnum;
    }
  }

  number_of_equations = totalnum; 
 
  // form the initial solution vector
  initial_soln = new myvar[number_of_equations];
  cnt = 0;
  for (int j = 0; j < number_of_nodes; ++j) {
    if (!node_list[j]->constrained) {
      initial_soln[cnt] = node_list[j]->initialu;
      ++cnt;
      initial_soln[cnt] = node_list[j]->initialv;
      ++cnt;
    }
  }

  // now go through each element's eqn number array and fill it in
  int nd;
  for (int i = 0; i <number_of_elements; i++) {
    for (int j = 0; j < 9; ++j) {
      nd = element_list[i]->connectivity[j];
      element_list[i]->vel_equation_numbers[2*j] = node_list[nd]->ueqn;
      element_list[i]->vel_equation_numbers[2*j+1] = node_list[nd]->veqn;

      // fill in x and y arrays in deriv
      element_list[i]->deriv->x_vals[j] = node_list[nd]->x;
      element_list[i]->deriv->y_vals[j] = node_list[nd]->y;
    }
  }

  return totalnum;
}

void Mesh::assign_skyline (skyline_sizes* sky) {
  for ( int k = 0; k < number_of_equations; ++k )
   {
      sky->left[k] = 0;
      sky->diag[k] = 0;
   }

  // loop through elements and
  // assign space for diffusion-convection matrix
  int eqn1; int eqn2; int diff;
  for (int i = 0; i < number_of_elements; ++i) {
    Element* el = element_list[i];
    for (int qn1 = 0; qn1 < 18; ++qn1) {
      eqn1 = el->vel_equation_numbers[qn1];
      if ( eqn1 < 0 ) continue;
      for (int qn2 = 0; qn2 < 18; ++qn2) {
	eqn2 = el->vel_equation_numbers[qn2];
	if ( eqn2 < 0 ) continue;
	if ( eqn2 <= eqn1 ) {
	  diff = eqn1 - eqn2;
	  sky->left [eqn1] = max ( sky->left[eqn1], diff );
	  sky->diag[eqn1] = max ( sky->diag[eqn1], diff );
	}
      }
    }
  }

  /*printf("print out left: ");
   for ( int j = 0; j < number_of_equations; ++j )
   {
     printf(" %d ",sky->left[j]);
   }
   printf("\n");*/

   // now assemble the diagonal array
   sky->diag [0] = 0;
   for ( int eqn = 1; eqn < number_of_equations; ++eqn)
   {
      sky->diag [eqn] = sky->diag [eqn-1] + 1 + 
	sky->left[eqn] + sky->diag[eqn];
   }

   /*printf("print out diag: ");
   for ( int j = 0; j < number_of_equations; ++j )
   {
     printf(" %d ",sky->diag[j]);
   }
   printf("\n");*/

  sky->matrix_size = sky->diag[number_of_equations-1] + 1;
  printf("size of matrix: %d\n",sky->matrix_size);  
}

void Mesh::fill_el_matrix ( ) {
  for (int i = 0; i < number_of_elements; ++i) {
    //printf("fill el: %d\n",i);
    element_list[i]->fill_el_matrix();
  }
}

void Mesh::fill_global_matrix ( myvar* matrix, int* left, int* diag ) {
  for (int i = 0; i < number_of_elements; ++i) {
    int veld = 2 * element_list[0]->number_of_nodes;
    // fill in difconv
    element_list[i]->element_to_global_skyline(matrix, left, diag, 1.0,
      veld, veld, element_list[i]->difcon_v,
      element_list[i]->vel_equation_numbers,
      element_list[i]->vel_equation_numbers);

    // fill in vduv
    element_list[i]->element_to_global_skyline(matrix, left, diag, 1.0,
      veld, veld, element_list[i]->v_duv,
      element_list[i]->vel_equation_numbers,
      element_list[i]->vel_equation_numbers);
  }
}

void Mesh::element_resid (myvar* residual, myvar* solution) {
  myvar resid = 0.0;
  //printf("starting residual calc with solution: %f %f %f %f\n",solution[0],solution[1],solution[2],solution[3]);
  for (int i = 0; i < number_of_elements; ++i) {
    //printf("calling element number: %d\n",i);
    element_list[i]->find_residual(residual, solution);
  }
  //printf("end of find resid: print it:\n");
  //for (int i = 0; i < number_of_equations; ++i) {
  //  printf(" %f ",residual[i]);
  //}
  //printf("\n");
  //printf("at end of mesh element resid: %f %f\n",residual[0],solution[0]);
}

void Mesh::update_nodes( myvar* solution ) {
  for (int j = 0; j < number_of_nodes; ++j) {
    // see if this node is constrained
    if (node_list[j]->ueqn > -1) {
      node_list[j]->uval = solution[node_list[j]->ueqn];
      node_list[j]->vval = solution[node_list[j]->veqn];
      //printf("updating node: %d with values: %f %f\n",j,solution[node_list[j]->ueqn],solution[node_list[j]->veqn]);
    }
  }
}

void Mesh::printSolution() {
  int cnt = 0;
  int cnt5 = 0;
  float uval;
  printf("new solution: \n");
  while (cnt < number_of_nodes) {
    // find uval
    uval = node_list[cnt]->uval;
    printf(" %10.8f ",uval);
    ++cnt;
    ++cnt5;
    if (cnt5 == 5) {
      printf("\n");
      cnt5 = 0;
    }
  }
  printf("\n");
}
