#ifndef SOLVERSKY_H
#define SOLVERSKY_H

class Solver_skyline : public Solver_structure
{
   public:
      Solver_skyline ( Mesh*, equation_groups, int );
      void size_the_global_matrix ( );
      void assign_sizes ( );
      void fill_global_matrix ( );
      void solve_the_matrix ( myvar* );
      void assign_block_structure ( );
      void print_diagonals ( );

   protected:
      skyline_sizes* field_sizes;
      myvar* sub_matrix;
};

#endif
