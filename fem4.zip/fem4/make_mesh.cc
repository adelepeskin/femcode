#include <fstream.h>

main()
{
   // this program creates a regular mesh of 4 node elements
   // open the output file

   ofstream heat_data;
   heat_data.open ( "make_mesh_out", ios::out );
   

   // first create the nodes
   int number_x_nodes = 61;
   int number_y_nodes = 61;
   double top_y = 0.0021;  double top_x = 0.0021; double delta = 3.5e-5;
   int node_number = 1; int gen = 1; int no_gen = 0;

   for ( int row = 0; row < number_y_nodes; ++row )
   {
      heat_data << number_x_nodes*row + 1 << "   " << 0.0 << "   " << top_y - delta*row << "   " << 0.0 << "   " << no_gen << "\n";
      heat_data << number_x_nodes*row + number_x_nodes << "   " << top_x << "   " << top_y - delta*row << "   " << 0.0 << "   " << gen << "\n";
   }

   gen = 0;
   // create constraints on the outside nodes
   for ( row = 0; row < number_y_nodes; ++row )
   {
      heat_data << number_x_nodes*row + 1 << "   " << 0.0 << "   " << 0.0 << "   " << no_gen << endl;
      heat_data << number_x_nodes*row + number_x_nodes << "   " << 0.0 << "   " << 0.0 << "   " << no_gen << endl;
   } 

   // now create the elements
   for ( row = 0; row < number_y_nodes - 1; ++row )
   {
      for ( int col = 0; col < number_x_nodes - 1; ++col )
      {
         heat_data << number_x_nodes*row + number_x_nodes + 1 + col << "   " 
                   << number_x_nodes*row + number_x_nodes + 2 + col << "   " 
                   << number_x_nodes*row +   2 + col << "   " 
                   << number_x_nodes*row +   1 + col << "   "
                   << "\n";
      }
   }

   int number_of_elements = (number_x_nodes-1)*(number_y_nodes-1);
   int cnt = 0;
   while ( cnt < number_of_elements )
   {
      for ( int j = 0; j < 20; ++j )
      {
         heat_data << 0.0 << "  ";
         ++cnt;
         if ( cnt == number_of_elements ) j = 20;
      }
      heat_data << endl;
   }


   for ( int d = 0; d < 10; ++d )
   {
       heat_data << d+1 << "  " << d + 2 << "  " << d+13 << "  " << d+12 << endl;
    }
}

