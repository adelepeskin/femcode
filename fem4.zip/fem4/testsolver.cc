#include <stdio.h>
#include <fstream.h>
#include <math.h>

double max ( double first, double second )
{
   if ( first > second ) return first;
   return second;
}
int min ( int first, int second )
{
   if ( first < second ) return first;
   return second;
}

int max ( int first, int second )
{
   if ( first > second ) return first;
   return second;
}
double dot_product ( double* vector_a, double* vector_b, int length )
{
   double product = 0.0;
   if ( length < 1 ) return product;
   for ( int cnt = 0; cnt < length; ++cnt )
   {
      product += vector_a [cnt] * vector_b [cnt];
      printf("prod: %f  a: %f   b: %f\n",product,vector_a[cnt],vector_b[cnt]);
   }
   printf("length: %d, product: %f\n",length,product);
   return product;
}

int main( int argc, char** argv )
{
  // set up the solver
  double* matrix = new double[16];
  for (int i = 0; i < 16; ++i) {
    matrix[i] = 1.0;
  }
  matrix[0] = 2.0;
  matrix[3] = 2.0;
  matrix[8] = 2.0;
  matrix[15] = 2.0;

  int* left = new int[4];
  int* diag = new int[4];

  left[0] = 0;
  left[1] = 1;
  left[2] = 2;
  left[3] = 3;

  diag[0] = 0;
  diag[1] = 3;
  diag[2] = 8;
  diag[3] = 15;

  int number_of_equations = 4;
  double* solution = new double[4];
  double* delta_soln = new double[4];
  double* rhs = new double[4];
  rhs[0] = 5.0;
  rhs[1] = 5.0;
  rhs[2] = 5.0;
  rhs[3] = 5.0;
  delta_soln[0] = 0.0;
  delta_soln[1] = 0.0;
  delta_soln[2] = 0.0;
  delta_soln[3] = 0.0;
  solution[0] = 1.0;
  solution[1] = 1.0;
  solution[2] = 1.0;
  solution[3] = 1.0;
  int matrix_size = 16;
  double machine_zero = 1.0e-10;

   // this solver will find the difference between the current_soln
   // and the next guess
   // store the current solution in dela_soln and add on the
   // calculated delta at the end
   for ( int q = 0; q < number_of_equations; ++q )
     {
      delta_soln[q] = solution[q];
     }
   
   int row_last_diag = 0;  int col_last_diag = 0;
   int row_top = 0;        int col_top = 0;
   int row_diag = 0;       int col_diag = 0;
   int row_left = 0;       int col_left = 0;
   int row_start_left = 0; int col_start_left = 0;
   int row_start_top = 0;  int col_start_top = 0;
   int first = 0;
   int overlap_starts = 0; int col_pt = 0;
   int row_pt1 = 0;        int row_pt2 = 0;
   double hold;             int diff = 0;
   int first_one;          int last_one;
   int first_sub;          int last_sub;
   int current_memory = matrix_size;
   int check_first;        int check_last;
   int memory_size;
   
   printf("point 1\n");
   row_diag = 0;
   for ( int row = 0; row < number_of_equations; ++row ) {
     if ( row == 0 ) continue;
     if ( diag[row] < diag[row-1] )
       row_last_diag = -1;
     else
       row_last_diag = diag[row-1];
     row_diag = diag [row];
     row_left = left [row];
     if ( (row+1) == first_one )
       row_top = (row_diag) - row_left;
     else
       row_top = (row_diag - row_last_diag) - row_left - 1;
     
     row_start_left = row + 1 - row_left;
     row_start_top = row + 1 - row_top;
     
     for ( int col = 0; col < number_of_equations; ++col ) {
       if ( col <= 1 )
	 col_last_diag = 0;
       else {
	 col_last_diag = diag [col-1];
	 col_diag = diag [col];
	 col_left = left [col];
	 col_top = 0;
	 col_start_left = 0;
	 col_start_top = 0;
	 if ( col > 0 ) {
	   col_top = (col_diag - col_last_diag) - col_left - 1;
	   col_start_left = col + 1 - col_left;
	   col_start_top = col + 1 - col_top;
	 }
	 
	 // find matrix ( row, col )
	 if ( row_start_left <= (col+1) ) {
	   overlap_starts = max ( row_start_left, col_start_top );
	   col_pt = col_diag - ( (col+1) - overlap_starts );
	   row_pt1 = row_diag - row_top - ( row - col );
	   row_pt2 = row_diag - row_top -
	     ( (row+1) - overlap_starts );
	   hold = 0.0;
	   if ( col_pt > -1 ) {
	     diff = col + 1 - overlap_starts;
	     if ( diff > 0 ) hold = dot_product
	       (&matrix[row_pt2], &matrix[col_pt], diff );
	   }
	   matrix [row_pt1] =
	     ( matrix[row_pt1] - hold ) / matrix[col_diag];
	 }
	 
	 // find matrix ( col, row )
	 if ( row_start_top <= (col+1) ) {
	   overlap_starts = max ( row_start_top, col_start_left );
	   col_pt = col_diag - col_top -
	     ( (col+1) - overlap_starts );
	   row_pt1 = row_diag - ( row - col );
	   row_pt2 = row_diag - ( (row+1) - overlap_starts );
	   hold = 0.0;
	   if ( col_pt > -1 ) {
	     diff = col + 1 - overlap_starts;
	     if ( diff > 0 ) hold = dot_product
	       ( &matrix[col_pt], &matrix[row_pt2], diff );
	     matrix [row_pt1] = matrix [row_pt1] - hold;
	   }
	 }
       }
       
       printf("point2\n");
       // find matrix ( row, row )
       overlap_starts = max ( row_start_left, row_start_top );
       row_pt1 = row_diag - row_top - ( (row+1) - overlap_starts );
       row_pt2 = row_diag - ( (row+1) - overlap_starts );
       hold = 0.0;
       diff = row + 1 - overlap_starts;
       if ( diff > 0 ) hold = dot_product
	 ( &matrix[row_pt1], &matrix[row_pt2], diff);
       matrix [row_diag] = matrix [row_diag] - hold;
       
       // check for zero pivot
       if (fabs(matrix[row_diag]) <= machine_zero) {
	 break;
       }
     }
     
     printf("point3\n");
     // reduce the right hand side
     row_pt1 = row_diag - row_top - ( (row) - row_start_left );
     hold = 0.0;
     diff = row + 1 - row_start_left;
     printf("row: %d,row_start_left: %d  diff: %d\n",row,row_start_left,diff);
     if ( diff > 0 ) hold = dot_product ( &matrix[row_pt1],
					  &solution[row_start_left-1], diff );
     printf("matrix: %f rowpt1: %d row_start_left-1: %d diff: %d\n",matrix[row_pt1],row_start_left-1,diff);
     printf("hold: %f\n",hold);
     solution [row] = rhs [row] - hold;
   }
 
   // second loop on blocks
   // back substitution to find the solution
   int row_above = number_of_equations - 1;  
   printf("point4: %d\n",row_above);
   int diag_above = diag[row_above];
   int row_pt;
   printf("point5\n");
   for ( int row = number_of_equations-1; row >= 0; --row ) {
     ++row_above;
     row_diag = diag [ row ];
     row_left = left [ row ];
     if ( row == 0 ) 
       diag_above = 0;
     else
       diag_above = diag [ row-1 ];
     printf("point6\n");
     row_top = (row_diag - diag_above) - row_left - 1;
     row_start_top = row + 1 - row_top;
     solution [row] = solution [row] / matrix [ row_diag ];
     if ( row_start_top <= row_above ) {
       row_pt = row_diag - row_top;
       for ( int place = row_start_top-1; place < row; ++place ) {   
	 solution [place] = solution [place]
	   - matrix [row_pt] * solution [row];
	 ++row_pt;
       }
     }
   }

   printf("point7: solution: \n");
   // add the delta solution found onto the current guess of the solution
   for ( int q = 0; q < number_of_equations; ++q ) {
     solution[q] = delta_soln[q] - solution[q];
     printf("delta: %f   soln: %f\n",delta_soln[q],solution[q]);
   }
}

