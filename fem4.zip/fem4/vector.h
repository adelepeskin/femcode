#ifndef VECTOR_H
#define VECTOR_H

class vector
{
  //friend class Node;
  //friend class List;
  //friend class One_d_element;
  //friend class Two_d_element;
  //friend class Particle;
  //friend class Mesh;
   public:
      vector ( myvar, myvar, myvar );
      void find_vector_length ( );
      void normalize_vector ( );
      void set_up_a_vector ( myvar, myvar, myvar );
      void make_a_normalized_vector_a_given_length ( myvar );

   protected:
      myvar length;
      myvar* direction;
};

#endif
