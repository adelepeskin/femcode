#include "refprop.h"
#include "property_model.cc"
#include <math.h>

refprop::refprop ( density_models dens_type, model_types mod_type )
   :Property_model ( dens_type, mod_type )
{
}

myvar refprop::find_density ( myvar tempval, myvar pressval )
{
   myvar density = 0.0;
   myvar b,c,d;
   myvar bv,av,fw,tr;
   myvar mol_vol;
   int itmax = 20; int ierr;
   myvar tolr = 1.0e-8;
   myvar vc, vclog, vlog;
   myvar plog, vlog0, rho, dpdlv, fvdpl;
   myvar p2, dpd, MPa_press;
   myvar Mw =
     properties->molecular_weights[properties->main_component_number];

   // use a cubic equation to get a good initial guess
   // type_of_model == RedlichKwong
   bv = 0.0778 * gas_const_r *
        (properties->tcrit/properties->pcrit);
   av = (0.45724*gas_const_r*gas_const_r);
   av *= properties->tcrit*properties->tcrit/
         properties->pcrit;
   fw = 0.37464 - 1.54226 - 0.26992;
   tr = tempval/properties->tcrit;
   fw = 1.0 - 1.43754*(1.0-sqrt(tr));
   av *= fw*fw;
   // solve for molar volume:
   // V^3 + (b-RT/P)V^2 + (-3b^2 -2RTb/P +a/P)V + (b^3+b^2RT/P-ab/P) = 0
   b = bv - (gas_const_r*tempval/pressval);
   c = -3.0*bv*bv - (2.0*bv*gas_const_r*tempval/pressval) + av/pressval;
   d = bv*bv*bv + bv*bv*(gas_const_r*tempval/pressval) - (av*bv/pressval);
   mol_vol = cubic_solver_ ( &b, &c, &d );
   density = Mw / mol_vol;

   // now use this density as a guess for the refprop6 routines
   // density in units of g/cm^3 = kg/L: refprop wants mol/L
   // multiply by (10^3 g/kg)/(Mw g/mole)

   // pressure in units of MPa
   MPa_press = 0.001 * pressval * atm_to_kPa;
   //cout << "initial guess at density at press: " << MPa_press << "  ";

   // convert density to molar units;
   rho = density * 1000.0 / Mw;

   // rhocrit in mass units: put in molar units
   // rhocrit is in kg/L: want in mol/L
   vc = Mw/(1000.0*properties->rhocrit);
   vclog = log(vc);
   vlog = log(1.0/rho);

   // vapor phase iteration
   // want pressure in MPa = .101atm
   plog = log(MPa_press);

   for ( int j = 0; j < itmax; ++j )
   {
      vlog0 = vlog;
      rho = 1.0/exp(vlog);
      p2 = newpress (tempval,rho);
      dpd = newdpdd (tempval,rho);
      if (dpd < 0.0 || p2 < 0.0)
      {
         //  unstable portion of two-phase region or p2<0, make another guess
         vlog = vlog + 0.10;
      }
      else
      {
         dpdlv = -rho * dpd;
         fvdpl = (log(p2)-plog)*p2/dpdlv;
         if (fabs(fvdpl) < (0.01*tolr))
	 {
	    //  iteration has converged
            rho =1.0/exp(vlog);
            ierr = 0;
            p2 = newpress (tempval,rho);

            // rho in mol/L : convert back to g/cm^3
            density = rho * Mw / 1000.0;
            return ( density );
	 }
         else
	 {
	    //  next guess
            vlog = vlog - fvdpl;
            if (fabs(vlog - vlog0) > 0.5)
	    {
               if ((vlog - vlog0) > 0.5) 
                  vlog = vlog0 + 0.5;
               else
                  vlog = vlog0 - 0.5;
	    }
            if (vlog < vclog && tempval < properties->tcrit)
              vlog = 0.5 * (vlog0 + vclog);
	 }
      }
   } 
   //  iteration has not converged
        
   rho = 1.0/exp(vlog);
   // convert back to g/cm^3
   density = rho * Mw / 1000.0;
   ierr = 1;
   return ( density );
}

myvar refprop::newpress ( myvar tempval, myvar rho )
{
   myvar tau = fluid_data->reducing_t/tempval;
    myvar Mw =
     properties->molecular_weights[properties->main_component_number];
    // reducing rho in kg/L: want in mol/L
    myvar redrho = (fluid_data->reducing_rho*1000.0)/Mw;
   myvar del= rho/redrho;

   // units for press: (R = MPa * cm^3/ mol K) (K) (mol/L) (0.001L/cm^3)
   myvar newpress = gas_const_J*tempval*rho*0.001*(1.0+del*phik(0,1,tau,del));
   return (newpress);
}

myvar refprop::newdpdd ( myvar tempval, myvar rho )
{
   myvar tau = fluid_data->reducing_t/tempval;
   // put reducing rho in correct units
   myvar redrho = (fluid_data->reducing_rho*1000.0)/molecular_wt;
   myvar del= rho/redrho;
   myvar phi01 = phik(0,1,tau,del);
   myvar phi02 = phik(0,2,tau,del);

   // units of dp/drho in MPa/(mol/L)
   // (R=MPa*cm^3/mole K) X (K) X (.001 L/cm^3)
   myvar newdpdd = gas_const_J*tempval*0.001*(1.0+2.0*del*phi01+del*del*phi02);
   return (newdpdd);
}

myvar refprop::phik ( int itau, int idel, myvar tau, myvar del )
{
  //  compute reduced Helmholtz energy or a derivative as functions
  //  of dimensionless temperature and density for the Helmholtz-explicit
  //  equation of state

  //  based on Tillner-Roth & Baehr (1994), JPCRD 23:657-729
  //     itau--flag specifying order of temperature derivative to calc
  //     idel--flag specifying order of density derivative to calculate
  //           when itau = 0 and idel = 0, compute A/RT
  //           when itau = 0 and idel = 1, compute 1st density derivative
  //           when itau = 1 and idel = 1, compute cross derivative
  //           etc.
  //      tau--dimensionless temperature (To/T)
  //      del--dimensionless density (D/Do)     
   myvar phik;
   int ntermf = fluid_data->number_of_terms;
   myvar* ai = fluid_data->ai; myvar* ti = fluid_data->ti; 
   myvar* di = fluid_data->di;
   int* li = fluid_data->li;

   myvar* phi01 = fluid_data->phi01;
   myvar* phi10 = fluid_data->phi10;
   myvar* phisav = fluid_data->phisav;
   myvar phisum, dell;



   if (del < 1.0e-10)   //trivial solution at zero density
   {
       phik = 0.0;      //for any and all derivatives
       return ( phik );
   }

   phisum = 0.0;
   for ( int k = 0; k < ntermf; ++k )
   { 
       if ( pow(del,di[k]) > 500.0 )
          phisav[k] = ai[k] * pow(tau,ti[k]) * 
                              pow(del,di[k]) * 
                              exp(-500.0);
       else 
          phisav[k] = ai[k] * pow(tau,ti[k]) * 
                              pow(del,di[k]) * 
                         exp(-pow(del,di[k]));
       phisum = phisum + phisav[k];
   }

   phik = phisum;

   //  check if derivatives are requested, calculations make use of fact 
   //  that terms in derivative summations are very similar to A/RT terms
   //
   if (idel == 1)
   {
      //  compute derivative w.r.t. del (dimensionless density)
      //  save individual terms for possible use in cross derivative
      phisum = 0.0;
      for ( int k = 0; k < ntermf; ++k )
      {
         phi01[k] = pow(del,di[k]);
         if (li[k] == 0)
            phi01[k] = phisav[k]*di[k]/del;
         else
	    phi01[k] = (phisav[k]/del) *
	     (di[k]-li[k]*phi01[k]);

         phisum += phi01[k];
      }
      phik = phisum;
   }

   if ( idel == 2 )
   {
      //  compute 2nd derivative w.r.t. del (dimensionless density)
      phisum = 0.0;
      for ( int k = 0; k < ntermf; ++k )
      {
         if (li[k] == 0)
            phisum = phisum + phisav[k]*di[k]*(di[k]-1.0)/(del*del);
         else
	 {
             dell = pow(del,di[k]);
             dell = li[k] * dell;
             phisum = phisum + (phisav[k]/(del*del)) *
                (di[k]*di[k] - di[k] - dell*(2.0*di[k] +li[k]-1.0-dell));
         }
      }
      phik = phisum;
   }  

   if ( itau == 1 )
   {
      //  compute derivative w.r.t. tau (dimensionless temperature)
      //  save individual terms for possible use in cross derivative
      phisum = 0.0;
      for ( int k = 0; k < ntermf; ++k )
      {
         phi10[k] = phisav[k] * ti[k]/tau;
         phisum += phi10[k];
      }
      phik = phisum;
   }
   if (itau == 2)
   {
      //  compute 2nd derivative w.r.t. tau (dimensionless temperature)
      phisum = 0.0;      for ( int k = 0; k < ntermf; ++k )
      {
         phisum = phisum + phisav[k]*ti[k]*(ti[k]-1.0)/(tau*tau);
      }
      phik = phisum;
   }

   if ( (itau == 1) && (idel == 1) )
   {
      //  compute cross derivative using terms from 1st derivatives
      phisum=0.0;
      for ( int k = 0; k < ntermf; ++k )
      {
         phisum = phisum + phi10[k] * phi01[k]/phisav[k];
      }
      phik = phisum;
   }
   return ( phik );
}

myvar refprop::find_dp_dt ( myvar tempval, myvar pressval )
{
   return ( pressval/tempval );
}

myvar refprop::find_enthalpy ( myvar tempval, myvar, myvar rho )
{
   // this is refprof routine ENTHAL in prop_sub.for
   myvar enthalpy = 0.0;
   // rho is needed in mol/L : convert from g/cm^3 = kg/L
   myvar refrho = rho * 1000.0 / molecular_wt;

   // pure fluid
   myvar tau = fluid_data->reducing_t/tempval;

   // reducing rho in kg/L: want in mol/L
   myvar redrho = (fluid_data->reducing_rho*1000.0)/molecular_wt;
   myvar del = refrho / redrho;

   // myvar phi00 = phik (0,0,tau,del);
   myvar phi01 = phik (0,1,tau,del);
   myvar phi10 = phik (1,0,tau,del);
   // cout << "del: " << del << "  tau: " << tau << "  01:" << phi01 << "  10:" << phi10 << endl;

   myvar phig10 = phi0 (1,tempval,refrho);
   enthalpy = gas_const_J * tempval * (phig10 + tau*phi10 + 1.0 + del*phi01);

      // enthalpy returned in units of (J/(mol-K)): change to J/g
   enthalpy /= molecular_wt;

   return ( enthalpy );
}

myvar refprop::phi0 ( int itau, myvar tempval, myvar rho )
{
   //  compute the ideal gas part of the reduced Helmholtz energy or a 
   //  derivative as functions of temperature and pressure for a mixture;
   //  for use with the Helmholtz-explicit models (e.g. FEQ and HMX)

   //  inputs:
   //     itau--flag specifying order of temperature derivative to calc
   //     idel--flag specifying order of density derivative to calculate
   //            = 0 here
   //           (the density derivatives are not used in the calculation
   //           of any property, and are not implemented)
   //           when itau = 0 and idel = 0, compute A0/RT
   //           when itau = 1 and idel = 0, 1st temperature derivative
   //           when itau = 2 and idel = 0, 2nd temperature derivative
   //       t--temperature [K]
   //      rho--density [mol/L]
   //  output (as function value):
   //     PHI0--ideal-gas part of the reduced Helmholtz energy (A/RT);
   //           derivatives (as specified by itau and idel) are multiplied
   //           by the corresponding power of tau; when itau = 1, the 
   //           quantity returned is tau*d(PHI0)/d(tau) and when itau = 2,
   //           the quantity returned is tau*tau*d2(PHI0)/d(tau)**2,
   //           where the tau's are the Tc/T evaluated for each component 
   //  N.B.  While the real-gas part of the Helmholtz energy is calculated
   //        in terms of dimensionless temperature and density, the ideal-
   //        gas part is calculated in terms of absolute temperature and
   //        density.  (This distinction is necessary for mixtures.) 
   //        The Helmholtz energy consists of ideal-gas and residual 
   //        (real-gas) terms; this routine calculates only the ideal part
   //  written by M. McLinden, NIST Thermophysics Division

   myvar phi0 = 0.0;
   // calls PH0CPP from core_cpp.for

   if ( itau == 0 )
   {
      phi0 = (cpIcpp(tempval)/(gas_const_J*tempval)) -
             (cpTcpp(tempval)/gas_const_J) +
             log(tempval*rho/(tref*rhoref)) - 1.0;
   }
   if ( itau == 1 )
     phi0 = (cpIcpp(tempval)/(gas_const_J*tempval)) - 1.0;

   return ( phi0 );
}
