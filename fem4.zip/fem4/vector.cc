vector::vector ( myvar x_new, myvar y_new, myvar z_new )
{
   direction = new myvar[3];
   direction[0] = x_new;
   direction[1] = y_new;
   direction[2] = z_new;
}

void vector::find_vector_length ( )
{
   length = sqrt ( direction[0]*direction[0]  +  direction[1]*direction[1]  +  
                   direction[2]*direction[2] );
}

void vector::normalize_vector ( )
{
   find_vector_length ( );
   if ( length < small ) return;
   // divide each component by the vector length
   direction[0] /= length;
   direction[1] /= length;
   direction[2] /= length;    
}

void vector::make_a_normalized_vector_a_given_length 
   ( myvar given_length )
{
   find_vector_length ( );
   if ( length < small ) return;
   // divide each component by the vector length
   direction[0] *= given_length;
   direction[1] *= given_length;
   direction[2] *= given_length;
}

void vector::set_up_a_vector ( myvar length, myvar x_dist, myvar y_dist )
{
   // set up a vector of a given length, in the direction: (x_dist,y_dist)
   direction[0] = x_dist;
   direction[1] = y_dist;
   direction[2] = 0.0;
   normalize_vector ( );
   direction[0] *= length;
   direction[1] *= length;
}
