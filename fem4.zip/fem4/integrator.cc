#include "integrator.h"

// initialize private static member constants
const int Time_integrator::max_tries = 2;
const int Time_integrator::max_time_steps = 250000;

Time_integrator::Time_integrator( Solver_structure* solv )
{
   solver = solv;
   solver->mytime = this;
   mymesh = solv->mymesh;
   time_scheme = euler;
   current_step = 0;
   int_flags = solver->int_flags;
   stepsize_error = 0.01;
   first_moving_eqn = solver->number_of_field_equations -
		      solver->number_of_moving_equations;
   first_non_particle_eqn = mymesh->particle_degrees_of_freedom *
	                    mymesh->number_of_particles;
   number_of_lines = mymesh->number_of_lines;
   number_of_particles = mymesh->number_of_particles;
   move_flag = no_movement;
   if ( solver->number_of_moving_equations > 0 ) move_flag = boundary_moves;
   if ( mymesh->number_of_particles > 0 )
      move_flag = mymesh->are_the_particles_moving ( );
   soln_vec_c = 0;
   soln_vec_v = 0;
   if ( int_flags->vel_flag == velocity_combined )
   {
      soln_vec_c = new solution_vectors;
      soln_vec_c->current_soln = solver->soln_vec->current_soln;
      soln_vec_c->old_soln = new myvar [ solver->number_of_field_equations ];
      soln_vec_c->very_old_soln = new myvar [ solver->number_of_field_equations ];
      soln_vec_c->current_deriv = new myvar [ solver->number_of_field_equations ];
      soln_vec_c->old_deriv = new myvar [ solver->number_of_field_equations ];
      soln_vec_c->very_old_deriv = new myvar [ solver->number_of_field_equations ];
      soln_vec_c->current_guess = new myvar [ solver->number_of_field_equations ];
      soln_vec_c->current_time = 0.0;
   }
   if ( int_flags->vel_flag == velocity_alone )
   {
      soln_vec_v = new solution_vectors;
      soln_vec_v->current_soln = solver->soln_vec->current_soln;
      soln_vec_v->old_soln = new myvar [ solver->number_of_velocity_equations ];
      soln_vec_v->very_old_soln = new myvar [ solver->number_of_velocity_equations ];
      soln_vec_v->current_deriv = new myvar [ solver->number_of_velocity_equations ];
      soln_vec_v->old_deriv = new myvar [ solver->number_of_velocity_equations ];
      soln_vec_v->very_old_deriv = new myvar [ solver->number_of_velocity_equations ];
      soln_vec_v->current_guess = new myvar [ solver->number_of_velocity_equations ];
      soln_vec_v->current_time = 0.0;
   }
   make_soln_accessible ( soln_vec_c->current_soln, soln_vec_v->current_soln );
   int largest_eqns = max ( solver->number_of_field_equations,
			    solver->number_of_velocity_equations );
   residual = new myvar [ largest_eqns ];
   int last_fixed_eqn = solver->number_of_field_equations -
			solver->number_of_moving_equations;
   for ( int eqn=0; eqn < solver->number_of_field_equations; ++eqn )
   {
      soln_vec_c->current_soln [eqn] = 0.5;
      soln_vec_c->old_soln [eqn] = 0.0;
      soln_vec_c->very_old_soln [eqn] = 0.0;
      soln_vec_c->current_deriv [eqn] = 0.0;
      soln_vec_c->old_deriv [eqn] = 0.0;
      soln_vec_c->very_old_deriv [eqn] = 0.0;
      soln_vec_c->current_guess [eqn] = 0.5;
      if ( eqn > last_fixed_eqn ) soln_vec_c->current_guess [eqn] = 1.0;
   }
   for ( int eqn=0; eqn < solver->number_of_velocity_equations; ++eqn )
   {
      soln_vec_v->current_soln [eqn] = 0.5;
      soln_vec_v->old_soln [eqn] = 0.0;
      soln_vec_v->very_old_soln [eqn] = 0.0;
      soln_vec_v->current_deriv [eqn] = 0.0;
      soln_vec_v->old_deriv [eqn] = 0.0;
      soln_vec_v->very_old_deriv [eqn] = 0.0;
      soln_vec_v->current_guess [eqn] = 0.5;
   }
   for ( int eqn=0; eqn < largest_eqns; ++eqn )
   {
      residual [eqn] = 0.0;
   }
   error_check_total = 0.0;
   current_error_check_sum = 0.0;
   times_too_big = 0;
   times_too_small = 0;
   initial_delta_time = 0.0;
   int_flags->time_since_last_print = 0.0;
}

void Time_integrator::make_soln_accessible ( myvar* soln_c, myvar* soln_v )
{
   mymesh->make_soln_accessible ( soln_c, soln_v );
}

void Time_integrator::integrate_in_time ( )
{
   if ( int_flags->vel_flag == velocity_combined )
	soln_vec_c->step_size = int_flags->step_c;
   if ( int_flags->vel_flag == velocity_alone )
	soln_vec_v->step_size = int_flags->step_v;
   time_scheme = int_flags->time_scheme;
   stepsize_error = int_flags->stepsize_error;
   int_flags->which_field = concentration;
   if ( int_flags->use_data_flag == 0 ) return;
   if ( int_flags->time_integ_flag == steady_state )
   {
      steady_solve ( );
      return;
   }

   // transient solution needed
   transient_solve ( );
}

void Time_integrator::steady_solve ( )
{
   int_flags->mass_term_flag = no_mass_term;
   initial_derivatives ( );
}

void Time_integrator::transient_solve ( )
{
   error_test test = repeat_step;
   int tries = 0;
   int_flags->current_time = 0.0;

   // first see if there is a restart file to use instead of the
   // normal startup steps:

   if ( int_flags->startup_flag == continue_from_file )
      read_a_restart_file ( );
   else
   {
      while ( test == repeat_step && tries < max_tries )
      {
         // solve for initial derivatives         
         int_flags->time_since_last_print = 0.0;
         int_flags->mass_term_flag = no_mass_term;
         initial_derivatives ( );
         // for debugging - go to initial_solution for any case of endup_flag
         if ( int_flags->endup_flag == get_residual ||
              int_flags->endup_flag == get_first_derivative ) return;

         // solve for first initial field and movement
         current_step = 1;
         int_flags->initial_flag = not_solving_for_initial;

         int_flags->mass_term_flag = include_mass_term;
         initial_solution ( );
         int_flags->current_time = soln_vec_c->step_size;

         if ( int_flags->endup_flag == get_first_solution ) return; 

         // solve for the second field and movement
         current_step = 2;
         int_flags->mass_term_flag = include_mass_term;
         test = second_solution ( );

         if ( int_flags->endup_flag == get_second_solution ) return;

         if ( test == repeat_step )
         {
	    put_back_original_coordinates ( );
            int_flags->initial_flag = solving_for_initial;
            if ( int_flags->number_of_surf_equations > 0 )
            {
               int_flags->resize_global_flag = resize; 
               solver->size_the_global_matrix ( ); 
            }
         }
         ++tries;
      }
      current_step = 2;
      soln_vec_c->current_time = 2.0 * soln_vec_c->step_size;
      int_flags->current_time = 2.0 * soln_vec_c->step_size;
      int_flags->time_since_last_print += soln_vec_c->step_size;
   }

   while ( soln_vec_c->current_time < int_flags->end_of_run_time &&
	   current_step < max_time_steps )
   {
      test = repeat_step; int count = 0;
      while ( test == repeat_step && count < max_tries )
      {
	 test = take_a_step ( );
	 ++count;
      }
      if ( test == step_okay ) ++current_step;
      if ( test == repeat_step )
      {
         // make the program stop
         current_step = max_time_steps;
      }
   }
   print_a_restart_file ( );
}

void Time_integrator::initial_derivatives ( )
{
   int_flags->which_time_step = initial_deriv;
   // get initial field and set old_soln to initial field
   iterating_flag iter_flag = iterate_without_moving;
   mymesh->store_current_eqn_numbers ( );
 
   if ( int_flags->vel_flag == velocity_alone )
   {
      int_flags->which_field = velocity;
      int_flags->step_size = soln_vec_v->step_size;
      initial_delta_time = soln_vec_v->step_size;
      // put initial nodal values into current_guess and current_soln vectors
      get_initial_field ( );

      save_old_solution ( );
      if ( int_flags->time_scheme == trapezoid )
      {
         solver->mymesh->Loop_to_integrate ( solver->matrix_group );
         update_matrices ( );
      }

      // if the initial field is known, continue; if not solve for it here:
      if ( int_flags->startup_flag == start_over )
         newton_raphson ( iter_flag );
      for ( int j = 0; j < solver->number_of_velocity_equations; ++j )
      {
	 if ( int_flags->field_flag == full )
	    soln_vec_v->current_deriv[j] =
	       soln_vec_v->current_soln[j] / soln_vec_v->step_size;
         else
	    soln_vec_v->current_deriv[j] = 0.0;
      }
   }
   else
   {
      int_flags->which_field = concentration;
      int_flags->step_size = soln_vec_c->step_size;
      initial_delta_time = soln_vec_c->step_size;
      // put initial nodal values into current_guess  and current_soln vectors
      get_initial_field ( );
      save_old_solution ( );

      if ( int_flags->time_scheme == trapezoid )
      {
         solver->mymesh->Loop_to_integrate ( solver->matrix_group );
         update_matrices ( );
      }

      // solve for the initial field and derivatives if necessary
      if ( int_flags->startup_flag == start_over )
         newton_raphson ( iter_flag );
      if ( int_flags->time_since_last_print > int_flags->print_step_size )
         print_post_processor ( soln_vec_c->current_soln );
      for ( int j = 0; j < solver->number_of_field_equations; ++j )
      {
	 if ( j >= first_moving_eqn || j < first_non_particle_eqn ||
              int_flags->field_flag == full )
	    soln_vec_c->current_deriv[j] =
	       soln_vec_c->current_soln[j] / soln_vec_c->step_size;
         else
	    soln_vec_c->current_deriv[j] = 0.0;
      }
   }
}

void Time_integrator::get_initial_field ( )
{
   int numeqns = solver->number_of_field_equations;
   if ( int_flags->which_field == velocity )
      numeqns = solver->number_of_velocity_equations;

   // gather initial data from each node
   mymesh->node_list->get_initial_field ( int_flags, solver->matrix_group, soln_vec_c );
   mymesh->store_current_eqn_numbers ( );

   // gather initial data from each element
   if ( int_flags->press_eqns == solve_press )
      mymesh->element_list->get_initial_element_field ( soln_vec_c );

   for ( int num = 0; num < numeqns; ++num )
   {
      if ( int_flags->which_field == concentration )
	 soln_vec_c->current_soln[num] = soln_vec_c->current_guess[num];
      if ( int_flags->which_field == velocity )
	 soln_vec_v->current_soln[num] = soln_vec_v->current_guess[num];
   }
}

void Time_integrator::initial_solution ( )
{
   int_flags->which_time_step = initial_soln;
   iterating_flag iter_flag = iterate_without_moving;
   mymesh->store_current_eqn_numbers ( );
   if ( int_flags->field_flag == full ) iter_flag = iterate_while_moving;
   if ( int_flags->number_of_particles > 0 ) iter_flag = iterate_without_moving;
   if ( int_flags->piston_motion != no_piston ) iter_flag = iterate_without_moving;
   if ( int_flags->vel_flag == velocity_alone )
   {
      int_flags->which_field = velocity;
      int_flags->step_size = soln_vec_v->step_size;
      form_first_predictors ( );
      newton_raphson ( iter_flag );
      soln_vec_v->current_time += soln_vec_v->step_size;
      int_flags->time_since_last_print += soln_vec_v->step_size;
      if ( int_flags->time_since_last_print > int_flags->print_step_size )
         print_post_processor ( soln_vec_v->current_soln );
   }

   else
   {
      int_flags->which_field = concentration;
      int_flags->step_size = soln_vec_c->step_size;
      form_first_predictors ( );
      if ( int_flags->number_of_particles > 0 )
      {
         get_initial_field ( );
         for ( int p = 0; p <  solver->number_of_field_equations; ++p )
         {
            soln_vec_c->current_soln[p] = soln_vec_c->current_guess[p];
         }
      }
      newton_raphson ( iter_flag );
      soln_vec_c->current_time += soln_vec_c->step_size;
      int_flags->time_since_last_print += soln_vec_c->step_size;
      if ( int_flags->time_since_last_print > int_flags->print_step_size )
         print_post_processor ( soln_vec_c->current_soln );
   }

   // if there are particles: move them according to the new solution
   if ( int_flags->number_of_particles > 0 && 
        move_flag == boundary_moves ) move_the_mesh_forward ( );
}

error_test Time_integrator::second_solution ( )
{
   int_flags->which_time_step = second_soln;
   error_test test = step_okay;
   iterating_flag iter_flag = iterate_without_moving;
   mymesh->store_current_eqn_numbers ( );
   if ( int_flags->field_flag == full ) iter_flag = iterate_while_moving;
   if ( int_flags->number_of_particles > 0 ) iter_flag = iterate_without_moving;
   if ( int_flags->piston_motion != no_piston ) iter_flag = iterate_without_moving;

   int_flags->which_field = which_field_next ( );
   if ( int_flags->which_field == velocity )
      int_flags->step_size = soln_vec_v->step_size;
   else
      int_flags->step_size = soln_vec_c->step_size;
   form_first_derivatives ( );
   form_new_predictors ( );
   if ( int_flags->number_of_particles > 0 )
   {
      get_initial_field ( );
      for ( int p = 0; p <  solver->number_of_field_equations; ++p )
      {
         soln_vec_c->current_soln[p] = soln_vec_c->current_guess[p];
         // soln_vec_c->old_soln[p] = soln_vec_c->current_guess[p];
      }
   }

   // reset startup flag
   int_flags->start_up_flag = not_start_up;
   if ( int_flags->start_again_flag == start_again_renumbered )
      int_flags->start_up_flag = not_start_up;
   newton_raphson ( iter_flag );

   test = check_error ( );
   // step size change was calculated in check_error,
   // but no size change takes place unless step was too large

   if ( test == step_okay )
   {
      if ( int_flags->which_field == velocity )
      {
	 soln_vec_v->current_time += soln_vec_v->step_size;
         int_flags->time_since_last_print += soln_vec_v->step_size;
         if ( int_flags->time_since_last_print > int_flags->print_step_size )
            print_post_processor ( soln_vec_v->current_soln );
      }
      else
      {
	 soln_vec_c->current_time += soln_vec_c->step_size;
         int_flags->time_since_last_print += soln_vec_c->step_size;
         if ( int_flags->time_since_last_print > int_flags->print_step_size )
            print_post_processor ( soln_vec_c->current_soln );
      }

      // if there are particles: move them according to the new solution
      if ( int_flags->number_of_particles > 0 && 
           move_flag == boundary_moves ) move_the_mesh_forward ( );
   }
   else
   {
      if ( int_flags->which_field == velocity )
	 soln_vec_v->current_time = 0.0;
      else
	 soln_vec_c->current_time = 0.0;
   }
   return test;
}

type_of_field Time_integrator::which_field_next ( )
{
   type_of_field which_field = concentration;
   if ( int_flags->vel_eqns == dont_solve_vel ||
	int_flags->vel_flag == velocity_combined )
      return which_field;
   which_field = velocity;
   if ( int_flags->vel_flag == velocity_alone )
      return which_field;

   // add on the current time step and see whose ahead
   myvar new_c = soln_vec_c->current_time + soln_vec_c->step_size;
   myvar new_v = soln_vec_v->current_time + soln_vec_v->step_size;

   // if they're at the same time: run a velocity time step
   if ( fabs ( new_c - new_v ) < small ) which_field = velocity;

   // if the velocity field is ahead: run a concentration time step
   else
      if ( new_v > new_c ) which_field = concentration;

   // if the concentration field is ahead: run a velocity time step
   else
      which_field = velocity;

   return which_field;
}

error_test Time_integrator::take_a_step ( )
{
   int_flags->which_time_step = more_solns;
   error_test test;
   int_flags->which_field = which_field_next ( );
   mymesh->store_current_eqn_numbers ( );
   if ( int_flags->which_field == velocity )
      int_flags->step_size = soln_vec_v->step_size;
   else
      int_flags->step_size = soln_vec_c->step_size;
   form_new_derivatives ( );
   form_new_predictors ( );

   if ( int_flags->number_of_particles > 0 )
   {
      get_initial_field ( );
      for ( int p = 0; p <  solver->number_of_field_equations; ++p )
      {
         soln_vec_c->current_soln[p] = soln_vec_c->current_guess[p];
         // soln_vec_c->old_soln[p] = soln_vec_c->current_guess[p];
      }
   }
   
   iterating_flag iter_flag = iterate_without_moving;
   if ( int_flags->field_flag == full ) iter_flag = iterate_while_moving;
   if ( int_flags->number_of_particles > 0 ) iter_flag = iterate_without_moving;
   if ( int_flags->piston_motion != no_piston ) iter_flag = iterate_without_moving;
   newton_raphson ( iter_flag );
   test = check_error ( );

   if ( test == step_okay )
   {
      // update the time before the step size is changed for the
      // next step
      if ( int_flags->which_field == velocity )
      {
	 soln_vec_v->current_time += soln_vec_v->step_size;
         int_flags->current_time += soln_vec_v->step_size;
         int_flags->time_since_last_print += soln_vec_c->step_size;
         if ( int_flags->time_since_last_print > int_flags->print_step_size )
            print_post_processor ( soln_vec_v->current_soln );
      }
      else
      {
	 soln_vec_c->current_time += soln_vec_c->step_size;
         int_flags->current_time += soln_vec_c->step_size;
         int_flags->time_since_last_print += soln_vec_c->step_size;
         if ( int_flags->time_since_last_print > int_flags->print_step_size )
            print_post_processor ( soln_vec_c->current_soln );

      }
      // if there are particles: move them according to the new solution
      if ( int_flags->number_of_particles > 0 && 
           move_flag == boundary_moves ) move_the_mesh_forward ( );
   }
   else
   {
      if ( int_flags->moving_flag == boundary_moves && 
           move_flag == boundary_moves )
	move_the_mesh_back ( );
   } 

   return test;
}

myvar Time_integrator::find_residual ( solution_vectors* soln_vec )
{
   int numeqns = solver->number_of_field_equations;
   if ( int_flags->which_field == velocity )
      numeqns = solver->number_of_velocity_equations;
   myvar final_residual = 0.0;
   mymesh->element_list->element_resid ( numeqns, residual, soln_vec, solver->matrix_group );

   final_residual =
      dot_product ( residual, residual, numeqns );
   final_residual = sqrt ( final_residual );

   return final_residual;
}

void Time_integrator::compare_to_initial ( solution_vectors* soln_vec )
{
   int numeqns = solver->number_of_field_equations;
   if ( int_flags->which_field == velocity )
      numeqns = solver->number_of_velocity_equations;
   myvar final_residual = 0.0; myvar diff;
   return;
}

void Time_integrator::form_first_predictors ( )
{
   int numeqns = solver->number_of_field_equations;
   save_old_solution ( );
   if ( int_flags->time_scheme == trapezoid ) update_matrices ( );
   if ( int_flags->which_field == velocity )
   {
      numeqns = solver->number_of_velocity_equations;
      for ( int num = 0; num < numeqns; ++num )
      {
	 soln_vec_v->current_guess[num] = soln_vec_v->current_soln[num];
      }
   }
   else
   {
      for ( int num=0; num < numeqns; ++num )
      {
	 soln_vec_c->current_guess[num] = soln_vec_c->current_soln[num];
	 if ( num >= first_moving_eqn || num < first_non_particle_eqn ||
              int_flags->field_flag == full )
	 {
	    soln_vec_c->current_guess[num] =
	       soln_vec_c->step_size * soln_vec_c->current_deriv[num];
	    soln_vec_c->current_soln[num] = soln_vec_c->current_guess[num];
	 }
      }
   }
}

void Time_integrator::form_new_predictors ( )
{
   int numeqns = solver->number_of_field_equations;
   save_old_solution ( );
   if ( int_flags->time_scheme == trapezoid ) update_matrices ( );
   if ( int_flags->which_field == velocity )
   {
      numeqns = solver->number_of_velocity_equations;
      for ( int num=0; num < numeqns; ++num )
      {
	 if ( int_flags->field_flag == full )
	    soln_vec_v->current_guess[num] =
	       soln_vec_v->step_size * soln_vec_v->current_deriv[num];
	 else
	    soln_vec_v->current_guess[num] = soln_vec_v->current_soln[num];
	 soln_vec_v->current_soln[num] = soln_vec_v->current_guess[num];
      }
   }
   else
   {
      for ( int num=0; num < numeqns; ++num )
      {
	 soln_vec_c->current_guess[num] = soln_vec_c->current_soln[num];
	 if ( num >= first_moving_eqn || num < first_non_particle_eqn ||
              int_flags->field_flag == full )
	    soln_vec_c->current_guess[num] =
	       soln_vec_c->step_size * soln_vec_c->current_deriv[num];
	 soln_vec_c->current_soln[num] = soln_vec_c->current_guess[num];
      }
   }
}

void Time_integrator::form_first_derivatives ( )
{
   int numeqns = solver->number_of_field_equations;
   if ( int_flags->which_field == velocity )
      numeqns = solver->number_of_velocity_equations;

   for ( int num=0; num < numeqns; ++num )
   {
      if ( int_flags->which_field == velocity )
      {
	 soln_vec_v->old_deriv[num] = soln_vec_v->current_deriv[num];
	 if ( int_flags->field_flag == full )
	    soln_vec_v->current_deriv [num] =
	       ( 2.0/soln_vec_v->step_size) * soln_vec_v->current_soln[num]
		   - soln_vec_v->current_deriv [num];
      }
      else
      {
	 soln_vec_c->old_deriv[num] = soln_vec_c->current_deriv[num];
	 if ( num >= first_moving_eqn || num < first_non_particle_eqn ||
              int_flags->field_flag == full )
	    soln_vec_c->current_deriv [num] =
	       ( 2.0/soln_vec_c->step_size) * soln_vec_c->current_soln[num]
		   - soln_vec_c->current_deriv [num];
      }
   }
}

void Time_integrator::form_new_derivatives ( )
{
   if ( int_flags->which_field == velocity )
   {
      int numeqns = solver->number_of_velocity_equations;
      for ( int num=0; num < numeqns; ++num )
      {
	 soln_vec_v->very_old_deriv[num] = soln_vec_v->old_deriv[num];
         soln_vec_v->old_deriv[num] = soln_vec_v->current_deriv[num];
	 if ( int_flags->field_flag == full )
	    soln_vec_v->current_deriv [num] =
	       (2.0/soln_vec_v->step_size) * soln_vec_v->current_soln[num]
		-  soln_vec_v->old_deriv[num];
      }
   }
   else
   {
      int numeqns = solver->number_of_field_equations;
      for ( int num=0; num < numeqns; ++num )
      {
	 soln_vec_c->very_old_deriv[num] = soln_vec_c->old_deriv[num];
         soln_vec_c->old_deriv[num] = soln_vec_c->current_deriv[num];
	 if ( num >= first_moving_eqn || num < first_non_particle_eqn ||
              int_flags->field_flag == full )
	    soln_vec_c->current_deriv [num] =
	       (2.0/soln_vec_c->step_size) * soln_vec_c->current_soln[num]
		-  soln_vec_c->old_deriv[num];
      }
   }
}

void Time_integrator::save_old_solution ( )
{
   int numeqns = solver->number_of_field_equations;
   if ( int_flags->which_field == velocity )
      numeqns = solver->number_of_velocity_equations;
   for ( int num = 0; num < numeqns; ++num )
   {
      if ( int_flags->which_field == velocity )
      {
         soln_vec_v->very_old_soln [num] = soln_vec_v->old_soln [num];
	 soln_vec_v->old_soln [num] = soln_vec_v->current_soln [num];
      }
      else
      {
         soln_vec_c->very_old_soln [num] = soln_vec_c->old_soln [num];
	 soln_vec_c->old_soln [num] = soln_vec_c->current_soln [num];
      }
   }
}

void Time_integrator::update_matrices ( )
{
   mymesh->update_matrices ( );
}

void Time_integrator::reset_after_step_size_change ( )
{
   // step size was too big
   // update timestep-based derivatives after cut in time step size

   int numeqns = solver->number_of_field_equations;
   if ( int_flags->which_field == velocity )
      numeqns = solver->number_of_velocity_equations;
   for ( int num = 0; num < numeqns; ++num )
   {
      if ( int_flags->which_field == velocity )
      {
	 soln_vec_v->current_soln [num] = soln_vec_v->old_soln [num];
         soln_vec_v->old_soln [num] = soln_vec_v->very_old_soln [num];
         soln_vec_v->current_deriv [num] =
            soln_vec_v->old_deriv [num] / change_stepsize_factor;
         soln_vec_v->old_deriv [num] =
            soln_vec_v->very_old_deriv [num] / change_stepsize_factor;
      }
      else
      {
	 soln_vec_c->current_soln [num] = soln_vec_c->old_soln [num];
         soln_vec_c->old_soln [num] = soln_vec_c->very_old_soln [num];
         soln_vec_c->current_deriv [num] =
            soln_vec_c->old_deriv [num] / change_stepsize_factor;
         soln_vec_c->old_deriv [num] =
            soln_vec_c->very_old_deriv [num] / change_stepsize_factor;
      }
   }
}

void Time_integrator::reset_derivatives ( )
{
   // time step was too big: update derivatives based on a smaller 
   // time step size

   int numeqns = solver->number_of_field_equations;
   if ( int_flags->which_field == velocity )
      numeqns = solver->number_of_velocity_equations;
   for ( int num = 0; num < numeqns; ++num )
   {
      if ( int_flags->which_field == velocity )
      {
         soln_vec_v->current_deriv [num] =
            soln_vec_v->old_deriv [num] / change_stepsize_factor;
         soln_vec_v->old_deriv [num] =
            soln_vec_v->very_old_deriv [num] / change_stepsize_factor;
      }
      else
      {
         soln_vec_c->current_deriv [num] =
            soln_vec_c->old_deriv [num] / change_stepsize_factor;
         soln_vec_c->old_deriv [num] =
            soln_vec_c->very_old_deriv [num] / change_stepsize_factor;
      }
   }
}
      
void Time_integrator::update_r_values ( which_way direction )
{
   mymesh->update_r_values ( direction, soln_vec_c->current_soln );
}

error_test Time_integrator::check_error ( )
{
   int numeqns = solver->number_of_field_equations;
   if ( int_flags->which_field == velocity )
      numeqns = solver->number_of_velocity_equations;
   error_test test = step_okay;
   current_error_check_sum = 0.0;
   if ( int_flags->con_logs == take_logs && 
        int_flags->which_field != velocity )
      current_error_check_sum = mymesh->find_sum_for_con_logs ( soln_vec_c->current_soln,
                                              soln_vec_c->current_guess );
   else
   {
      for ( int num = 0; num < numeqns; ++num )
      {
         if ( int_flags->which_field == velocity )
	    current_error_check_sum += pow ( (soln_vec_v->current_soln[num]-
		          soln_vec_v->current_guess[num]), 2.0 );
         else
   	    current_error_check_sum += pow ( (soln_vec_c->current_soln[num]-
		          soln_vec_c->current_guess[num]), 2.0 );
      }
   }
   
   error_check_total = numeqns * pow ( (0.5*int_flags->stepsize_error), 2.0 );

   // calculate what the change in step size would be if one were made here
   change_stepsize_factor = 1.0;

   // see if a change is needed here
   if ( change_stepsize_factor > 2.0 )
   {
      ++times_too_big;
      if ( times_too_big < 3 ) 
         change_stepsize_factor = 1.0;
      else
      {
         times_too_big = 0;
         update_step_size ( );
      }
   }
   if ( change_stepsize_factor < 0.5 )
   {
      ++times_too_small;
      if ( times_too_small < 3 ) 
         change_stepsize_factor = 1.0;
      else
      {
         times_too_small = 0;
         update_step_size ( );
      }
   }

   // if ( current_error_check_sum > error_check_total ) test = repeat_step;
   return test;
}

void Time_integrator::update_step_size ( )
{      
   if ( change_stepsize_factor > 2.0 ) change_stepsize_factor = 2.0;

   myvar stepsize = soln_vec_c->step_size;
   if ( int_flags->which_field == velocity ) 
      stepsize = soln_vec_v->step_size; 
   myvar newstepsize = stepsize * change_stepsize_factor;
   if ( newstepsize < initial_delta_time * 1.0e-5 )
      newstepsize = initial_delta_time * 1.0e-5;
   if ( newstepsize > small )
   {
      if ( int_flags->which_field == velocity )
         soln_vec_v->step_size = newstepsize;
      else
         soln_vec_c->step_size = newstepsize;
   }
   reset_derivatives ( );
   // reset_after_step_size_change ( );
}

void Time_integrator::print_a_restart_file ( )
{
}

void Time_integrator::print_xy_for_restart ( )
{
   mymesh->print_xy_for_restart ( );
}

void Time_integrator::read_a_restart_file ( )
{
}

void Time_integrator::read_xy_from_restart ( )
{
   mymesh->read_xy_from_restart ( );
}

void Time_integrator::newton_raphson ( iterating_flag iter_flag )
{
   int numeqns = solver->number_of_field_equations;
   int_flags->finding_solution_flag = still_iterating;

   if ( int_flags->which_field == velocity )
      numeqns = solver->number_of_velocity_equations;
   myvar iter_error = int_flags->iteration_error * numeqns;
   // find initial residual from first guess
   if ( (int_flags->moving_flag == boundary_moves && 
         move_flag == boundary_moves &&
         int_flags->mass_term_flag == include_mass_term &&
         iter_flag == iterate_while_moving) ||
        (int_flags->piston_motion != no_piston &&
         int_flags->which_time_step != initial_deriv))
   {
      save_old_coordinates ( );
      move_the_mesh_forward ( );
   }

   solver->mymesh->Loop_to_integrate ( solver->matrix_group );
   myvar current_error;
   if ( int_flags->which_field == velocity )
      current_error = find_residual ( soln_vec_v );
   else
      current_error = find_residual ( soln_vec_c );

   if ( int_flags->endup_flag == get_residual ) return;

   if ( iter_flag == iterate_while_moving &&
        int_flags->moving_flag == boundary_moves && 
        move_flag == boundary_moves )
	move_the_mesh_back ( );

   // Loop until error is sufficiently small
   int loop_count = 0;
   myvar new_delta = current_error;
   while ( (new_delta > iter_error &&
	    current_error > iter_error ) &&
	    loop_count < int_flags->max_iteration_loop )
   {
      // solve: jacobian*x = residual to find next guess
      solver->fill_global_matrix ( );
      if ( int_flags->which_field == velocity )
      {
	 solver->solve_the_matrix ( residual );
         solver->mymesh->Loop_to_integrate ( solver->matrix_group );
	 current_error = find_residual ( soln_vec_v );
      }
      else
      {
	 solver->solve_the_matrix ( residual );
         if ( iter_flag == iterate_while_moving &&
	      int_flags->moving_flag == boundary_moves && 
              move_flag == boundary_moves &&
              iter_flag == iterate_while_moving )
	      move_the_mesh_forward ( );
         solver->mymesh->Loop_to_integrate ( solver->matrix_group );
         current_error = find_residual ( soln_vec_c );
         if ( iter_flag == iterate_while_moving &&
	      int_flags->moving_flag == boundary_moves && 
              move_flag == boundary_moves )
              move_the_mesh_back ( );
      }
      ++loop_count;
   }
   int_flags->finding_solution_flag = solution_found;
   if ( iter_flag == iterate_while_moving && 
        move_flag == boundary_moves &&
	int_flags->moving_flag == boundary_moves )
      move_the_mesh_forward ( );
}

void Time_integrator::machine_error_in_residuals ( )
{
   int numeqns = solver->number_of_field_equations;
   if ( int_flags->which_field == velocity )
      numeqns = solver->number_of_velocity_equations;
   for ( int eqn = 0; eqn < numeqns; ++eqn )
   {
      if ( fabs ( residual[eqn] ) < 0.1e-10 ) residual[eqn] = 0.0;
   }
}

void Time_integrator::move_the_mesh_forward ( )
{
   if ( number_of_lines > 0 )
      update_r_values ( plus );
   mymesh->move_the_mesh_forward 
      ( soln_vec_c->current_soln );
   if ( number_of_lines > 0 )
      update_r_values ( minus );
}

void Time_integrator::move_the_mesh_back ( )
{
   mymesh->move_the_mesh_back ( );
}

void Time_integrator::put_back_original_coordinates ( )
{
   mymesh->put_back_original_coordinates ( );
}

void Time_integrator::save_old_coordinates ( )
{
   mymesh->save_old_coordinates ( );
}

void Time_integrator::print_post_processor ( myvar* current_soln )
{
   mymesh->print_post_processor ( );
}
