#ifndef MATRIX_DRIVER_H
#define MATRIX_DRIVER_H
#include "solver.cc"

class matrix_driver
{
   public:
      matrix_driver ( Mesh* );
      void set_up_the_solvers ( );
      //void steady_solve ( );
      //void initial_derivatives ( );
      void get_initial_field ( );
      void run_a_step ( );
      //void initial_solution ( );
      void form_first_predictors ( );
      //void form_new_predictors ( );
      //void form_first_derivatives ( );
      //void form_new_derivatives ( );
      //void set_current_from_guess ( );
      void update_derivatives ( );

   protected:
      Mesh* mymesh;
      myvar* residual;
      int number_of_equations;
};

#endif
