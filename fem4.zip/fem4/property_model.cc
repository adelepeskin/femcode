#include "property_model.h"

// initialize private static member constants
// ex.: int Moving_boundary_entity::elements_per_particle = 0;

Property_model::Property_model
   ( density_models dens, model_types mod_type )
{
   properties = 0;
   density_type = dens;
   type_of_model = mod_type;
   
   // create fluid data struct
   fluid_data = new refprop_data;
}

myvar Property_model::find_density ( myvar, myvar )
{
   myvar density = 0.0;
   return ( density );
}

myvar Property_model::find_dp_dt ( myvar, myvar )
{
   myvar dp_dt = 0.0;
   return ( dp_dt );
}

myvar Property_model::find_enthalpy ( myvar, myvar, myvar )
{
   myvar enthalpy = 0.0;
   return ( enthalpy );
}

myvar Property_model::cp0cpp ( myvar tempval )
{
   // this function finds the ideal gas part of the heat capacity, c_p
   // from Refprop CP0CPP
   //  uses polynomial correlation of Cp0:
   //     Cp0/Cred = SUM [cpc(i,k)*(T/Tred(i))**xk(i,k)]
   //              + SUM [cpc(i,k)*u(i,k)**2*exp{u(i,k)}/(1-exp{u(i,k)})**2]
   //  output (as function value):
   //   CP0CPP--Cp0 (J/(mol-K))

   myvar cp0cpp = 0.0;
   for ( int j = 0; j < fluid_data->number_cp_terms; ++j )
   {  
      cp0cpp += fluid_data->cpc[j] * pow(tempval,fluid_data->xk[j]);
   }

   return ( cp0cpp );
}

myvar Property_model::cpIcpp ( myvar tempval )
{
   // This routine find the integral of CP0 from Tref to T
   // from Refprop CPICPP
   // based on derivations in Younglove & McLinden (1994), JPCRD 23:731-779
   //  equation C11
   //   CPICPP--int (Cp0 dT)|T-Tref (J/mol)
   myvar cpIcpp = 0.0;
   myvar jexp;

   for ( int j = 0; j < fluid_data->number_cp_terms; ++j )
   {  
      jexp = fluid_data->xk[j] + 1.0;
      cpIcpp += fluid_data->cpc[j] * 
         (pow(tempval,jexp) - pow(tref,jexp))/ jexp;
   }

   return ( cpIcpp );
}

myvar Property_model::cpTcpp ( myvar tempval )
{
   // This routine find the integral of CP0/T from Tref to T
   // from Refprop CPTCPP

   //  compute integral of Cp0/T over limits of Tref to T
   //  for use in entropy calculation

   //  uses polynomial correlation of Cp0:
   //     Cp0/Cred = SUM [cpc(i,k)*(T/Tred(i))**xk(i,k)]
   //              + SUM [cpc(i,k)*u(i,k)**2*exp{u(i,k)}/(1-exp{u(i,k)})**2]

   //  output (as function value):
   //   CPTCPP--int (Cp0/T dT)|T-Tref (J/(mol-K))

   myvar cpTcpp = 0.0;
   for ( int j = 0; j < fluid_data->number_cp_terms; ++j )
   {  
      // first deal with the log term:
      if ( fluid_data->xk[j] < 1.0e-6 )
         cpTcpp += fluid_data->cpc[j] * log(tempval/tref);

      else
         cpTcpp += fluid_data->cpc[j] *
            (pow(tempval,fluid_data->xk[j]) - pow(tref,fluid_data->xk[j]))/
            fluid_data->xk[j];
   }

   return ( cpTcpp );
}

