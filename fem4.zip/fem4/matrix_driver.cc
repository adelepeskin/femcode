#include "matrix_driver.h"

matrix_driver::matrix_driver( Mesh* mesh_ptr )
{
   mymesh = mesh_ptr;
   number_of_equations = mymesh->number_of_equations;
   printf("number of eqns in matrix driver: %d\n",number_of_equations);
}

void matrix_driver::set_up_the_solvers ( )
{
   // create the global matrices one by one
   Solver_skyline* solv_sky;
   solv_sky = new Solver_skyline ( mymesh, number_of_equations);
}

void matrix_driver::steady_solve ( )
{
  //initial_derivatives ( );
}

/*void matrix_driver::initial_derivatives ( )
{
   cout << "start of initial derivatives: " << endl;
   int_flags->which_time_step = initial_deriv;
   // get initial field and set old_soln to initial field
   iterating_flag iter_flag = iterate_without_moving;
   mymesh->store_current_eqn_numbers ( );
 
   cout << "in integrator: " << int_flags->step_size << endl;
   initial_delta_time = int_flags->step_size;
   // put initial nodal values into current_guess  and current_soln vectors
   get_initial_field ( );
   set_current_from_guess ( );
   save_old_solution ( );

   if ( int_flags->time_scheme == trapezoid )
   {
      mymesh->Loop_to_integrate ( list_of_solve[0]->matrix_group );
      update_matrices ( );
   }
   run_a_step ( );

   // update current derivatives
   update_derivatives ( );
}*/

void matrix_driver::get_initial_field ( )
{
  //mymesh->get_initial_field ( );
}

void matrix_driver::run_a_step( )
{

}

void matrix_driver::initial_solution ( )
{
   form_first_predictors ( );

   run_a_step ( );
}
    
void matrix_driver::update_matrices ( )
{
  //mymesh->update_matrices ( );
}

void matrix_driver::form_first_predictors ( )
{
}

void matrix_driver::form_new_predictors ( )
{
   for ( int k = 0; k < number_of_matrices; ++k )
   {
      list_of_solve[k]->form_new_predictors ( );
   }
}


void matrix_driver::update_derivatives ( )
{
}
