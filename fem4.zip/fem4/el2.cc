#include "el.h"
#include "el-1d.h"
#include "el-2d.h"
#include "el-no-d.h"
#include "chem.h"
#include "io.h"
#include "lists.h"
#include "mesh-fem.h"
#include "node.h"
#include "mover.h"
#include "mover-lines.h"
#include "particles.h"
#include "vector.h"
#include "solver.h"
#include <math.h>
#include <fstream.h>

// initialize private static member constants

void Element::renumber_equations_separately ( equation_groups* matrix_group )
{
   // matrix group holds values: all_equations,all_except_velocity,velocity_only ) 

   // the current equation number for each group is stored 
   // in int_flags->numbers_of_equations
 
   if ( dimension == zero_dimensional ) return;
   if ( is_it_a_special_particle_element == special_particle_element ||
        is_it_empty == empty ) return;
   if ( connect_ptrs[0] == 0 ) return;

   // keep separate counters for temperature equations and velocity equations
   int vel_matrix = 0;
   if ( matrix_group[1] == velocity_only ) vel_matrix = 1;
   int press_matrix = 0;
   if ( matrix_group[2] == pressure_only ) press_matrix = 2;

   // solve moving boundary stuff with temperature equations
   for ( int nod = 0; nod < total_nodes; ++nod )
   {
      if ( connect_ptrs[nod] == 0 ) continue;
      if ( dimension == one_dimensional )
      {
         if ( moving_type == line )
         {
            // moving line equations are always in matrix 1:
            if ( connect_ptrs[nod]->line_ptr->line_equation_number > 0 )
	    {
               if ( connect_ptrs[nod]->line_ptr->renumber == 
                    line_is_not_renumbered )
               {
                  int_flags->numbers_of_equations[0] += 1;
                  connect_ptrs[nod]->line_ptr->renumber_line ( int_flags->numbers_of_equations[0] );
	          connect_ptrs[nod]->line_ptr->renumber =  line_is_renumbered;
                  el_equation_numbers[nod] = int_flags->numbers_of_equations[0];
               }
               else
                  el_equation_numbers[nod] = 
                     connect_ptrs[nod]->line_ptr->line_equation_number;
	    }
         }
 
         if ( elem_bc->free_surf_bc[0] == free_surface )
         {
            // free surface equations are always in matrix 1:
            for ( int j = 0; j < free_surf_degrees_of_freedom; ++j )
            {
               if ( connect_ptrs[nod]->renumber_1d == node_is_not_renumbered )
               {
                  int_flags->numbers_of_equations[0] += 1;
                  free_surf_equation_numbers[surf_degrees_of_freedom*nod+j] = 
                     int_flags->numbers_of_equations[0];
                  if ( j == 0 ) connect_ptrs[nod]->first_free_surf_eqn = 
                     int_flags->numbers_of_equations[0];
	       }
               else
                  free_surf_equation_numbers[surf_degrees_of_freedom*nod+j] = 
                     connect_ptrs[nod]->first_free_surf_eqn;
            }
	 }
         if ( int_flags->temp_eqns == solve_temp )
         {
            temp_equation_numbers [nod] = connect_ptrs[nod]->first_temp_eqn; 
	 }
         if ( int_flags->vel_eqns == solve_vel )
         {
            // see if velocity equation are in matrix 1 or 2
            if ( connect_ptrs[nod]->is_node_in_particle == 
                          node_on_particle_surface )
            {
               vel_equation_numbers[vel_degrees_of_freedom*nod] = 
                  p_ptr->part_equation_numbers[0];
               vel_equation_numbers[vel_degrees_of_freedom*nod+1] = 
                  p_ptr->part_equation_numbers[1];
               connect_ptrs[nod]->first_vel_eqn = p_ptr->part_equation_numbers[0];
	    }
            else
            {
               if ( connect_ptrs[nod]->first_vel_eqn > 0 )
               {
                  for ( int j = 0; j < vel_degrees_of_freedom; ++j )
                  {
                     if ( connect_ptrs[nod]->renumber == node_is_not_renumbered )
                     {
                        int_flags->numbers_of_equations[vel_matrix] += 1;
                        vel_equation_numbers[vel_degrees_of_freedom*nod+j] = 
                           int_flags->numbers_of_equations[vel_matrix];
                        if ( j == 0 ) connect_ptrs[nod]->first_vel_eqn = 
                           int_flags->numbers_of_equations[vel_matrix];
		     }
                     else
                        vel_equation_numbers[vel_degrees_of_freedom*nod+j] = 
                           connect_ptrs[nod]->first_vel_eqn + j;
                  }
	       }
	    }
	 }
         connect_ptrs[nod]->renumber_1d = node_is_renumbered;
      }
      if ( dimension == two_dimensional )
      {
         if ( int_flags->mass_eqns == solve_mass )
         {
            // first_mass_eqn  el_equation_numbers
            if ( connect_ptrs[nod]->first_mass_eqn > 0 )
            {
               for ( int j = 0; j < mass_degrees_of_freedom; ++j )
               {
                  if ( connect_ptrs[nod]->renumber == node_is_not_renumbered )
                  {
                     int_flags->numbers_of_equations[0] += 1;
                     el_equation_numbers[mass_degrees_of_freedom*nod+j] = 
                        int_flags->numbers_of_equations[0];
                     if ( j == 0 ) connect_ptrs[nod]->first_mass_eqn = 
                        int_flags->numbers_of_equations[0];
	          }
                  else
                    el_equation_numbers[mass_degrees_of_freedom*nod+j] = 
                       connect_ptrs[nod]->first_mass_eqn + j; 
	       }
	    }
         }
         if ( int_flags->vel_eqns == solve_vel )
         {
            // first_vel_eqn  vel_equation_numbers
            // number a node if on the particle surface - no eqns if inside
            if ( connect_ptrs[nod]->is_node_in_particle ==
                    node_on_particle_surface || 
                 connect_ptrs[nod]->is_node_in_particle == node_in_particle_box )
            {
               if ( connect_ptrs[nod]->is_node_in_particle ==
                    node_on_particle_surface || 
                    connect_ptrs[nod]->is_node_in_particle ==
                    node_in_particle_box )
	       {
                  vel_equation_numbers[vel_degrees_of_freedom*nod] = 
		     p_ptr->part_equation_numbers[0];
                  vel_equation_numbers[vel_degrees_of_freedom*nod+1] = 
		     p_ptr->part_equation_numbers[1];
                  connect_ptrs[nod]->first_vel_eqn = 
	             p_ptr->part_equation_numbers[0];
                  connect_ptrs[nod]->print_flag = do_print;
	       }
               else
	       {
                  vel_equation_numbers[vel_degrees_of_freedom*nod] = 0;
                  vel_equation_numbers[vel_degrees_of_freedom*nod+1] = 0;
                  connect_ptrs[nod]->first_vel_eqn = 0;
                  connect_ptrs[nod]->print_flag = do_not_print;
               }
	    }
            else
            {
               connect_ptrs[nod]->print_flag = do_print;
               if ( connect_ptrs[nod]->first_vel_eqn > 0 )
               {
                  // check for the center of a cylinder
                  if ( connect_ptrs[nod]->center_mark == at_the_center )
                  {
                     for ( int j = 1; j < vel_degrees_of_freedom; ++j )
                     {
                        if ( connect_ptrs[nod]->renumber == node_is_not_renumbered )
                        {
                           int_flags->numbers_of_equations[vel_matrix] += 1;
                           if ( j == 1 ) connect_ptrs[nod]->first_vel_eqn = 
                              int_flags->numbers_of_equations[vel_matrix];
                           vel_equation_numbers[vel_degrees_of_freedom*nod+j] = 
                              int_flags->numbers_of_equations[vel_matrix];
		        }
                        else
                           vel_equation_numbers[vel_degrees_of_freedom*nod+j] = 
                             connect_ptrs[nod]->first_vel_eqn + j - 1;
		     }
                  }
                  else
                  {
                     for ( int j = 0; j < vel_degrees_of_freedom; ++j )
                     {
                        if ( connect_ptrs[nod]->renumber == node_is_not_renumbered )
                        {
                           int_flags->numbers_of_equations[vel_matrix] += 1;
                           vel_equation_numbers[vel_degrees_of_freedom*nod+j] = 
                              int_flags->numbers_of_equations[vel_matrix];
                           if ( j == 0 ) connect_ptrs[nod]->first_vel_eqn = 
                              int_flags->numbers_of_equations[vel_matrix];
		        }
                        else
                           vel_equation_numbers[vel_degrees_of_freedom*nod+j] = 
                             connect_ptrs[nod]->first_vel_eqn + j;
                     }
		  }
	       }
               else
	       {
		  // constrained node: 
                  for ( int j = 0; j < vel_degrees_of_freedom; ++j )
                  {
                     vel_equation_numbers[vel_degrees_of_freedom*nod+j] = connect_ptrs[nod]->first_vel_eqn - j;
		  } 
	       }
            }
            if ( int_flags->turb_eqns == solve_turb )
	    {
               // first_turb_eqn  turb_equation_numbers
               if ( connect_ptrs[nod]->first_turbk_eqn > 0 )
               {
                  if ( connect_ptrs[nod]->renumber == node_is_not_renumbered )
                  {
                     int_flags->numbers_of_equations[vel_matrix] += 1;
                     turbk_equation_numbers[nod] =
                              int_flags->numbers_of_equations[vel_matrix];
                     connect_ptrs[nod]->first_turbk_eqn = 
                        turbk_equation_numbers[nod];
                     int_flags->numbers_of_equations[vel_matrix] += 1;
                     turbe_equation_numbers[nod] =
                              int_flags->numbers_of_equations[vel_matrix];
                     connect_ptrs[nod]->first_turbe_eqn = 
                        turbe_equation_numbers[nod];
	          }
                  else
		  {
                     turbk_equation_numbers[nod] = 
                       connect_ptrs[nod]->first_turbk_eqn;
                     turbe_equation_numbers[nod] = 
                       connect_ptrs[nod]->first_turbe_eqn;
		  }
	       } 
	    }
	 }
         if ( int_flags->temp_eqns == solve_temp )
         {
            // first_temp_eqn  temp_equation_numbers
            if ( connect_ptrs[nod]->first_temp_eqn > 0 )
            {
               if ( connect_ptrs[nod]->renumber == node_is_not_renumbered )
               {
                  int_flags->numbers_of_equations[0] += 1;
                  temp_equation_numbers[nod] = 
                     int_flags->numbers_of_equations[0];
                  connect_ptrs[nod]->first_temp_eqn = 
                     int_flags->numbers_of_equations[0];
	       }
               else
                  temp_equation_numbers[nod] = 
                       connect_ptrs[nod]->first_temp_eqn;
            }
         }
         if ( int_flags->pot_eqns == solve_pot )
         {
            // first_pot_eqn   pot_equation_numbers;
            if ( connect_ptrs[nod]->first_pot_eqn > 0 )
            {
               for ( int j = 0; j < mass_degrees_of_freedom; ++j )
               {
                  if ( connect_ptrs[nod]->renumber == node_is_not_renumbered )
                  {
                     int_flags->numbers_of_equations[0] += 1;
                     pot_equation_numbers[nod] = 
                        int_flags->numbers_of_equations[0];
                     if ( j == 0 ) connect_ptrs[nod]->first_pot_eqn = 
                        int_flags->numbers_of_equations[0];
		  }
                  else
                     pot_equation_numbers[nod] = 
                       connect_ptrs[nod]->first_pot_eqn;
	       }
            }
         }

         // r_equation_numbers: see if moving line has been updated
         if ( connect_ptrs[nod]->first_moving_eqn > 0 )
         {
            // see if the line has been updated
            if ( connect_ptrs[nod]->line_ptr->renumber == 
                 line_is_not_renumbered )
            {
               int_flags->numbers_of_equations[0] += 1;
               connect_ptrs[nod]->line_ptr->renumber_line 
                  ( int_flags->numbers_of_equations[0] );
	       connect_ptrs[nod]->line_ptr->renumber =  line_is_renumbered;
               r_equation_numbers[nod] = int_flags->numbers_of_equations[0];
            }
            else
               r_equation_numbers[nod] = 
                  connect_ptrs[nod]->line_ptr->line_equation_number;
	 }
         connect_ptrs[nod]->renumber = node_is_renumbered;
      }
   }

if ( element_number == 1 )
{
   cout << "element 1 nodes: ";
   for ( int j = 0; j < 4; ++j )
   {
     cout << "node: " << j+1 << "  first vel: " << connect_ptrs[j]->first_vel_eqn << "  " << "first turb: " << connect_ptrs[j]->first_turbk_eqn << "  " << connect_ptrs[j]->first_turbe_eqn << endl;
   }
     cout << "element 1 vel equation: " << endl;
   for ( j = 0; j < 8; ++j )
   {
     cout << vel_equation_numbers[j] << "  ";
   }
   cout << endl;
}

   if ( int_flags->press_eqns == solve_press && 
           is_it_a_special_particle_element != special_particle_element &&
           is_it_empty == not_empty )
   {
      if ( first_press_eqn > 0 )
      {
         // if element is totally inside the particle, it does not need
	 // a pressure equation
         if ( element_particle_type == element_contains_particle &&
            (total_nodes == number_of_nodes || 
             particle_edge == edge_element || 
             does_particle_fill_element == element_filled_with_particle ) )
         { 
            first_press_eqn = -33333;
            for ( int pbase = 0; 
                  pbase < number_of_pressure_basis_fcns; ++pbase )
            {
               press_equation_numbers[pbase] = -33333;
	    }
	 }
         else
         {
            first_press_eqn = int_flags->numbers_of_equations[press_matrix]+1;
            for ( int pbase = 0; pbase < number_of_pressure_basis_fcns; ++pbase )
            {
               int_flags->numbers_of_equations[press_matrix] += 1;
               ++int_flags->press_cnt;
               press_equation_numbers[pbase] = 
                  int_flags->numbers_of_equations[press_matrix];
	    }
         }
      }
   }
}

void Element::fill_equation_number_arrays ( )
{
   int first_vel_eqn, place;
   int first_surf_eqn, first_free_surf_eqn, first_mass_eqn;
   int first_temp_eqn, first_pot_eqn, first_turbk_eqn, first_turbe_eqn;
   int first_moving_eqn;
   int vels = vel_degrees_of_freedom;
   if ( dimension == one_dimensional )
   {
      if ( moving_type != stationary )
      {
         for ( int nod = 0; nod < number_of_nodes; ++nod)
         {
            first_moving_eqn = 
                connect_ptrs[nod]->first_moving_eqn;
	    el_equation_numbers [nod] = first_moving_eqn;
         }
      }

      if ( elem_bc->piston_bc[0] != none )
      {
         for ( int nod = 0; nod < number_of_nodes; ++nod)
         {
            first_vel_eqn = connect_ptrs[nod]->first_vel_eqn;
            vel_equation_numbers[vel_degrees_of_freedom*nod] = 0;
            vel_equation_numbers[vel_degrees_of_freedom*nod+1] = -1;
            if ( vel_degrees_of_freedom > 2 ) 
               vel_equation_numbers[vel_degrees_of_freedom*nod+2] = -1;
	 }
      }

      if ( elem_bc->surf_bc[0] != none )
      {
         place = 0;
         for ( int nod = 0; nod < number_of_nodes; ++nod)
         {
            first_surf_eqn = connect_ptrs[nod]->first_surf_eqn;
            for ( int nxt = 0; nxt < surf_degrees_of_freedom; ++nxt )
	    {
               if ( first_surf_eqn > 0 )
	          surf_equation_numbers [place] = first_surf_eqn + nxt;
               else
                  surf_equation_numbers [place] = first_surf_eqn - nxt;
	       ++place;
	    }
	 }
      }
      if ( elem_bc->free_surf_bc[0] == free_surface )
      {
         place = 0;
         for ( int nod = 0; nod < number_of_nodes; ++nod )
         {
            first_free_surf_eqn = connect_ptrs[nod]->first_free_surf_eqn;
            for ( int nxt = 0; nxt < free_surf_degrees_of_freedom; ++nxt )
	    {
               if ( first_free_surf_eqn > 0 )
	          free_surf_equation_numbers [place] = first_free_surf_eqn + nxt;
               else
                  free_surf_equation_numbers [place] = first_free_surf_eqn - nxt;
	       ++place;
	    }
	 }
      }
      if ( int_flags->temp_eqns == solve_temp )
      {
         for ( int nod = 0; nod < number_of_nodes; ++nod )
         {
            temp_equation_numbers [nod] = connect_ptrs[nod]->first_temp_eqn;
	 }
      } 
   }
   if ( dimension == two_dimensional )
   {
      place = 0;
      for ( int nod = 0; nod < number_of_nodes; ++nod)
      {
	 first_mass_eqn = connect_ptrs[nod]->first_mass_eqn;
	 first_temp_eqn = connect_ptrs[nod]->first_temp_eqn;
	 first_vel_eqn = connect_ptrs[nod]->first_vel_eqn;
         first_pot_eqn = connect_ptrs[nod]->first_pot_eqn;
	 first_moving_eqn = connect_ptrs[nod]->first_moving_eqn;
	 first_turbk_eqn = connect_ptrs[nod]->first_turbk_eqn;
	 first_turbe_eqn = connect_ptrs[nod]->first_turbe_eqn;
	 if ( int_flags->mass_eqns == solve_mass )
	 {
            for ( int nxt = 0; nxt < mass_degrees_of_freedom; ++nxt )
	    {
               if ( first_mass_eqn > 0 )
	          el_equation_numbers [place] = first_mass_eqn + nxt;
               else
                  el_equation_numbers [place] = first_mass_eqn - nxt;
	       ++place;
	    }
	 }
	 if ( int_flags->temp_eqns == solve_temp )
	    temp_equation_numbers [nod] = first_temp_eqn;

	 if ( int_flags->vel_eqns == solve_vel )
	 {
            // check for the center of a cylinder
            if ( connect_ptrs[nod]->center_mark == at_the_center &&
                 first_vel_eqn > 0 )
	    {
               vel_equation_numbers[vels*nod] =
                  connect_ptrs[nod]->center_eqn;
               for ( int j = 1; j < vel_degrees_of_freedom; ++j )
               {
                  vel_equation_numbers[vels*nod+j] = first_vel_eqn + j - 1;
	       }       
	    }
            else
	    {
	       vel_equation_numbers[vels*nod] = first_vel_eqn;
	       if (first_vel_eqn > 0)
	       {
	          vel_equation_numbers[vels*nod+1] = first_vel_eqn + 1;
                  if ( vels > 2 )
                     vel_equation_numbers[vels*nod+2] = first_vel_eqn + 2; 
	       }
	       else
	       {
	          vel_equation_numbers[vels*nod+1] = first_vel_eqn - 1;
                  if ( vels > 2 )
	             vel_equation_numbers[vels*nod+2] = first_vel_eqn - 2;
	       }
	    }

            // check for the center of a cylinder
            if ( connect_ptrs[nod]->center_mark == at_the_center &&
                 first_vel_eqn > 0 )
               vel_equation_numbers[vels*nod] =
                  connect_ptrs[nod]->center_eqn;
	 }
         if ( int_flags->pot_eqns == solve_pot )
	 {
	    pot_equation_numbers [nod] = first_pot_eqn;
	 }
	 if ( int_flags->moving_flag == boundary_moves )
	 {
	    r_equation_numbers [nod] = first_moving_eqn;
	 }
	 if ( int_flags->turb_eqns == solve_turb )
	 {
	    turbk_equation_numbers [nod] = first_turbk_eqn;
	    turbe_equation_numbers [nod] = first_turbe_eqn;
	 }
      }
   }
}
