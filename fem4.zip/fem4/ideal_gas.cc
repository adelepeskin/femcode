#include "ideal_gas.h"
#include "property_model.h"
#include "el.h"
#include <math.h>
#include <fstream.h>

ideal_gas::ideal_gas ( density_models dens_type, model_types mod_type )
   :Property_model ( dens_type, mod_type )
{
}

myvar ideal_gas::find_density ( myvar tempval, myvar pressval )
{
   myvar density = 0.0;
   // ideal gas law: rho = (Mw * p) / (R * T)

   if ( density_type == f_of_temp )
   {
      density = 
      (properties->molecular_weights[properties->main_component_number] *
       properties->gas_vapor_pressure) / 
      (gas_const_r * tempval);
      // cout << "density: " << density << "  R:" << gas_const_r << "  Mw: " << properties->molecular_weights[properties->main_component_number] << " press: " << properties->gas_vapor_pressure << "  tempval: " << tempval << endl;
   }
   if ( density_type == f_of_temp_and_press )
   {
      density = 
      (properties->molecular_weights[properties->main_component_number] *
       pressval) / 
      (gas_const_r * tempval);
   }
   cout << "final ideal density: " << density << " at press: " << pressval << endl;
   return ( density );
}

myvar ideal_gas::find_dp_dt ( myvar tempval, myvar pressval )
{
   myvar dp_dt = 0.0;
   // ideal gas law: P = rho R T / Mw
   // dp_dt = rho R / Mw = P / T

   if ( density_type == f_of_temp )
   {
      dp_dt = 0.0;
   }
   if ( density_type == f_of_temp_and_press )
   {
      dp_dt = pressval / tempval;
   }

   return ( dp_dt );
}

myvar ideal_gas::find_enthalpy ( myvar tempval, myvar, myvar )
{
   // call routine to find ideal gas integral ( cp0 ) from Tref to T
   myvar enthalpy = cpIcpp(tempval);

   // this is a test-------------------------------------------------
   // use a constant cp0 value: integral = cp0*(T2 - T1);
   // enthalpy = 83.14 * (tempval - tref);
   // end of test--------------------------------------------------
   // cout << "found enthalpy for temp: " << tempval << " to be: " << enthalpy << endl;
   
   // enthalpy returned in units of (J/(mol-K)): change to J/g
   enthalpy /= molecular_wt;
   return ( enthalpy );
}
