#ifndef EL2D_H
#define EL2D_H

class Two_d_element : public Element
{
   public:
      Two_d_element ( int, myvar* );
      ~Two_d_element ( );
      void fill_el_matrix ( );
      void find_values_at_this_gauss_point ( );
      void find_mass_values_at_this_gauss_point ( );
      void find_moving_integral_terms ( );
      void find_vel_integral_terms ( );
      void find_temp_integral_terms ( );
      void find_mass_integral_terms ( );
      void find_pot_integral_terms ( );
      void e_matrix_into_skyline 
         ( int*, int*, int, int, myvar*, myvar*);
      void elem_residual_calc ( myvar*, myvar*);
      void form_conval ( );
      int find_number_of_pressures ( );
      myvar find_area_ratio_of_particle ( );
      bool is_node_on_element_side ( Node*, int );
      void assign_shape_fcns ( );
      void set_pqmn_values ( );
      myvar compute_work_term ( );
      int increase_global_eqn_number ( );
      static const int maximum_particle_nodes_per_element;
      int vel_degrees_of_freedom;

   protected:

};

class nine_node_element : public Two_d_element
{
   public:
      nine_node_element ( int, myvar* );
      void find_derivatives ( );
      void form_kp_matrix ( );

   protected:
};

#endif
