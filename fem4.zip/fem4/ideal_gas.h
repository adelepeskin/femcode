#ifndef IDEAL_GAS_H
#define IDEAL_GAS_H

#include "property_model.h"
#include "mytypes.h"

//class Property_model;

class ideal_gas: public Property_model
{
   friend class Element;
   public:
      ideal_gas ( density_models, model_types );
      myvar find_density ( myvar, myvar );
      myvar find_dp_dt ( myvar, myvar );
      myvar find_enthalpy ( myvar, myvar, myvar );

   protected:
};

#endif
