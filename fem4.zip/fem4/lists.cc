#include "lists.h"

// initialize private static member constants
const myvar List::set_free_value = 999999999.999;
const int List::max_number_of_blocks = 6;

List::List ( )
{
   top_element = 0;
   bottom_element = 0;
   top_node = 0;
   bottom_node = 0;
   old_top_node = 0;
   top_moving = 0;
   bottom_moving = 0; 
}

Item_Element::Item_Element ( Element* newelem )
{
   value = newelem;
   next = 0;
}

Item_Node::Item_Node ( Node* newnode )
{
   value = newnode;
   next = 0;
}

Item_Line::Item_Line ( Line* newline )
{
   value = newline;
   next = 0;
}

Item_Particle::Item_Particle ( Particle* newparticle )
{
   value = newparticle;
   next = 0;
}

Item_Moving::Item_Moving ( Moving_boundary_entity* newmoving )
{
   value = newmoving;
   next = 0;
}

Boolean List::is_empty ()
{
   if (top_element == 0  &&  top_node == 0  &&  
       top_moving == 0 )
       return true;
   else
      return false;
}

void List::append ( Element* newelem )
{
   Item_Element* ptr = new Item_Element ( newelem );
   if (top_element == 0)
      // empty list: this is the first entry
      top_element = ptr;
   else
      // full list; stick this on the end
      bottom_element->next = ptr;

   ptr->next = 0;
   bottom_element = ptr;
}

void List::append ( Node* newnode )
{
   Item_Node *ptr = new Item_Node ( newnode );
   if (top_node == 0)
      // empty list: this is the first entry
      top_node = ptr;
   else
      // full list; stick this on the end
      bottom_node->next = ptr;
   ptr->next = 0;
   bottom_node = ptr;
}

void List::append ( Moving_boundary_entity* newmoving )
{
   Item_Moving *ptr = new Item_Moving ( newmoving );
   if (top_moving == 0)
      // empty list: this is the first entry
      top_moving = ptr;
   else
      // full list; stick this on the end
      bottom_moving->next = ptr;
   ptr->next = 0;
   bottom_moving = ptr;
}

void List::save_top_node_value ( )
{
   old_top_node = top_node;
}

void List::replace_top_node_value ( )
{
   top_node = old_top_node;
}

void List::element_off_list ( int elem_number )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   Item_Element* previous = e_item;
   Element* prev; Element* next_el;
   cout << "start of element off list: " << elem_number << endl;
   // check for top element
   if ( e_ptr->element_number == elem_number )
   {
      // delete and reassign the top element
      top_element =  e_item->next;
      next_el = top_element->value;
      e_ptr->~Element ( );
      return;
   }


   // find the element pointer to delete
   while ( e_ptr->element_number != elem_number && 
           e_item != 0 )
   {
      previous = e_item;
      e_item = e_item->next;
      e_ptr = e_item->value;
      if ( e_item == 0 ) 
      {
	 cout << "element: " << elem_number 
              << "  cannot be found on the element list. " << endl;
      }
   }

   if ( e_ptr->element_number == elem_number )
   {
       // take the element out of the linked list
       prev = previous->value;

       // if this is the bottom, make previous the bottom
       if ( bottom_element->value == e_ptr )
          bottom_element = previous;
       else
       {
          next_el = e_item->next->value;
          previous->next = e_item->next;
       }

       // delete the element
       e_ptr->~Element ( );
   }
   else
     cout << "did not delete" << e_ptr->element_number << endl;
}

void List::delete_the_top ( )
{
   Item_Element* e_item = top_element;
   Element* e_ptr = top_element->value;
   e_item = e_item->next;
   Element* e_ptr2 = e_item->value;
   int e_number = e_ptr->element_number;
   cout << "inside delete_the_top " << e_ptr->element_number << "  next: " << e_ptr2->element_number << endl;
   element_off_list ( e_number );
}


void List::node_off_list ( Node* off_node )
{
   Item_Node* n_item = top_node;
   Node* n_ptr = top_node->value;
   Item_Node* previous = n_item;
   Node* prev; Node* next_node;

   cout << "start of node off list: " << off_node->node_number << endl;
   // check for top node
   if ( off_node == n_ptr )
   {
      // delete and reassign the top node
      top_node = n_item->next;
      next_node = top_node->value;
      delete [] n_ptr;
      return;
   }

   // find the node pointer if not at the top
   while ( n_ptr != off_node && n_item != 0 )
   {
      previous = n_item;
      n_item = n_item->next;
      n_ptr = n_item->value;
      if ( n_item == 0 ) 
      {
	 cout << "node: " << off_node->node_number 
              << "  cannot be found on the node list. " << endl;
      }
   }

   if ( n_ptr == off_node )
   {
       // take the node out of the linked list
       prev = previous->value;
       next_node = n_item->next->value;
       previous->next = n_item->next;

       // delete the node
       cout << "calling delete for: " << n_ptr->node_number << endl;
       delete [] n_ptr;
   }
   else
     cout << "did not delete" << off_node->node_number << endl; 

}
