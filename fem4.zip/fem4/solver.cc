#include "solver.h"

Solver_structure::Solver_structure 
   ( Mesh* newmesh, int numeqn )
{
   mymesh = newmesh;
   number_of_equations = numeqn;
   sky_sizes = new skyline_sizes;
   sky_sizes->diag = new int[numeqn];
   sky_sizes->left = new int[numeqn];
   residual = new myvar[numeqn];
   solution = new myvar[numeqn];
   delta_soln = new myvar[numeqn];
   rhs = new myvar[numeqn];
}

void Solver_structure::set_up_the_solver ( ) {
  mymesh->assign_skyline ( sky_sizes );
  matrix_size = sky_sizes->matrix_size;
  matrix = new myvar[matrix_size];
}

void Solver_structure::solve_the_matrix ( )
{
  // put in an initial solution
  //printf("initial soln: ");
  for (int q = 0; q < number_of_equations; ++q) {
    solution[q] = mymesh->initial_soln[q];
    //printf(" %f ",solution[q]);
  }
  //printf("\n");
  mymesh->update_nodes( solution );

  // fill the element matrices
  mymesh->fill_el_matrix();
  myvar ress = find_residual();
  printf("called find the residual: %f\n",ress);

  // fill the global matrix from the element matrices
  fill_global_matrix ( );

  for ( int q = 0; q < number_of_equations; ++q ) {
    rhs[q] = residual[q];
    delta_soln[q] = solution[q];
    solution[q] = rhs[q];
  }

  // now solve: matrix*delta = residual
  solve_it();
  mymesh->update_nodes( solution );
  
  // find a new residual
  mymesh->fill_el_matrix();
  ress = find_residual();
  printf("called find the residual: %f\n",ress);

  // fill the global matrix from the element matrices
  fill_global_matrix ( );

  int tries = 5;
  while (ress > 0.01 && tries < 4) {
    // copy the residual into the rhs vector
    for (int j = 0; j < number_of_equations; ++j) {
      rhs[j] = residual[j];
    }

    // save last solution in delta_soln
    for ( int q = 0; q < number_of_equations; ++q ) {
      delta_soln[q] = solution[q];
      solution[q] = rhs[q];
    }

    // now solve: matrix*delta = residual
    printf("calling solvit: %f\n",solution[0]);
    solve_it();
    mymesh->update_nodes( solution );

    // compute a new residual
    mymesh->fill_el_matrix();
    ress = find_residual();
    printf("the residual after %d tries: %f\n",tries,ress);

    // fill the global matrix from the element matrices
    fill_global_matrix ( );
    ++tries;
  }
  mymesh->printSolution();
}

void Solver_structure::fill_global_matrix ( )
{
  mymesh->fill_global_matrix ( matrix, sky_sizes->left, sky_sizes->diag );
}

myvar Solver_structure::find_residual ( ) 
{
  resid = 0.0;

  // residual vector will get zeroed in the List routine
  
  for ( int j = 0; j < number_of_equations; ++j )
    {
      residual[j] = 0.0;
    }

  //printf("calling mymesh resid\n");
  mymesh->element_resid ( residual, solution );
  
  
  resid = dot_product ( residual, residual, number_of_equations );
  resid = sqrt ( resid );
  printf("final resid: %f\n",resid);

  return resid;
}

void Solver_structure::form_first_predictors ( )
{
   for ( int num = 0; num < number_of_equations; ++num )
   {
   }
}


void Solver_structure::solve_it ( )
{
   // The skyline structure stores row multipliers below the
   // diagonals and reduced matrix entries above the diagonals

   int* left = sky_sizes->left;
   int* diag = sky_sizes->diag;

   // this solver will find the difference between the current_soln
   // and the next guess
   // store the current solution in dela_soln and add on the
   // calculated delta at the end
   int row_last_diag = 0;  int col_last_diag = 0;
   int row_top = 0;        int col_top = 0;
   int row_diag = 0;       int col_diag = 0;
   int row_left = 0;       int col_left = 0;
   int row_start_left = 0; int col_start_left = 0;
   int row_start_top = 0;  int col_start_top = 0;
   int first = 0;
   int overlap_starts = 0; int col_pt = 0;
   int row_pt1 = 0;        int row_pt2 = 0;
   double hold;             int diff = 0;
   int first_one;          int last_one;
   int first_sub;          int last_sub;
   int current_memory = 16;
   int check_first;        int check_last;
   int memory_size;
   int number_of_blocks = 1;

   // loop over the number of matrix blocks needed
   //for ( int block = 0; block < number_of_blocks; ++ block )
   //{
   first_one = 0;
   last_one = 3;
   int block = 0;
   
   // loop on subordinate blocks
   memory_size = 0;
   int sub = 0;
   first_sub = 0;
   last_sub = number_of_equations-1;
   row_diag = 0;
       
   for ( int row = 0; row < number_of_equations; ++row ) {
     if ( row == 0 ) continue;
     if ( diag[row] < diag[row-1] )
       row_last_diag = -1;
     else
       row_last_diag = diag[row-1];
     row_diag = diag [row];
     row_left = left [row];
     if ( (row+1) == first_one )
       row_top = (row_diag) - row_left;
     else
       row_top = (row_diag - row_last_diag) - row_left - 1;
     
     row_start_left = row + 1 - row_left;
     row_start_top = row + 1 - row_top;
     // see if this subblock is used here
     check_first = max ( first_sub-1,
			 min(row_start_left,row_start_top)-1 );
     check_last = min ( row, last_sub );
     
     if ( check_first <= check_last ) {
       for ( int col = check_first; col < check_last; ++col ) {
	 if ( col <= 1 )
	   col_last_diag = 0;
	 else {
	   if ((col+1) == first_sub  )
	     col_last_diag = -1;
	   else
	     col_last_diag = diag [col-1];
	 }
	 col_diag = diag [col];
	 col_left = left [col];
	 col_top = 0;
	 col_start_left = 0;
	 col_start_top = 0;
	 if ( col > 0 ) {
	   col_top = (col_diag - col_last_diag) - col_left - 1;
	   col_start_left = col + 1 - col_left;
	   col_start_top = col + 1 - col_top;
	 }
		   
	 // find matrix ( row, col )
	 if ( row_start_left <= (col+1) ) {
	   overlap_starts = max ( row_start_left, col_start_top );
	   col_pt = col_diag - ( (col+1) - overlap_starts );
	   row_pt1 = row_diag - row_top - ( row - col );
	   row_pt2 = row_diag - row_top -
	     ( (row+1) - overlap_starts );
	   hold = 0.0;
	   if ( col_pt > -1 ) {
	     diff = col + 1 - overlap_starts;
	     if ( diff > 0 ) hold = dot_product
	       (&matrix[row_pt2], &matrix[col_pt], diff );
	   }
	   matrix [row_pt1] =
	     ( matrix[row_pt1] - hold ) / matrix[col_diag];
	   if ( number_of_blocks > 1 && block == sub )
	     matrix [row_pt1] = matrix [row_pt1];
	 }
		   
	 // find matrix ( col, row )
	 if ( row_start_top <= (col+1) ) {
	   overlap_starts = max ( row_start_top, col_start_left );
	   col_pt = col_diag - col_top -
	     ( (col+1) - overlap_starts );
	   row_pt1 = row_diag - ( row - col );
	   row_pt2 = row_diag - ( (row+1) - overlap_starts );
	   hold = 0.0;
	   if ( col_pt > -1 ) {
	     diff = col + 1 - overlap_starts;
	     if ( diff > 0 ) hold = dot_product
	       ( &matrix[col_pt], &matrix[row_pt2], diff );
	     matrix [row_pt1] = matrix [row_pt1] - hold;
	     if ( number_of_blocks > 1 && block == sub )
	       matrix [row_pt1] = matrix [row_pt1];
	   }
	 }
       }
     }
               
     // find matrix ( row, row )
     overlap_starts = max ( row_start_left, row_start_top );
     row_pt1 = row_diag - row_top - ( (row+1) - overlap_starts );
     row_pt2 = row_diag - ( (row+1) - overlap_starts );
     hold = 0.0;
     diff = row + 1 - overlap_starts;
     if ( diff > 0 ) hold = dot_product
       ( &matrix[row_pt1], &matrix[row_pt2], diff);
     matrix [row_diag] = matrix [row_diag] - hold;
     if ( number_of_blocks > 1 )
       matrix [row_diag] = matrix [row_diag];
     
     // check for zero pivot
     if (fabs(matrix[row_diag]) <= machine_zero) {
       printf("zero pivot on row: %d\n",row);
       // matrix[row_diag] = machine_zero;
       break;
     }
	   
     // reduce the right hand side
     row_pt1 = row_diag - row_top - ( (row+1) - row_start_left );
     hold = 0.0;
     diff = row + 1 - row_start_left;
     if ( diff > 0 ) hold = dot_product ( &matrix[row_pt1],
					  &solution[row_start_left-1], diff );
     solution [row] = rhs [row] - hold;
   }

   // second loop on blocks
   block = 0;
   first_one = 0;
   last_one = number_of_equations-1;

   // back substitution to find the solution
   int row_above = last_one - 1;
   int diag_above = diag[row_above];
   int row_pt;
   for ( int row = number_of_equations-1; row >= 0; --row ) {
     ++row_above;
     row_diag = diag [ row ];
     row_left = left [ row ];
     if ( row == 0 ) 
       diag_above = 0;
     else {
       if ( (row+1) == first_one )
	 diag_above = -1;
       else
	 diag_above = diag [ row-1 ];
     }
     row_top = (row_diag - diag_above) - row_left - 1;
     row_start_top = row + 1 - row_top;
     solution [row] = solution [row] / matrix [ row_diag ];
     if ( row_start_top <= row_above ) {
       row_pt = row_diag - row_top;
       for ( int place = row_start_top-1; place < row; ++place ) {   
	 solution [place] = solution [place]
	   - matrix [row_pt] * solution [row];
	 ++row_pt;
       }
     }
   }

   // add the delta solution found onto the current guess of the solution
   //printf("old solution: \n");
   // for ( int q = 0; q < number_of_equations; ++q ) {
   //  printf(" %f ",delta_soln[q]);
   //}
   //printf("\n");

   printf("new solution: \n");
   for ( int q = 0; q < number_of_equations; ++q ) {
     solution[q] = delta_soln[q] - solution[q];
     printf(" %f ",solution[q]);
   }
   printf("\n");
}
