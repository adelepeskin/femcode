#ifndef LIST_H
#define LIST_H

class List
{
   friend class Mesh;
   friend class Solver_structure;
   friend class Element;
   friend class One_d_element;
   friend class Node;
   friend class Moving_boundary_entity;
   friend class Item_Element;
   friend class Item_Node;
   friend class Item_Moving;
   friend class vector;
   public:
      List ( );
      bool is_empty ( );
      void append ( Element* );
      void append ( Node* );
      void append ( Moving_boundary_entity* );
      void element_off_list ( int );
      void node_off_list ( Node* );
      void delete_the_top ( );
      void display_element_list ( );
      void display_node_list ( );
      void display_moving_list ( );
      void display_initial_velocities ( );
      void display_intersecting_particle_nodes ( );
      void display_particle_types ( );
      void assign_shape_fcns ( );
      Node* find_node_ptr ( int );
      Element* find_element_ptr ( int );
      Element* get_top_element ( );
      void initialize_reaction_solution ( myvar* );
      void get_initial_values ( integration_flags* );
      void store_current_eqn_numbers ( integration_flags* );
      void store_pressure_eqn_numbers ( );
      void get_initial_field
	 ( integration_flags*, equation_groups, solution_vectors* );
      void get_initial_element_field ( solution_vectors* );
      void get_initial_pressures ( integration_flags* );
      void setup_initial_pressures ( );
      void set_current_pressure_space ( );
      void read_in_nodal_values
	 ( integration_flags*, initial_node_values* );
      void fix_sizes_for_skyline
         ( Solver_structure*, integration_flags*, skyline_sizes* );
      void fix_sizes_for_iterative
         ( Solver_structure*, integration_flags*, iterative_sizes*, int );
      void assign_skyline ( int, int, int*, int*, int*, int*, fill_diag_flag );
      void assign_block_structure ( Solver_structure*, skyline_sizes* );
      void assign_iterative ( int*, int, int, int, int, int*, int* );
      void count_field_eqn_numbers ( integration_flags* );
      void assign_pressure_eqn_numbers ( integration_flags* );
      void set_up_eqn_arrays ( );
      void renumber_equations ( );
      void renumber_equations_separately ( equation_groups* );
      void find_element_ptrs_from_element_numbers ( List* );
      Element* find_equivalent_quad ( Element* );
      void integrate ( equation_groups );
      void fill_skyline
         ( Solver_structure*, myvar*, skyline_sizes* );
      void fill_iterative
         ( Solver_structure*, myvar*, iterative_sizes* );
      void element_resid
	 ( int, myvar*, solution_vectors*, equation_groups );
      void update_matrices ( );
      void update_r_values ( which_way, myvar* );
      void move_the_mesh_forward ( myvar* );
      void move_the_mesh_back ( );
      void put_back_original_coordinates ( );
      void save_old_coordinates ( );
      void save_old_pressures ( );
      void print_xy_for_restart ( );
      void read_xy_from_restart ( );
      void print_post_processor ( integration_flags* );
      void print_pressures ( );
      myvar find_sum_for_con_logs ( myvar*, myvar*, integration_flags* );
      void original_slopes ( );
      void save_top_node_value ( );
      void replace_top_node_value ( );
      void check_vel_eqn_numbers ( );
      void show_quad_numbers ( );
      void reset_renumber_flags ( );
      void update_nodes_with_solutions 
         ( integration_flags*, equation_groups, myvar* );
      void update_elements_with_solutions ( myvar* );
      void run_through_the_nodes ( );
      void fill_equation_number_arrays ( );
      void find_vval ( );
      void check_all_the_elements ( );
      void check_deriv ( );

   private:
      Item_Element* top_element;
      Item_Element* bottom_element;
      Item_Node* top_node;
      Item_Node* bottom_node;
      Item_Node* old_top_node;
      Item_Moving* top_moving;
      Item_Moving* bottom_moving;
      static const myvar set_free_value;
      static const int max_number_of_blocks;
};

class Item_Element
{
   friend class List;
   friend class Element;
   public:
      Item_Element ( Element* );

   protected:
      Element* value;
      Item_Element *next;
};

class Item_Node
{
   friend class List;
   friend class Node;
   public:
      Item_Node ( Node* );

   protected:
      Node* value;
      Item_Node *next;
};

class Item_Line
{
   friend class List;
   friend class Line;
   public:
      Item_Line ( Line* );

   protected:
      Line* value;
      Item_Line *next;
};

class Item_Moving
{
   friend class List;
   friend class Moving_boundary_entity;
   public:
      Item_Moving ( Moving_boundary_entity* );

   protected:
      Moving_boundary_entity* value;
      Item_Moving *next;
};

#endif
