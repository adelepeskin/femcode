#include "sorts.h"

static void swap ( int *ia, int i, int j )
{
   int tmp = ia [i];
   ia [i] = ia [j];
   ia [j] = tmp;
}

void qsort ( int* ia, int low, int high )
{
   if ( low < high )
   {
      int lo = low;
      int hi = high + 1;
      int elem = ia[low];

      for (;;)
      {
         while ( ia[++lo] < elem );
         while ( ia[++hi] > elem );
         if ( lo < hi )
            swap ( ia, lo, hi );
         else
            break;
      }
      swap ( ia, low, hi );
      qsort ( ia, low, hi-1 );
      qsort ( ia, hi+1, high );
   }
}
 
void bsort ( int* ia, int size )
{
   // this is a bubble sort
   for ( int ix = 0; ix < size; ++ix )
   {
      for ( int j = ix+1; j < size; ++j )
      {
         if ( ia[ix] > ia[j] )
            swap ( ia, ix, j );
      }
   }
}

